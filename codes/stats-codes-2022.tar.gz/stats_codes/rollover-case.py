import datetime
import os
import json


rollover_input_path = "/path/to/rollover_output/"
target_case_input_path = "/path/to/rollover_case/"
target_input_path = "/path/to/rollover-actual-targets.txt"


dateMxMap = {"SO":{}, "SSDO":{}, "SSDS":{}}
domainStat = {"SO":[set([]), set([])], "SSDO":[set([]), set([])], "SSDS":[set([]), set([])]}
candList = []

def getDetailedStats(mx, results, dnCase):
    global domainStat
    stats = {"num":0, "NoData":0, "ShortTTL":0, "NotRollover":0, "NotMatchedBefore":0, "wrong":0, "earlyRetract":0, "btw":0, "afterUpdate":0, "afterNotUpdate":0, "same":0, "correct":0, "timingIssue":0}


    lateOrNo = []
    for result in results:
        stats["num"] += 1

        if result == "NoData" or result == "ShortTTL":
            stats[result] += 1
            continue

        result = result.split("/")

        depth = result[1]
        case = result[2]
        
        if case == "UnmatchBefore":
            stats["NotMatchedBefore"] += 1
            continue

        elif case == "NotRollover":
            stats["NotRollover"] += 1
            continue
        
        elif case == "Correct":
            stats["correct"] += 1
            
            times = dateMxMap[dnCase][mx].keys()
            for time in times:
                domainStat[dnCase][0].update(dateMxMap[dnCase][mx][time])
            continue

        elif case == "Wrong":
            times = dateMxMap[dnCase][mx].keys()
            for time in times:
                domainStat[dnCase][0].update(dateMxMap[dnCase][mx][time])
                domainStat[dnCase][1].update(dateMxMap[dnCase][mx][time])

            stats["wrong"] += 1
            wrongCase = result[3]
            timingFlag = False
            if wrongCase == "a":
                stats["earlyRetract"] += 1
            elif wrongCase == "b":
                if result[5] == "NotMatched":
                    stats["afterNotUpdate"] += 1
                    lateOrNo.append((result[4], "N"))
                else:
                    stats["afterUpdate"] += 1
                    lateOrNo.append((result[4], "L"))
                    timingFlag = True
            elif wrongCase == "c":
                stats["same"] += 1
                timingFlag = True
            elif wrongCase == "d":
                stats["earlyRetract"] += 1
            elif wrongCase == "e":
                if result[5] == "NotMatched":
                    stats["afterNotUpdate"] += 1
                    lateOrNo.append((result[4], "N"))
                else:
                    stats["afterUpdate"] += 1
                    lateOrNo.append((result[4], "L"))
                    timingFlag = True
            elif wrongCase == "thres":
                thresCase = result[5]
                if thresCase == "NotMatched":
                    stats["afterNotUpdate"] += 1
                    lateOrNo.append((result[4], "N"))
                elif thresCase == "Between":
                    stats["btw"] += 1
                    timingFlag = True
                elif thresCase == "SameTime":
                    stats["same"] += 1
                    timingFlag = True
                elif thresCase == "After":
                    stats["afterUpdate"] += 1
                    lateOrNo.append((result[4], "L"))
                else:
                    print("thresCase Error!!!!!!!!!!!!!")
                    print(thresCase)
                    print(results)
                    input()
            else:
                print("wrongCase Error!!!!!!!!!!!!!")
                print(wrongCase)
                print(results)
                input()

            if timingFlag:
                stats["timingIssue"] += 1
        else:
            print("case Error!!!!!!!!!!!!!")
            print(case)
            print(resutls)
            input()

    return stats, lateOrNo


def getRolloverStat(mxResults, case):
        
    resultMap = {"total":0, "NotTarget":0, "NeverMatched":0, "NoData":0, "ShortTTL":0, "NotRollover":0, "wrong":0, "earlyRetract":0, "btw":0, "afterUpdate":0,  "afterNotUpdate":0, "same":0, "correct":0, "timingIssue":0}

    cannotKnowMX = set([])

    targetMX = set([])
    
    mxs = mxResults.keys()

    for mx in mxs: 
        line = mxResults[mx]

        if"ERROR/" in line:
            print("Error!!!!!!!!!!!!!!!!!")
            print(line)
            input()

        if len(line) < 1:
            print(line)
            continue 

        if line[0] == "NotTarget":
            resultMap[line[0]] += 1
            continue

        if not mx in candList:
            continue

        resultMap["total"] += 1
        if line[0] == "NeverMatched":
            resultMap[line[0]] += 1
            continue

        #resultMap["total"] += 1
            
        results = set(line)

        if len(results) == 1:
            if "NoData" in results:
                resultMap["NoData"] += 1
                continue
            if "ShortTTL" in results:
                resultMap["ShortTTL"] += 1
                continue
        if len(results) == 2:
            if "NoData" in results and "ShortTTL" in results:
                resultMap["ShortTTL"] += 1
                continue

        details, lateOrNo = getDetailedStats(mx, results, case)
        lateOrNo = sorted(lateOrNo, key=lambda x: datetime.datetime.strptime(x[0], "%Y%m%d-%H"))

        flag = False
        if details["num"] > 0:
            if details["num"] == details["NotMatchedBefore"]:
                resultMap["NeverMatched"] += 1
                flag = True
            elif details["num"] == details["NotRollover"]:
                resultMap["NotRollover"] += 1
                flag = True
            elif details["wrong"] == 0 and details["correct"] > 0:
                if details["ShortTTL"] > 0:
                    resultMap["ShortTTL"] += 1
                    flag = True
                if details["NoData"] > 0:
                    resultMap["NoData"] += 1
                    flag = True
            elif details["num"] == (details["NoData"] + details["NotRollover"] + details["NotMatchedBefore"]):
                if details["NoData"] > 0:
                    resultMap["NoData"] += 1
                    flag = True
                elif details["NotRollover"] > 0:
                    resultMap["NotRollover"] += 1
                    flag = True
                else:
                    resultMap["NeverMatched"] += 1
                    flag = True


        if flag:
            continue

        targetMX.add(mx)
            
        if details["num"] > 0:

            if details["wrong"] == 0 and details["correct"] > 0:
                if details["NoData"] == 0 and details["ShortTTL"] == 0:
                    resultMap["correct"] += 1
            elif details["wrong"] > 0:
                resultMap["wrong"] += 1
                if details["earlyRetract"] > 0:
                    resultMap["earlyRetract"] += 1
                if details["btw"] > 0:
                    resultMap["btw"] += 1
                if details["afterUpdate"] > 0:
                    resultMap["afterUpdate"] += 1
                if details["afterNotUpdate"] > 0:
                    judgeSet = set([])
                    if len(lateOrNo) == 0:
                        print(line)
                        print(lateOrNo)
                        input()
                    for data in lateOrNo:
                        judgeSet.add(data[1])
                    if len(judgeSet) == 1 and "N" in judgeSet:
                        resultMap["afterNotUpdate"] += 1

                if details["same"] > 0:
                    resultMap["same"] += 1
                if details["timingIssue"] > 0:
                    resultMap["timingIssue"] += 1

                if details["wrong"] > 0 and details["earlyRetract"] == 0 and details["btw"] == 0 and details["afterUpdate"] == 0 and details["afterNotUpdate"] == 0 and details["same"] == 0:
                    print("Something Wrong!!")
                    print(details)
                    input()
            else:
                print("Something Wrong2!!")
                print(details)
                input()


    keys = list(resultMap.keys())
    
    for key in keys:
        print("-", key, resultMap[key])
    print("- Target", len(targetMX))



def classifyRolloverCase(results, caseMap):

    returns = []

    for result in results:
        if "NoData" in result or "ShortTTL" in result:
            date = result.split("/")[1]
            result = result.split("/")[0]
        elif "Correct" in result or "NotRollover" in result or "UnmatchBefore" in result:
            date = result.split("/")[3]
        elif "Wrong" in result:
            date = result.split("/")[4]
        else:
            print(result)
            input()

        if date in caseMap:
            returns.append(result)

    return returns


def mapCase():
    global dateMxMap
    caseMap = {"SO":{}, "SSDO":{}, "SSDS":{}}
    
    months = ["1907", "1908", "1909", "1910", "1911", "1912", "2001", "2002", "2003", "2004", "2005", "2006", "2007", "2008", "2009", "2010" ,"2011", "2012", "2101"]
    
    path = os.path.join(target_case_input_path, "rollover_target_case_")
    for month in months:
        files = os.listdir(path + month)
        for filename in files:
            f = open(path + month + "/" + filename, "r")
            while True:
                line = f.readline()
                if not line: break

                l = json.loads(line)

                mx = l['mx']
                cases = list(l.keys())
                cases.remove('mx')
            
                for case_ in cases:
                    if case_ == "MO":
                        case = "SO"
                    elif case_ == "MSDO":
                        case = "SSDO"
                    elif case_ == "MSDS":
                        case = "SSDS"
                    else:
                        case = case_

                    if not mx in caseMap[case]:
                        caseMap[case][mx] = []

                    caseMap[case][mx] += sorted(l[case_].keys(), key = lambda x: datetime.datetime.strptime(x, "%Y%m%d-%H"))
                    dateMxMap[case][mx] = l[case_]

    targets = set([])
    cases = caseMap.keys()
    for case in cases:
        targets |= caseMap[case].keys()

   
    rolloverCase = {"SO":{}, "SSDO":{}, "SSDS":{}}
    
    path = os.path.join(rollover_input_path , "rollover_output/")
    files = os.listdir(path)
    for filename in files:
        f = open(path + filename, "r")
        while True:
            line = f.readline()
            if not line: break

            line = line.strip().split()

            mx = line[0]
            if not mx in targets:
                continue
            
            for case in cases:
                if mx in caseMap[case]:
                    classified = classifyRolloverCase(line[1:], caseMap[case][mx])
                    if not classified == []:
                        rolloverCase[case][mx] = classified

        f.close()

    return rolloverCase


def readCand():
    global candList
    
    f = open(os.path.join(target_input_path, "rollover-actual-targets.txt"), "r")
    while True:
        line = f.readline()
        if not line: break

        line = line.strip().split()
        candList.append(line[0])

    f.close()



if __name__ == "__main__":
    readCand()
    rolloverCase = mapCase()

    cases = rolloverCase.keys()
    cases = ["SO", "SSDO", "SSDS"]
    for case in cases:
        print("- " + case)
        getRolloverStat(rolloverCase[case], case)
        print(len(domainStat[case][0]), len(domainStat[case][1]))
        print("")
