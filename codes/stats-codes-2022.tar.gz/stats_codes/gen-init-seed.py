import os
import datetime
import json
import dns.message as mymessage
import base64
from OpenSSL import crypto


input_path = "/path/to/input (aggregated files)"
mx_wo_nl_input_path = "/path/to/all-mx-exclude-nl.txt"
antago_syix_mx_input_path = "/path/to/antago_syix_mx/"
incorrect_input_path = "/path/to/incorrect_output_[month]"


X3 = "7fdce3bf4103c2684b3adbb5792884bd45c75094c217788863950346f79c90a3"
antagonistMx = set([])
targetMx = set([])
unknownMap = {}
emptyCount = 0

def getData():
    unknownData = []
    times = unknownMap.keys()
    print(unknownMap.keys())
    for time in times:
        mxs = unknownMap[time]
        f = open(input_path + time + ".txt", "r")
        while True:
            line = f.readline()
            if not line: break
           
            l = json.loads(line)
            if l["domain"] in mxs:
                unknownData.append((l["domain"], l["tlsa"]["record_raw"], l["starttls"]["certs"]))
    return unknownData


def usingX3(raw):
    global emptyCount
    msg = base64.b64decode(raw)
    msg = mymessage.from_wire(msg)
    rrsetList = []
    for answer in msg.answer:
        if answer.rdtype == 52: 
            rrsetList = rrsetList + [data.to_text() for data in answer]

    for rrset in rrsetList:
        if X3 in rrset.lower():
            return True
        if "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855" in rrset.lower():
            emptyCount += 1
    return False


def checkX3():
    unknownData = getData()
    print(len(unknownData))
    leLeaf = 0
    x3 = 0
    for data in unknownData:
        useX3 = usingX3(data[1])
        if not useX3: continue

        x3 += 1
        certs = data[2]
        leaf = certs[0]
    
        crt = base64.b64decode(leaf)
        crt = crypto.load_certificate(crypto.FILETYPE_PEM, crt)
        issuer = crt.get_issuer()
        if issuer == None or issuer.O == None: continue

        if issuer.O == "Let's Encrypt":
            leLeaf += 1
            print(data)
        
    print("Using X3:", x3)
    print("Among them, using LE leaf:", leLeaf)


def getInitSetAux(month, initSet):

    path = os.path.join(incorrect_input_path, "incorrect_output_" + month + "/")

    files = os.listdir(path)
    for filename in files:
        f = open(path + filename, "r")

        while True:
            line = f.readline()
            if not line: break

            line = line.strip().split()

            mx = line[0]
            if mx in antagonistMx:
                continue

            if not mx in targetMx:
                continue

            date = line[2]
            time = date + "-" + line[3]

            if datetime.datetime.strptime(time, "%Y%m%d-%H") < datetime.datetime.strptime("20190713-0", "%Y%m%d-%H"):
                continue
            if datetime.datetime.strptime(time, "%Y%m%d-%H") > datetime.datetime.strptime("20210212-14", "%Y%m%d-%H"):
                continue

            if datetime.datetime.strptime(date, "%Y%m%d") < datetime.datetime.strptime("20191013", "%Y%m%d"):
                initSet.add(mx)

        f.close()
    return initSet


def getInitSet():

    initSet = set([])
    months = ["1907", "1908", "1909", "1910"]
    for month in months:
        initSet = getInitSetAux(month, initSet)
   
    f = open("init-seed.txt", "w")
    for mx in initSet:
        f.write(mx + "\n")
    f.close()

    return initSet


def checkInitDeployMonth(initSet, appeared, initMap, path):
    global unknownMap
    files = os.listdir(path)

    for filename in files:
        f = open(path + filename, "r")
        while True:
            line = f.readline()
            if not line: break

            line = line.strip().split()
            
            date = line[2] + "-" + line[3]
            if datetime.datetime.strptime(date, "%Y%m%d-%H") < datetime.datetime.strptime("20191014-0", "%Y%m%d-%H"):
                continue
            if datetime.datetime.strptime(date, "%Y%m%d-%H") > datetime.datetime.strptime("20210212-14", "%Y%m%d-%H"):
                continue

            mx = line[0]
            if mx in antagonistMx:
                continue
            if not (mx in targetMx):
                continue

            if mx in initSet:
                continue
            if mx in appeared:
                continue
           

            if line[2] == "20201217" and line[3] == "1":
                initMap["1217"].append(mx)
                appeared.add(mx)
                continue

            if line[4] == "NoTLSA" or line[4] == "NoCerts":
                initMap["nodata"].append(mx)
            elif line[4] == "Correct":
                initMap["correct"].append(mx)
            else:
                dnssec = line[4]
                chain = line[5]
                matching = line[6]

                if dnssec == "Insecure":
                    initMap["insecure"].append(mx)
                elif dnssec == "Bogus":
                    initMap["bogus"].append(mx)

                if chain == "WrongChain":
                    initMap["chain"].append(mx)

                if matching == "WeirdField":
                    initMap["undefined"].append(mx)
                elif matching == "OtherReason":
                    initMap["wrong_fields"].append(mx)
                elif matching == "NoCase":
                    initMap["unknown"].append(mx)
                    time = line[2][2:] + "_" + line[3]
                    if not time in unknownMap:
                        unknownMap[time] = []
                    unknownMap[time].append(mx)

            appeared.add(mx)
        f.close()

    return appeared, initMap


def checkInitDeployment(initSet):
    path = os.path.join(incorrect_input_path, "incorrect_output_")
    months = ["1910", "1911", "1912", "2001", "2002", "2003", "2004", "2005", "2006", "2007", "2008", "2009", "2010", "2011", "2012", "2101", "2102"]
    #months = ["1911"]
    initMap = {"1217":[], "nodata":[], "correct":[], "insecure":[], "bogus":[], "undefined":[], "wrong_fields":[], "unknown":[], "chain":[]}
    appeared = set([])
    for month in months:
        print(month)
        appeared, initMap = checkInitDeployMonth(initSet, appeared, initMap, path + month + "/")

    checkX3()
    print("Newly appeared:", len(appeared))
    keys = initMap.keys()
    for key in keys:
        print(key, len(initMap[key]))

    print("Empty:", emptyCount)

def getAntagonist():
    mxs = set([])
    path = os.path.join(antago_syix_mx_input_path, "antago_syix_mx/")
    files = os.listdir(path)
    for filename in files:
        f = open(path + filename, "r")
        while True:
            line = f.readline()
            if not line: break
            line = line.strip().split()

            if line[-1] == "Antagonist":
                mxs.add(line[0])
        f.close()

    return mxs


def getTargetMx():
    global targetMx
    f = open(os.path.join(mx_wo_nl_input_path, "all-mx-exclude-nl.txt"), "r")
    while True:
        line = f.readline()
        if not line: break
        mx = line.strip()
        targetMx.add(mx)
    f.close()


if __name__ == "__main__":
    getAntagonist()
    getTargetMx()
    initSet = getInitSet()
    print("Init TLSA:", len(initSet))
    checkInitDeployment(initSet)
        

