import datetime
import os


rollover_input_path = "/path/to/rollover_output/"
le_input_path = "/path/to/le_output/"
rollover_target_input_path = "/path/to/rollover-actual-targets.txt"
output_path = "/path/to/output/"


dateMap = {}
candList = []

def getTimeline():
    times = dateMap.keys()
    times = sorted(times, key=lambda x: datetime.datetime.strptime(x, "%Y%m%d %H"))

    start = datetime.datetime.strptime(times[0], "%Y%m%d %H")
    end = datetime.datetime.strptime("20210212 14", "%Y%m%d %H")

    timeList = []
    delta = end - start
    for i in range((delta.days+1)*24):
        t = start + datetime.timedelta(seconds=i*3600)
        t = t.strftime("%Y%m%d %H")
        if t.split(" ")[1][0] == "0":
            t = t.split(" ")[0] + " " + t.split(" ")[1][1]
        timeList.append(t)

        
    timeline = {}
    for time in timeList:
        timeline[time] = []

    overlap = set([])
    usages = ["3", "2", "2_3"]
    prev = None
    for time in times:
        if prev == None:
            currWhole = dateMap[time][0]["total"] | dateMap[time][1]["total"]

            currFail = dateMap[time][1]["total"]
            currEarlyDrop = dateMap[time][2]["total"]
            currTimingFail = dateMap[time][3]["total"]
            currNotUpdated = dateMap[time][4]["total"]
            currSucc = currWhole - currFail
            currUsages = {}
            for usage in usages:

                currUsageWhole = dateMap[time][0][usage] | dateMap[time][1][usage]
                currUsageFail = dateMap[time][1][usage]
                currUsageEarlyDrop = dateMap[time][2][usage]
                currUsageTimingFail = dateMap[time][3][usage]
                currUsageNotUpdated = dateMap[time][4][usage]
                currUsageSucc = currUsageWhole - currUsageFail
                currUsages[usage] = [currUsageWhole, currUsageSucc, currUsageFail, currUsageEarlyDrop, currUsageTimingFail, currUsageNotUpdated]

                if usage == "3":
                    overlap |= currUsageTimingFail.intersection(currUsageNotUpdated)

            timeline[time] = [currWhole, currSucc, currFail, currEarlyDrop, currTimingFail, currNotUpdated, currUsages]

            prev = timeline[time]
            continue


        currWhole = prev[0] | dateMap[time][0]["total"] | dateMap[time][1]["total"]

        currFail = prev[2] | dateMap[time][1]["total"]
        currEarlyDrop = prev[3] | dateMap[time][2]["total"]
        currTimingFail = prev[4] | dateMap[time][3]["total"]
        currNotUpdated = prev[5] | dateMap[time][4]["total"]
        currSucc = currWhole - currFail
        currUsages = {}
        for usage in usages:
            currUsageWhole = prev[6][usage][0] | dateMap[time][0][usage] | dateMap[time][1][usage]
            currUsageFail = prev[6][usage][2] | dateMap[time][1][usage]
            currUsageEarlyDrop = prev[6][usage][3] | dateMap[time][2][usage]
            currUsageTimingFail = prev[6][usage][4] | dateMap[time][3][usage]
            currUsageNotUpdated = prev[6][usage][5] | dateMap[time][4][usage]
            currUsageSucc = currUsageWhole - currUsageFail
            currUsages[usage] = [currUsageWhole, currUsageSucc, currUsageFail, currUsageEarlyDrop, currUsageTimingFail, currUsageNotUpdated]
            if usage == "3":
                overlap |= currUsageTimingFail.intersection(currUsageNotUpdated)
            
        timeline[time] = [currWhole, currSucc, currFail, currEarlyDrop, currTimingFail, currNotUpdated, currUsages]

        prev = timeline[time]
    
    print("overlap", len(overlap)) 
    prev = None
    f = open(os.path.join(output_path, "rollover-timeline-le.txt"), "w")
    f.write("#time,total,success,fail,early_drop,timing_fail,not_update,usage3_total,usage3_succ,usage3_fail,usage3_early_drop,usage3_timing_fail,usage3_not_update,usage2_total,usage2_succ,usage2_fail,usage2_early_drop,usage2_timing_fail,usage2_not_update,usage2_3_total,usage2_3_succ,usage_2_3_fail,usage_2_3_early_drop,usage2_3_timing_fail,usage2_3_not_update\n")
    for time in timeList:
        if timeline[time] == []:
            f.write(time + "," + str(len(prev[0])) + "," + str(len(prev[1])) + "," + str(len(prev[2])) + "," + str(len(prev[3])) + "," + str(len(prev[4])) + "," + str(len(prev[5])))
            for usage in usages:
                f.write("," + str(len(prev[6][usage][0])) + "," + str(len(prev[6][usage][1])) + "," + str(len(prev[6][usage][2])) + "," + str(len(prev[6][usage][3])) + "," + str(len(prev[6][usage][4])) + "," + str(len(prev[6][usage][5])))
            f.write("\n")
            
        else:
            f.write(time + "," + str(len(timeline[time][0])) + "," + str(len(timeline[time][1])) + "," + str(len(timeline[time][2])) + "," + str(len(timeline[time][3])) + "," + str(len(timeline[time][4])) +"," + str(len(timeline[time][5])))
            for usage in usages:
                f.write("," + str(len(timeline[time][6][usage][0])) + "," + str(len(timeline[time][6][usage][1])) + "," + str(len(timeline[time][6][usage][2])) + "," + str(len(timeline[time][6][usage][3])) + "," + str(len(timeline[time][6][usage][4])) + "," + str(len(timeline[time][6][usage][5])))
            f.write("\n")

            prev = timeline[time]

    f.close()


def getUsageStats(mx, results):
    global dateMap

    stats = {"num":0, "NoData":0, "ShortTTL":0, "wrong":0, "correct":0, "NotRollover":0}

    usages = set([])
    for result in results:
        
        stats["num"] += 1

        if result == "NoData" or result == "ShortTTL":
            stats[result] += 1
            continue

        result = result.split("/")

        usage = result[0]
        if not usage in stats:
            stats[usage] = {"num":0, "NotRollover":0, "NotMatchedBefore":0, "wrong":0, "earlyRetract":0, "btw":0, "afterUpdate":0, "afterNotUpdate":0, "same":0, "correct":0}
            usages.add(usage)
            
        depth = result[1]
        case = result[2]

        stats[usage]["num"] += 1


        if case == "UnmatchBefore":
            stats[usage]["NotMatchedBefore"] += 1
            continue

        elif case == "NotRollover":
            stats["NotRollover"] += 1
            stats[usage]["NotRollover"] += 1
            continue

        elif case == "Correct":
            stats["correct"] += 1
            stats[usage]["correct"] += 1

            date = result[3].replace("-", " ")
            if not date in dateMap:
                correctForm = {"total":set([]), "1":set([]), "3":set([]), "1_3":set([]), "2":set([]), "2_3":set([])}
                wrongForm = {"total":set([]), "1":set([]), "3":set([]), "1_3":set([]), "2":set([]), "2_3":set([])}
                earlyDropForm = {"total":set([]), "1":set([]), "3":set([]), "1_3":set([]), "2":set([]), "2_3":set([])}
                timingFailForm = {"total":set([]), "1":set([]), "3":set([]), "1_3":set([]), "2":set([]), "2_3":set([])}
                notUpdatedForm = {"total":set([]), "1":set([]), "3":set([]), "1_3":set([]), "2":set([]), "2_3":set([])}
                dateMap[date] = [correctForm, wrongForm, earlyDropForm, timingFailForm, notUpdatedForm]
            dateMap[date][0]["total"].add(mx)
            dateMap[date][0][usage].add(mx)
            continue

        elif case == "Wrong":
            stats["wrong"] += 1
            stats[usage]["wrong"] += 1
            earlyDropFlag = False
            timingFlag = False
            notUpdateFlag = False
            wrongCase = result[3]
            if wrongCase == "a":
                stats[usage]["earlyRetract"] += 1
                earlyDropFlag = True
            elif wrongCase == "b":
                if result[5] == "NotMatched":
                    stats[usage]["afterNotUpdate"] += 1
                    notUpdateFlag = True
                else:
                    stats[usage]["afterUpdate"] += 1
                    timingFlag = True
            elif wrongCase == "c":
                stats[usage]["same"] += 1
                timingFlag = True
            elif wrongCase == "d":
                stats[usage]["earlyRetract"] += 1
                earlyDropFlag = True
            elif wrongCase == "e":
                if result[5] == "NotMatched":
                    stats[usage]["afterNotUpdate"] += 1
                    notUpdateFlag = True
                else:
                    stats[usage]["afterUpdate"] += 1
                    timingFlag = True
            elif wrongCase == "thres":
                thresCase = result[5]
                if thresCase == "NotMatched":
                    stats[usage]["afterNotUpdate"] += 1
                    notUpdateFlag = True
                elif thresCase == "Between":
                    stats[usage]["btw"] += 1
                    timingFlag = True
                elif thresCase == "SameTime":
                    stats[usage]["same"] += 1
                    timingFlag = True
                elif thresCase == "After":
                    stats[usage]["afterUpdate"] += 1
                    timingFlag = True
                else:
                    print("thresCase Error!!!!!!!!!!!!!")
                    print(thresCase)
                    print(results)
                    input()
            else:
                print("wrongCase Error!!!!!!!!!!!!!")
                print(wrongCase)
                print(results)
                input()
            ##
            date = result[4].replace("-", " ")
            if not date in dateMap:
                correctForm = {"total":set([]), "1":set([]), "3":set([]), "1_3":set([]), "2":set([]), "2_3":set([])}
                wrongForm = {"total":set([]), "1":set([]), "3":set([]), "1_3":set([]), "2":set([]), "2_3":set([])}
                earlyDropForm = {"total":set([]), "1":set([]), "3":set([]), "1_3":set([]), "2":set([]), "2_3":set([])}
                timingFailForm = {"total":set([]), "1":set([]), "3":set([]), "1_3":set([]), "2":set([]), "2_3":set([])}
                notUpdatedForm = {"total":set([]), "1":set([]), "3":set([]), "1_3":set([]), "2":set([]), "2_3":set([])}
                dateMap[date] = [correctForm, wrongForm, earlyDropForm,  timingFailForm, notUpdatedForm]
            dateMap[date][1]["total"].add(mx)
            dateMap[date][1][usage].add(mx)
            if earlyDropFlag:
                dateMap[date][2]["total"].add(mx)
                dateMap[date][2][usage].add(mx)
            if timingFlag:
                dateMap[date][3]["total"].add(mx)
                dateMap[date][3][usage].add(mx)
            if notUpdateFlag:
                dateMap[date][4]["total"].add(mx)
                dateMap[date][4][usage].add(mx)

        else:
            print("case Error!!!!!!!!!!!!!")
            print(case)
            print(resutls)
            input()

    return stats, usages


def filterResult(data):
    returns = []
    for d in data:
        if "NoData" in d or "ShortTTL" in d:
            returns.append(d.split("/")[0])
        else:
            returns.append(d)

    return returns


def getRolloverStat():
    path = os.path.join(rollover_input_path, "rollover_output/")
    files = os.listdir(path)

    resultMap = {"total":0, "NotTarget":0, "NeverMatched":0, "NoData":0, "ShortTTL":0, "NotRollover":0}

    wholeUsages = set([])
    cannotKnowMX = set([])

    targetMX = 0

    for filename in files:
        if filename[0] == ".":
            continue
        f = open(path + filename, "r")
        while True:
            line = f.readline()
            if not line: break

            line = line.strip()

            if"ERROR/" in line:
                print("Error!!!!!!!!!!!!!!!!!")
                print(line)
                input()

            line = line.split(" ")

            if len(line) < 2:
                print(line)
                continue 

            if line[1] == "NotTarget": 
                resultMap[line[1]] += 1
                continue

            if not line[0] in candList:
                continue
            
            resultMap["total"] += 1
            
            if line[1] == "NeverMatched":
                resultMap[line[1]] += 1
                continue
            
            mx = line[0]
            results = set(filterResult(line[1:]))


            if len(results) == 1:
                if "NoData" in results:
                    resultMap["NoData"] += 1
                    continue
                if "ShortTTL" in results:
                    resultMap["ShortTTL"] += 1
                    continue
            if len(results) == 2:
                if "NoData" in results and "ShortTTL" in results:
                    resultMap["ShortTTL"] += 1
                    continue
           
            results = filterResult(line[1:])
            usageStat, usages = getUsageStats(mx, results)
            
            flag = False
            for usage in usages:
                if usageStat[usage]["num"] > 0:
                    if usageStat[usage]["num"] == usageStat[usage]["NotMatchedBefore"]:
                        resultMap["NeverMatched"] += 1
                        flag = True
                        break
                    elif usageStat[usage]["num"] == usageStat[usage]["NotRollover"]:
                        resultMap["NotRollover"] += 1
                        flag = True
                        break
                    elif usageStat[usage]["wrong"] == 0 and usageStat[usage]["correct"] > 0:
                        if usageStat["ShortTTL"] > 0:
                            resultMap["ShortTTL"] += 1
                            flag = True
                            break
                        if usageStat["NoData"] > 0:
                            resultMap["NoData"] += 1
                            flag = True
                            break
                    elif usageStat[usage]["num"] == (usageStat[usage]["NotRollover"] + usageStat[usage]["NotMatchedBefore"]):
                        if usageStat[usage]["NotRollover"] > 0:
                            resultMap["NotRollover"] += 1
                            flag = True
                            break
                        else:
                            resultMap["NeverMatached"] += 1
                            flag = True
                            break

            if flag:
                continue

            targetMX += 1
            wholeUsages.update(usages)
            
            for usage in usages:
                if not usage in resultMap:
                    resultMap[usage] = {"num":0, "NoData":0, "NotRollover":0, "NotMatchedBefore":0, "wrong":0, "earlyRetract":0, "btw":0, "afterUpdate":0, "timingIssue":0, "afterNotUpdate":0, "same":0, "correct":0}

                if usageStat[usage]["num"] > 0:
                    resultMap[usage]["num"] += 1

                    if usageStat[usage]["wrong"] == 0 and usageStat[usage]["correct"] > 0:
                        if usageStat["NoData"] == 0 and usageStat["ShortTTL"] == 0:
                            resultMap[usage]["correct"] += 1
                        else:
                            print(line)
                            print(usageStat[usage])
                            input()
                    elif usageStat[usage]["wrong"] > 0:
                        timingFlag = False
                        resultMap[usage]["wrong"] += 1
                        if usageStat[usage]["earlyRetract"] > 0:
                            resultMap[usage]["earlyRetract"] += 1
                        if usageStat[usage]["btw"] > 0:
                            resultMap[usage]["btw"] += 1
                            timingFlag = True
                        if usageStat[usage]["afterUpdate"] > 0:
                            resultMap[usage]["afterUpdate"] += 1
                            timingFlag = True
                        if usageStat[usage]["same"] > 0:
                            resultMap[usage]["same"] += 1
                            timingFlag = True
                        if usageStat[usage]["afterNotUpdate"] > 0:
                            resultMap[usage]["afterNotUpdate"] += 1
                        
                        if timingFlag:
                            resultMap[usage]["timingIssue"] += 1

                        if usageStat[usage]["wrong"] > 0 and usageStat[usage]["earlyRetract"] == 0 and usageStat[usage]["btw"] == 0 and usageStat[usage]["afterUpdate"] == 0 and usageStat[usage]["afterNotUpdate"] == 0 and usageStat[usage]["same"] == 0:
                            print("Something Wrong!!")
                            print(usageStat)
                            input()
                    else:
                        print("Something Wrong2!!")
                        print(usage)
                        print(usageStat)
                        input()
            
        f.close()

    resultMap["NoData"] += len(cannotKnowMX)
    targetMX -= len(cannotKnowMX)
    print(len(cannotKnowMX))

    keys = list(resultMap.keys())
    for usage in wholeUsages:
        keys.remove(usage)
    
    for key in keys:
        print("-", key, resultMap[key])
    print("- Target", targetMX)
    print("")
    for usage in wholeUsages:
        print("- Usage:", usage)
        print(resultMap[usage])


def filterNonLE():
    global dateMap
    newDateMap = {}

    targetDates = dateMap.keys()

    months = ["1907", "1908", "1909", "1910", "1911", "1912", "2001", "2002", "2003", "2004", "2005", "2006", "2007", "2008", "2009", "2010", "2011", "2012", "2101"]

    path = os.path.join(le_input_path, "le_output/")

    for month in months:
        files = os.listdir(path + "le_output_" + month)
        for filename in files:
            f = open(path + "le_output_" + month + "/" + filename, "r")
            while True:
                line = f.readline()
                if not line: break
                line = line.strip().split(", ")

                if line[2] == "0":
                    continue

                date = line[1]
                if not date in targetDates:
                    continue

                mx = line[0]
                if not date in newDateMap:
                    correctForm = {"total":set([]), "1":set([]), "3":set([]), "1_3":set([]), "2":set([]), "2_3":set([])}
                    wrongForm = {"total":set([]), "1":set([]), "3":set([]), "1_3":set([]), "2":set([]), "2_3":set([])}
                    earlyDropForm = {"total":set([]), "1":set([]), "3":set([]), "1_3":set([]), "2":set([]), "2_3":set([])}
                    timingFailForm = {"total":set([]), "1":set([]), "3":set([]), "1_3":set([]), "2":set([]), "2_3":set([])}
                    notUpdatedForm = {"total":set([]), "1":set([]), "3":set([]), "1_3":set([]), "2":set([]), "2_3":set([])}
                    newDateMap[date] = [correctForm, wrongForm, earlyDropForm, timingFailForm, notUpdatedForm]
                
                keys = ["total", "1", "1_3", "3", "2", "2_3"]
                for key in keys:
                    if mx in dateMap[date][0][key]:
                        newDateMap[date][0][key].add(mx)
                    if mx in dateMap[date][1][key]:
                        newDateMap[date][1][key].add(mx)
                    if mx in dateMap[date][2][key]:
                        newDateMap[date][2][key].add(mx)
                    if mx in dateMap[date][3][key]:
                        newDateMap[date][3][key].add(mx)
                    if mx in dateMap[date][4][key]:
                        newDateMap[date][4][key].add(mx)
                

    dateMap = newDateMap



def readCand():
    global candList

    f = open(os.path.join(rollover_target_input_path, "rollover-actual-targets.txt"), "r")
    while True:
        line = f.readline()
        if not line: break

        line = line.strip().split()
        candList.append(line[0])

    f.close()


if __name__ == "__main__":
    readCand()
    getRolloverStat()
    filterNonLE()
    getTimeline()
