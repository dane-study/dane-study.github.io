import os


rollover_cand_input_path = "/path/to/rollover_cand_output/"


def avg(up, down):
    return round(100 * up / down, 1)

def writeOutput(keyChangedMap):

    f = open("keyChangedDn.txt", "w")
    keys = keyChangedMap.keys()
    for dn in keys:
        f.write(dn)
        for time in keyChangedMap[dn]:
            f.write(" " + time)
        f.write("\n")
    f.close()
 

def getStat(path):
    files = os.listdir(path)
    if "_SUCCESS" in files:
        files.remove("_SUCCESS")

    total = 0
    leafCertChanged = 0
    otherCertChanged = 0
    leafKeyChanged = 0
    otherKeyChanged = 0

    certX = 0
    certO_KeyX = 0
    certO_KeyO = 0
    leafCertX = 0
    leafCertO_KeyX = 0
    leafCertO_KeyO = 0
    otherCertX = 0
    otherCertO_KeyX = 0
    otherCertO_KeyO = 0
   
    keyChangedMap = {}

    for filename in files:
        f = open(path + filename, "r")
        while True:
            line = f.readline()
            if not line: break

            line = line.strip().split()

            total += 1
            
            results = line[3:8]
            timeline = line[8:]
                
            results = [int(result) for result in results]
            
            # leaf cert changed
            if results[1] == 0:
                leafCertX += 1
            else:
                leafCertChanged += 1

                if results[3] == 0:
                    leafCertO_KeyX += 1
                else:
                    leafCertO_KeyO += 1
                    leafKeyChanged += 1

                    keyChangedMap[line[0]] = timeline


            # other cert changed
            if results[2] == 0:
                otherCertX += 1
            else:
                otherCertChanged += 1

                if results[4] == 0:
                    otherCertO_KeyX += 1
                else:
                    otherCertO_KeyO += 1
                    otherKeyChanged += 1

                    keyChangedMap[line[0]] = timeline

            if results[1] == 0 and results[2] == 0:
                certX += 1
            else:
                if results[3] == 0 and results[4] == 0:
                    certO_KeyX += 1
                else:
                    certO_KeyO += 1

        f.close()

    writeOutput(keyChangedMap)

    print("")
    #print("None:", none)
    print("Total Mail Server:", total)
    print("0) Total Cert/Key Stats")
    print("0.1.1) Cert Changed X:", certX, avg(certX, total))
    print("0.1.2) Cert Changed O | Key Changed X:", certO_KeyX, avg(certO_KeyX, total))
    print("0.1.3) Cert Changed O | Key Changed O:", certO_KeyO, avg(certO_KeyO, total))
    print("")
    print("1) Leaf Cert/Key Stats")
    print("1.1.1) Cert Changed X:", leafCertX, avg(leafCertX, total))
    print("1.1.2) Cert Changed O | Key Changed X:", leafCertO_KeyX, avg(leafCertO_KeyX, total))
    print("1.1.3) Cert Changed O | Key Changed O:", leafCertO_KeyO, avg(leafCertO_KeyO, total))
    print("")
    print("2) Other Cert/Key Stats")
    print("2.1.1) Cert Changed X:", otherCertX, avg(otherCertX, total))
    print("2.1.2) Cert Changed O | Key Changed X:", otherCertO_KeyX, avg(otherCertO_KeyX, total))
    print("2.1.3) Cert Changed O | Key Changed O:", otherCertO_KeyO, avg(otherCertO_KeyO, total))
    


if __name__ == "__main__":

    path = os.path.join(rollover_cand_input_path, "rollover_cand_output/")
    getStat(path)

