import os
import datetime

input_path = "/path/to/case_stat/"
output_path = "/path/to/output"


def getStat():
    path = os.path.join(input_path, "case_stat/")

    months = ["1907", "1908", "1909", "1910", "1911", "1912", "2001", "2002", "2003", "2004", "2005", "2006", "2007", "2008", "2009", "2010" ,"2011", "2012", "2101", "2102"]

    resultMap = {}
    for month in months:
        dir_path = os.path.join(path, "case_stat_" + month)
        files = os.listdir(dir_path)

        for filename in files:
            f = open(dir_path + "/" + filename, "r")

            while True:
                line = f.readline()
                if not line: break
                
                l = line.strip().split()
                
                if "20200222" in l[0]: continue
                if "20200223" in l[0]: continue

                time = l[0]
                #if "None" in time:
                #    continue

                results = l[5:]
                resultMap[time] = results

            f.close()

    f = open(os.path.join(output_path, "case-stat.txt"), "w")
    f.write("time,total_crawled_domain,total_wrong_domain,total_tlsa,total_wrong_tlsa,SO_total_domain,SO_wrong_domain,SO_total_tlsa,SO_wrong_tlsa,SSDO_total_domain,SSDO_wrong_domain,SSDO_total_tlsa,SSDO_wrong_tlsa,SSDS_total_domain,SSDS_wrong_domain,SSDS_total_tlsa,SSDS_wrong_tlsa\n")
    times = sorted(resultMap.keys(), key=lambda x: datetime.datetime.strptime(x, "%Y%m%d-%H")) 
    for time in times:
        f.write(time + "," + ",".join(resultMap[time]) + "\n")

    f.close()

if __name__ == "__main__":
    getStat()
