import os


dane_validation_input_path = "/path/to/dane_output_[month]"


def getNeverMatchedSet():
    months = ["1907", "1908", "1909", "1910", "1911", "1912", "2001", "2002", "2003", "2004", "2005", "2006", "2007", "2008", "2009", "2010", "2011", "2012", "2101", "2102"]

    total = set([])
    everValid = set([])
    for month in months:
        print(month)
        path = os.path.join(dane_validation_input_path, "dane_output_" + month)
        files_ = os.listdir(path)

        files = []
        for filename in files_:
            if filename.startswith("_") or filename.startswith("."):
                continue
            files.append(filename)

        for filename in files:
            f = open(os.path.join(path, filename), "r")
            while True:
                line = f.readline()
                if not line: break
                line = line.strip().split()

                results = line[10:]

                dnssec = line[8]

                mx = line[0]

                date = line[2]
                hour = line[3]

                time = date + " " + hour

                total.add(mx)
                if "0" in results or "1" in results or "5" in results or "6" in results or "7" in results:
                    everValid.add(mx)


            f.close()


    neverMatched = total - everValid
    f = open("never_matched.txt", "w")
    for dn in neverMatched:
        f.write(dn + "\n")
    f.close()

if __name__ == "__main__":

    getNeverMatchedSet()

