import os
import datetime


input_path = "/path/to/case_tlsa_stat/"
output_path = "/path/to/output"


def getStat():
    path = os.path.join(input_path, "case_tlsa_stat/")

    months = ["1907", "1908", "1909", "1910", "1911", "1912", "2001", "2002", "2003", "2004", "2005", "2006", "2007", "2008", "2009", "2010" ,"2011", "2012", "2101", "2102"]
   
    resultMap = {"MO": {}, "MSDO": {}, "MSDS": {}}
    for month in months:
        dir_path = os.path.join(path, "case_tlsa_stat_" + month)
        files = os.listdir(dir_path)

        for filename in files:
            f = open(dir_path + "/" + filename, "r")

            while True:
                line = f.readline()
                if not line: break
                
                l = line.strip().split()
                
                if l[0] == "20190711":
                    continue
                if l[0] == "20200222" or l[0] == "20200223":
                    continue
                if l[0] == "20200713":
                    continue

                time = l[0] + "-" + l[1]
                case = l[2]

                resultMap[case][time] = ",".join(l[3:])
            f.close()

    cases = resultMap.keys()

    for case in cases:
        if case == "MO":
            new_case = "SO"
        elif case == "MSDO":
            new_case = "SSDO"
        elif case == "MSDS":
            new_case = "SSDS"
        else:
            new_case = case

        f = open(os.path.join(output_path, "case-tlsa-stat-" + new_case + ".txt"), "w")
        f.write("#time,total_tlsa,no_cert,no_tlsa,invalid_tlsa,dnssec,insecure,bogus,ds_only,unmatch,usage,selector,matching_type,undefined,unknown,chain,ever_matched,antago_invalid,antago_dnssec,antago_unmatch,antago_chain,syix_invalid,syix_dnssec,syix_unmatch,syix_chain\n")
        
        times = sorted(resultMap[case].keys(), key=lambda x: datetime.datetime.strptime(x, "%Y%m%d-%H")) 
        for time in times:
            f.write(time + "," + resultMap[case][time] + "\n")

        f.close()


if __name__ == "__main__":
    getStat()
