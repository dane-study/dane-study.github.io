import os


input_path = "/path/to/mx_dn_serving_210212_14/"
output_path = "/path/to/output" 


def writeStat(stat, fn):

    keys = sorted(stat.keys(), key=lambda x: int(x))
    num = 0
    for key in keys:
        num += len(stat[key][1])

    aggr = 0
    f = open(os.path.join(output_path, fn), "w")
    for key in keys:
        ratio = 100*len(stat[key][1])/num
        aggr += ratio
        f.write(key + ","  + str(ratio) + "," + str(aggr) + "\n")
    f.close()


def getStat():
    path = os.path.join(input_path, "mx_dn_serving_210212_14/")
    files_ = os.listdir(path)
    files = []
    for f in files_:
        if f.startswith("."):
            continue
        files.append(f)

    totalBin = {}
    validBin = {}
    invalidBin = {}
    notCrawledBin = {}

    for filename in files:
        f = open(os.path.join(path, filename), "r")

        while True:
            line = f.readline()
            if not line: break

            line = line.strip().split()
            mx = line[0]

            num = line[2]
            domains = line[3:]
            

            if not line[1] == "NoData":
                if num in totalBin:
                    totalBin[num][0].add(mx)
                    totalBin[num][1].update(domains)
                else:
                    totalBin[num] = [set([mx]), set(domains)]

            if line[1] == "Invalid":
                if num in invalidBin:
                    invalidBin[num][0].add(mx)
                    invalidBin[num][1].update(domains)
                else:
                    invalidBin[num] = [set([mx]), set(domains)]

            elif line[1] == "Valid":
                if num in validBin:
                    validBin[num][0].add(mx)
                    validBin[num][1].update(domains)
                else:
                    validBin[num] = [set([mx]), set(domains)]

            elif line[1] == "NoData":
                if num in notCrawledBin:
                    notCrawledBin[num][0].add(mx)
                    notCrawledBin[num][1].update(domains)
                else:
                    notCrawledBin[num] = [set([mx]), set(domains)]

            else:
                print("Type error")
                print(line)
                input()

        f.close()

    #writeStat(totalBin, "mx-dn-popularity.txt")
    writeStat(invalidBin, "mx-dn-invalid-serving-stat.txt")
    writeStat(validBin, "mx-dn-valid-serving-stat.txt")
   

if __name__ == "__main__":
    getStat()
    
