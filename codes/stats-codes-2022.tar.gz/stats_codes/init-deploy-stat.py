#!/usr/bin/python3
import os
import dns as mydns
import dns.message as mymessage
from OpenSSL import crypto
import json
import base64


init_deploy_input_path = "/path/to/init_deploy/"
incorrect_input_path = "/path/to/incorrect_output_[month]"


initDeployed = {}
initStat = {"total":[], "1217":[], "nodata":[], "correct":[], "insecure":[], "bogus":[], "undefined":[], "wrong_fields":[], "unknown":[], "chain":[]}
X3 = "7fdce3bf4103c2684b3adbb5792884bd45c75094c217788863950346f79c90a3"

def usingX3(raw):
    msg = base64.b64decode(raw)
    msg = mymessage.from_wire(msg)
    rrsetList = []
    for answer in msg.answer:
        if answer.rdtype == 52:
            rrsetList = rrsetList + [data.to_text() for data in answer]

    for rrset in rrsetList:
        if X3 in rrset.lower():
            return True
    return False


def checkUnknownSet(unknownSet):

    print(len(unknownSet))
    leLeaf = 0
    x3 = 0
    for d in unknownSet:
        useX3 = usingX3(d["tlsa"])
        if not useX3: continue

        x3 += 1
        certs = d["certs"]
        leaf = certs[0]
        
        crt = base64.b64decode(leaf)
        crt = crypto.load_certificate(crypto.FILETYPE_PEM, crt)
        issuer = crt.get_issuer()
        if issuer == None or issuer.O == None: continue

        if issuer.O == "Let's Encrypt":
            leLeaf += 1


    print(leLeaf)
    print(x3)


def checkInitDeployment():
    global initStat
    
    unknownSet = []
    months = ["1909", "1910", "1911", "1912", "2001", "2002", "2003", "2004", "2005", "2006", "2007", "2008", "2009", "2010", "2011", "2012", "2101", "2102"]
    for month in months:
        path = os.path.join(incorrect_input_path, "incorrect_output_" + month + "/")
        files = os.listdir(path)
        print(month)
        for filename in files:
            f = open(path + filename, "r")
            while True:
                line = f.readline()
                if not line: break
                line = line.strip().split()
                
                time = line[2] + " " + line[3]
                if not time in initDeployed:
                    continue

                mxs = initDeployed[time].keys()
                
                mx = line[0]
                if mx in mxs:
                    if line[4] == "Correct":
                        initStat["correct"].append(mx)
                    else:
                        dnssec = line[4]
                        chain = line[5]
                        matching = line[6]

                        if dnssec == "Insecure":
                            initStat["insecure"].append(mx)
                        elif dnssec == "Bogus":
                            initStat["bogus"].append(mx)

                        if chain == "WrongChain":
                            initStat["chain"].append(mx)

                        if matching == "WeirdField":
                            initStat["undefined"].append(mx)
                        elif matching == "OtherReason":
                            initStat["wrong_fields"].append(mx)
                        elif matching == "NoCase":
                            initStat["unknown"].append(mx)
                            unknownSet.append(initDeployed[time][mx])

            f.close()
        
    print("Newly appeared:", len(initStat["total"]))
    keys = initStat.keys()
    for key in keys:
        print(key, len(initStat[key]))

    checkUnknownSet(unknownSet)


def getInitDeployed():
    global initDeployed
    global initStat

    path = os.path.join(init_deploy_input_path, "init_deploy/")
    files = os.listdir(path)
    for filename in files:
        f = open(path + filename, "r")
        while True:
            line = f.readline()
            if not line: break

            l = json.loads(line)
            mx = l["mx"]
            time = l["time"]
            initStat["total"].append(mx)
            if time == "20201217 1":
                initStat["1217"].append(mx)
                continue
            if l["tlsa"] == "NoData" or l["certs"] == "NoData":
                initStat["nodata"].append(mx)
                continue

            if not time in initDeployed:
                initDeployed[time] = {}

            initDeployed[time][mx] = l
        f.close()
    print("AAA")

if __name__ == "__main__":
    getInitDeployed()
    checkInitDeployment()
