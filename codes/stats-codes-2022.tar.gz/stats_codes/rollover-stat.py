import datetime
import os


rollover_input_path = "/path/to/rollover_output/"
antago_syix_mx_input_path = "/path/to/antago_syix_mx/"
rollover_candidate_input_path = "/path/to/keyChangedDn.txt"


antagoMx = set([])
candList = []

def getUsageStats(domain, results):

    stats = {"num":0, "NoData":0, "ShortTTL":0, "wrong":0, "correct":0, "NotRollover":0}

    usages = set([])
    for result in results:
        stats["num"] += 1

        if result == "NoData" or result == "ShortTTL":
            stats[result] += 1
            continue

        result = result.split("/")
        usage = result[0]

        if not usage in stats:
            stats[usage] = {"num":0, "NotRollover":0, "NotMatchedBefore":0, "wrong":0, "earlyRetract":0, "btw":0, "afterUpdate":0, "afterNotUpdate":0, "same":0, "correct":0}
            usages.add(usage)
            
        depth = result[1]
        case = result[2]
        
        stats[usage]["num"] += 1

        if case == "UnmatchBefore":
            stats[usage]["NotMatchedBefore"] += 1
            continue

        elif case == "NotRollover":
            stats["NotRollover"] += 1
            stats[usage]["NotRollover"] += 1
            continue

        elif case == "Correct":
            stats["correct"] += 1
            stats[usage]["correct"] += 1
            continue

        elif case == "Wrong":
            stats["wrong"] += 1
            stats[usage]["wrong"] += 1
            wrongCase = result[3]
            if wrongCase == "a":
                stats[usage]["earlyRetract"] += 1
            elif wrongCase == "b":
                if result[5] == "NotMatched":
                    stats[usage]["afterNotUpdate"] += 1
                else:
                    stats[usage]["afterUpdate"] += 1
            elif wrongCase == "c":
                stats[usage]["same"] += 1
            elif wrongCase == "d":
                stats[usage]["earlyRetract"] += 1
            elif wrongCase == "e":
                if result[5] == "NotMatched":
                    stats[usage]["afterNotUpdate"] += 1
                else:
                    stats[usage]["afterUpdate"] += 1
            elif wrongCase == "thres":
                thresCase = result[5]
                if thresCase == "NotMatched":
                    stats[usage]["afterNotUpdate"] += 1
                elif thresCase == "Between":
                    stats[usage]["btw"] += 1
                elif thresCase == "SameTime":
                    stats[usage]["same"] += 1
                elif thresCase == "After":
                    stats[usage]["afterUpdate"] += 1
                else:
                    print("thresCase Error!!!!!!!!!!!!!")
                    print(thresCase)
                    print(results)
                    input()
            else:
                print("wrongCase Error!!!!!!!!!!!!!")
                print(wrongCase)
                print(results)
                input()
        else:
            print("case Error!!!!!!!!!!!!!")
            print(case)
            print(resutls)
            input()

    return stats, usages


def filterResult(data):
    
    returns = set([])
    for d in data:
        if "NoData" in d or "ShortTTL" in d:
            returns.add(d.split("/")[0])
        else:
            returns.add(d)

    return returns


def getRolloverStat():
    
    path = path.join(rollover_input_path, "rollover_output/")
    files = os.listdir(path)

    resultMap = {"total":0, "NotTarget":0, "NeverMatched":0, "NoData":0, "ShortTTL":0, "NotRollover":0}

    wholeUsages = set([])
    cannotKnowMX = set([])

    targetMX = set([])

    for filename in files:
        if filename[0] == ".":
            continue
        f = open(path + filename, "r")
        while True:
            line = f.readline()
            if not line: break

            line = line.strip()

            if line[0] in antagoMx:
                print(line)
                input()

            if"ERROR/" in line:
                print("Error!!!!!!!!!!!!!!!!!")
                print(line)
                input()

            line = line.split(" ")

            if len(line) < 2:
                print(line)
                input()

            if line[1] == "NotTarget":
                resultMap[line[1]] += 1
                continue

            if not line[0] in candList:
                continue

            resultMap["total"] += 1
            if line[1] == "NeverMatched":
                resultMap[line[1]] += 1
                continue

            mx = line[0]
            
            #results = set(line[1:])
            results = filterResult(line[1:])

            if len(results) == 1:
                if "NoData" in results:
                    resultMap["NoData"] += 1
                    continue
                if "ShortTTL" in results:
                    resultMap["ShortTTL"] += 1
                    continue
            if len(results) == 2:
                if "NoData" in results and "ShortTTL" in results:
                    resultMap["ShortTTL"] += 1
                    continue
            
            usageStat, usages = getUsageStats(mx, results)
            
            flag = False
            for usage in usages:
                if usageStat[usage]["num"] > 0:
                    if usageStat[usage]["num"] == usageStat[usage]["NotMatchedBefore"]:
                        resultMap["NeverMatched"] += 1
                        flag = True
                        break
                    elif usageStat[usage]["num"] == usageStat[usage]["NotRollover"]:
                        resultMap["NotRollover"] += 1
                        flag = True
                        break
                    elif usageStat[usage]["wrong"] == 0 and usageStat[usage]["correct"] > 0:
                        if usageStat["ShortTTL"] > 0:
                            resultMap["ShortTTL"] += 1
                            flag = True
                            break
                        if usageStat["NoData"] > 0:
                            resultMap["NoData"] += 1
                            flag = True
                            break
                    elif usageStat[usage]["num"] == (usageStat[usage]["NotRollover"] + usageStat[usage]["NotMatchedBefore"]):
                        if usageStat[usage]["NotRollover"] > 0:
                            resultMap["NotRollover"] += 1
                            flag = True
                            break
                        else:
                            resultMap["NeverMatached"] += 1
                            flag = True
                            break

            if flag:
                continue

            targetMX.add(mx)
            wholeUsages.update(usages)
            
            for usage in usages:
                if not usage in resultMap:
                    resultMap[usage] = {"num":0, "NoData":0, "NotRollover":0, "NotMatchedBefore":0, "wrong":0, "earlyRetract":0, "btw":0, "afterUpdate":0,  "afterNotUpdate":0, "same":0, "correct":0}
                if usageStat[usage]["num"] > 0:
                    resultMap[usage]["num"] += 1
                    if usageStat[usage]["wrong"] == 0 and usageStat[usage]["correct"] > 0:
                        if usageStat["NoData"] == 0 and usageStat["ShortTTL"] == 0:
                            resultMap[usage]["correct"] += 1
                    elif usageStat[usage]["wrong"] > 0:
                        resultMap[usage]["wrong"] += 1
                        if usageStat[usage]["earlyRetract"] > 0:
                            resultMap[usage]["earlyRetract"] += 1
                        if usageStat[usage]["btw"] > 0:
                            resultMap[usage]["btw"] += 1
                        if usageStat[usage]["afterUpdate"] > 0:
                            resultMap[usage]["afterUpdate"] += 1
                        if usageStat[usage]["afterNotUpdate"] > 0:
                            resultMap[usage]["afterNotUpdate"] += 1
                        if usageStat[usage]["same"] > 0:
                            resultMap[usage]["same"] += 1

                        if usageStat[usage]["wrong"] > 0 and usageStat[usage]["earlyRetract"] == 0 and usageStat[usage]["btw"] == 0 and usageStat[usage]["afterUpdate"] == 0 and usageStat[usage]["afterNotUpdate"] == 0 and usageStat[usage]["same"] == 0:
                            print("Something Wrong!!")
                            print(usageStat)
                            input()
                    else:
                        print("Something Wrong2!!")
                        print(usage)
                        print(usageStat)
                        input()

        f.close()

    keys = list(resultMap.keys())
    for usage in wholeUsages:
        keys.remove(usage)
    
    for key in keys:
        print("-", key, resultMap[key])
    print("- Target", len(targetMX))
    print("")
    for usage in wholeUsages:
        print("- Usage:", usage)
        print(resultMap[usage])

    
    f = open("rollover-actual-targets.txt", "w")
    for mx in targetMX:
        f.write(mx + "\n")
    f.close()

def readCand():
    global candList

    f = open(os.path.join(rollover_candidate_input_path, "keyChangedDn.txt"), "r")
    while True:
        line = f.readline()
        if not line: break

        line = line.strip().split()
        candList.append(line[0])

    f.close()


def getAntagonist():
    path = os.path.join(antago_syix_mx_input_path, "antago_syix_mx/")
    files = os.listdir(path)
    for filename in files:
        f = open(path + filename, "r")
        while True:
            line = f.readline()
            if not line: break
            line = line.strip().split()
            
            if line[-1] == "Antagonist":
                #mxs.add(line[0])
                antagoMx.add(line[0])
        f.close()



if __name__ == "__main__":
    getAntagonist()
    readCand()
    getRolloverStat()
