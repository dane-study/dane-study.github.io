import os
import datetime


input_path = "/path/to/cert_pki_cn_stat/"
output_path = "/path/to/output"


def mergeStat():
    path = os.path.join(input_path, "cert_pki_cn_stat/")
    files = os.listdir(cert_pki_cn_stat)

    statMap = {}
    for filename in files:
        if filename.startswith("."): continue
        with open(path + filename, "r") as f:
            while True:
                line = f.readline()
                if not line: break

                line = line.strip().split()

                statMap[line[0]] = line[1:]


    times = sorted(statMap.keys(), key = lambda x: datetime.datetime.strptime(x, "%Y%m%d-%H"))
    f = open(os.path.join(output_path, "cert-pki-cn-stat.txt"), "w")
    f.write("#time,total,noData,caCerts,useLE,X1,X3,E1,R3,total_wo_anta,noData_wo_anta,caCerts_wo_anta,useLE_wo_anta,X1_wo_anta,X3_wo_anta,E1_wo_anta,R3_wo_anta\n")    
    for time in times:
        f.write(time  + "," + ",".join(statMap[time]) + "\n")

    f.close()


if __name__ == "__main__":
    mergeStat()
