#!/usr/bin/python3
from pyspark import SparkContext, StorageLevel

import sys, os
import dns as mydns
import dns.message as mymessage
import base64
from OpenSSL import crypto
import hashlib
import json
import re
import subprocess
import struct
import time
import random
import shutil
import datetime
from os import listdir


chain_path = "chain_output_virginia/" # path to chain validation result (output of chain-validation.py), ex) /home/ubuntu/results/chain_output_virginia/
dependency_path = "dependencies.zip" # path to 'dependencies.zip'
input_path = "" # ex) /user/hadoop/data/virginia
output_path = "" # ex) /user/hadoop/superfluous_output_virgina


cert_path = '/etc/ssl/certs/' # Path of root CA certificates in Ubuntu 
make_name_size = 2**16 - 1
root_certs = {}
chainMap = {}

def make_name():
    global make_name_size
    return struct.pack(">dHH", time.time(), random.randint(0, make_name_size), os.getpid()).hex()

def tojson(line):
    return json.loads(line)

def toCSV(data):
    return " ".join(str(d) for d in data)

def tlsaCrawled(d):
    return int ('tlsa' in d)

def dnssec(d):
    '''    
    #Return
    -1: None (TLSA is not crawled)
    0: Secure
    1: Insecure
    2: Bogus
    -1000: Wrong value
    '''

    if 'tlsa' in d:
        dnssec = d['tlsa']['dnssec']
        if dnssec == "Secure":
            return 0
        elif dnssec == "Insecure":
            return 1
        elif dnssec == "Bogus":
            return 2
        else:
            return -1000
    return -1

def starttlsCrawled(d):
    return int ('certs' in d['starttls'])

def getStarttlsErr(d):
    '''
    #Return
    -1: None (STARTTLS certificate is not cralwed)
    0: Error Code 4
    1: Error Code 5
    2: Connection related Error
    '''

    if 'why_fail' in d['starttls']:
        connErrors = ["tls:", "read", "EOF", "dial", "write", "remote", "short", "250"]
        
        error = d['starttls']['why_fail'].split()[0]
        if error[0] == "4":
            return 0
        elif error[0] == "5":
            return 1
        else:
            return 2
    return -1

def parseTLSA(raw):
    msg = base64.b64decode(raw)
    msg = mymessage.from_wire(msg)
    rrsetList = []

    for answer in msg.answer:
        if answer.rdtype == 52:
            rrsetList = rrsetList + [data.to_text() for data in answer]
    return rrsetList

def matchCrt(matching, data, crt):
    from OpenSSL import crypto
    
    if matching == '0':
        crt = crypto.load_certificate(crypto.FILETYPE_ASN1, crt)
        hashed = crypto.dump_certificate(crypto.FILETYPE_PEM, crt).lower().decode()
        hashed = hashed.replace('-----begin certificate-----', '').replace('-----end certificate-----', '').replace('\n', '').lower()
        data = data.replace('-----begin certificate-----', '').replace('-----end certificate-----', '').replace('\n', '').lower()
    elif matching == '1':
        data = data.lower()
        hashed = hashlib.sha256(crt).hexdigest()
    elif matching == '2':
        data = data.lower()
        hashed = hashlib.sha512(crt).hexdigest()
    else:
        return False, "Matching-"+matching

    if hashed == data:
        return True, None
    return False, "CrtNotMatch"

def matchKey(matching, data, key):
    from OpenSSL import crypto
    if matching == '0':
        hashed = crypto.load_publickey(crypto.FILETYPE_ASN1, key)
        hashed = crypto.dump_publickey(crypto.FILETYPE_PEM, hashed).lower().decode()
        hashed = hashed.replace('-----begin public key-----', '').replace('-----end public key-----', '').replace('\n', '').lower()
        data = data.replace('-----begin public key-----', '').replace('-----end public key-----', '').replace('\n', '').lower()
    elif matching == '1':
        data = data.lower()
        hashed = hashlib.sha256(key).hexdigest()
    elif matching == '2':
        data = data.lower()
        hashed = hashlib.sha512(key).hexdigest()
    else:
        return False, "Matching-"+matching

    if hashed == data:
        return True, None
    return False, "KeyNotMatch"

def checkValidity(periods, time):
    currTime = datetime.datetime.strptime(time, "%Y%m%d %H:%M:%S")
    for period in periods:
        notBefore = datetime.datetime.strptime(period[0], "%Y%m%d-%H")
        notAfter = datetime.datetime.strptime(period[1], "%Y%m%d-%H")

        if currTime < notBefore:
            return False
        if currTime > notAfter:
            return False

    return True

def chainValid(usage, time, certs):

    hashList = []
    for crt in certs:
        pem = base64.b64decode(crt)
        hashed = hashlib.sha256(pem).hexdigest()
        hashList.append(hashed)
    key = tuple(hashList)

    if usage == '0' or usage == '1':
        if key in chainMap:
            validity = checkValidity(chainMap[key]['periods'], time)
            if validity:
                return chainMap[key]['usage0'], None
            else:
                return False, "InvalidTime"
        else:
            return None, "NoKey"

    elif usage == '2':
        if len(certs) == 1:
            return False, "NoChain"
        else:
            if key in chainMap:
                validity = checkValidity(chainMap[key]['periods'], time)
                if validity:
                    return chainMap[key]['usage2'], None
                else:
                    return False, "InvalidTime"
            else:
                return None, "NoKey" 
    else:
        return False, "WrongUsage"
    
def findRoot(cert):
    from OpenSSL import crypto
    crt = base64.b64decode(cert)
    crt = crypto.load_certificate(crypto.FILETYPE_PEM, crt)
    issuer = crt.get_issuer()

    if issuer == None:
        return None

    roots = set(root_certs.keys())

    if issuer.CN in roots:
        root = base64.b64encode(root_certs[issuer.CN].encode())
        return root
    return None

def isRoot(cert):
    from OpenSSL import crypto
    crt = base64.b64decode(cert)
    crt = crypto.load_certificate(crypto.FILETYPE_PEM, crt)
    issuer = crt.get_issuer()
    subject = crt.get_subject()
    
    if issuer == None or subject == None:
        return False

    if issuer.CN == subject.CN:
        return True
    return False

def unitValidate(record, time, certs):

    from OpenSSL import crypto

    record = record.split()
    if len(record) != 4:
        record = record[:3] + [''.join(record[3:])]
    usage = record[0]
    selector = record[1]
    matching = record[2]
    data = record[3]
  
    error = None
    chain = "Empty"
    if usage == '1' or usage == '3':
        
        pem = base64.b64decode(certs[0])
        crt = crypto.load_certificate(crypto.FILETYPE_PEM, pem)
        # use entire certificate
        if selector == '0':
            crt = crypto.dump_certificate(crypto.FILETYPE_ASN1, crt)
            matched, error = matchCrt(matching, data, crt)
            if usage == '1':
                chain, error = chainValid(usage, time, certs)
                if error == "NoKey":
                    chain = "NoKey"
            return matched, chain, error

        # use public key
        elif selector == '1':
            pubKey = crt.get_pubkey()
            pubKey = crypto.dump_publickey(crypto.FILETYPE_ASN1, pubKey)
            matched, error = matchKey(matching, data, pubKey)
            if usage == '1':
                chain, error = chainValid(usage, time, certs)
                if error == "NoKey":
                    chain = "NoKey"
            return matched, chain, error
        else:
            return False, chain, "Selector-"+selector
    elif usage == '0':
        if isRoot(certs[-1]):
            tmpCerts = certs
        else:
            root = findRoot(certs[-1])
            if root == None:
                tmpCerts = certs
            else:
                tmpCerts = certs + [root]
        for cert in tmpCerts[1:]:
            pem = base64.b64decode(cert)
            crt = crypto.load_certificate(crypto.FILETYPE_PEM, pem)

            chain, error = chainValid(usage, time, certs)
            if error == "NoKey":
                chain = "NoKey"
            if selector == '0':
                crt = crypto.dump_certificate(crypto.FILETYPE_ASN1, crt)
                matched, error = matchCrt(matching, data, crt)
                if matched:
                    return matched, chain, error
            elif selector == '1':
                pubKey = crt.get_pubkey()
                pubKey = crypto.dump_publickey(crypto.FILETYPE_ASN1, pubKey)
                matched, error = matchKey(matching, data, pubKey)
                if matched:
                    return matched, chain, error
            else:
                return False, chain, "Selector-"+selctor
    
        return False, chain, error
    elif usage == '2':

        pem = base64.b64decode(certs[-1])
        crt = crypto.load_certificate(crypto.FILETYPE_PEM, pem)

        chain, error = chainValid(usage, time, certs)
        if error == "NoKey":
            chain = "NoKey"

        # use entire certificate
        if selector == '0':
            crt = crypto.dump_certificate(crypto.FILETYPE_ASN1, crt)
            matched, error = matchCrt(matching, data, crt)
            return matched, chain, error
        elif selector == '1':
            pubKey = crt.get_pubkey()
            pubKey = crypto.dump_publickey(crypto.FILETYPE_ASN1, pubKey)
            matched, error = matchKey(matching, data, pubKey)
            return matched, chain, error
        else:
            return False, chain, "Selector-"+selector
    else:
        return False, False, "Usage-"+usage

def resultCase(dnssecRaw, matched, chain):
    if dnssecRaw == "Secure":
        dnssec = True
    else:
        dnssec = False

    if dnssec:
        if matched:
            if chain: return 0
            elif chain == None: return 0
            else: return 1
        else:
            if chain: return 2
            elif chain == None: return 3
            else: return 4
    else:
        if matched:
            if chain: return 5
            elif chain == None: return 6
            else: return 7
        else:
            if chain: return 8
            elif chain == None: return 9
            else: return 10


def daneValid(d):
    from OpenSSL import crypto

    '''
    #Return
    -1: TLSA record does not exist
    -2: STARTTLS cert does not exist
    '''

    if not ('tlsa' in d):
        return (d['domain']+":"+d['port'], d['time'], None)
    if not ('certs' in d['starttls']):
        return (d['domain']+":"+d['port'], d['time'], None)

    dnssec = d['tlsa']['dnssec']
    records = parseTLSA(d['tlsa']['record_raw'])
    time = d['time']+":01:00"

    
    resultList = []
    for record in records:
        matched, chain, error = unitValidate(record, time, d['starttls']['certs'])
        result = resultCase(dnssec, matched, chain)
        resultList.append(str(result))


    if chain == "NoKey":
        return (d['domain'] +":" + d['port'], d['time'], "ChainNone")
    
    if "0" in resultList:
        return (d['domain']+":"+d['port'], d['time'], d)
    return (d['domain']+":"+d['port'], d['time'], None)

def dnskeyExist(d):
    '''
    #Return
    -1: None (DNSSEC is not Insecure)
    0: DNSKEY does not exist
    1: DNSKEY exist
    '''
    
    if not ('tlsa' in d):
        return -1
    if not (d['tlsa']['dnssec'] == "Insecure"):
        return -1

    msg = base64.b64decode(d['tlsa']['record_raw'])
    msg = mymessage.from_wire(msg)
    raw = msg.to_text()

    dn = d['domain']
    query = dn + " .* RRSIG TLSA .*"
    exist = re.search(query, raw)
    if exist:
        return 1

    query = dn + " .* CNAME .*"
    exist = re.search(query, raw)
    if exit:
        query2 = dn + " .* RRSIG CNAME .*"
        exist2 = re.search(query2, raw)
        if exist2:
            return 1
    
    return 0

def getUsages(raw):
    msg = base64.b64decode(raw)
    msg = mymessage.from_wire(msg)
    usageSet = set([])

    for answer in msg.answer:
        if answer.rdtype == 52:
            for data in answer:
                usage = data.to_text().split()[0]
                usageSet.add(usage)
    return list(usageSet)

def isValidCerts(time, certs):
    hashList = []
    for crt in certs:
        pem = base64.b64decode(crt)
        hashed = hashlib.sha256(pem).hexdigest()
        hashList.append(hashed)
    key = tuple(hashList)

    certLen = str(len(certs))

    if key in chainMap:
        validity = checkValidity(chainMap[key]['periods'], time)
        if validity:
            return chainMap[key]['usage0'], certLen #+ " " + str(key) + " " + str(chainMap[key])
        else:
            return False, "Expired"
    else:
        return False, "NoKey"

def isPKIXCerts(time, certs):
    
    cert = base64.b64decode(certs[-1]).decode()

    roots = set(root_certs.values())
    if cert in roots:
        return True, "0"

    hashList = []
    for crt in certs:
        pem = base64.b64decode(crt)
        hashed = hashlib.sha256(pem).hexdigest()
        hashList.append(hashed)
    key = tuple(hashList)

    if key in chainMap:
        validity = checkValidity(chainMap[key]['periods'],time)
        if validity:
            return chainMap[key]['usage0'], "1"
        else:
            return False, "Expired"
    else:
        return False, "NoKey"


def superfluousChain(d):
    dn = d[0]
    time = d[1]
    data = d[2]
    if data == None:
        return dn + " " + time + " NotTarget"
    if data == "ChainNone":
        return dn + " " + time + " " + data

    usages = getUsages(data['tlsa']['record_raw'])

    if len(usages) == 1:
        if "3" in usages:
            valid, case = isValidCerts(data['time']+":01:00", data['starttls']['certs'])

            if not valid:
                return dn + " " + time + " notPKIXvalid"
            else:
                return dn  + " " + time + " isPKIXvalid " + case
        if "2" in usages:
            pkix, case = isPKIXCerts(data['time']+":01:00", data['starttls']['certs'])

            if not pkix:
                return dn + " " + time + " notPKIXchain2only " + case
            else:
                return dn + " " + time + " isPKIXchain2only " + case
        return dn + " " + time + " NoTarget"
    elif len(usages) == 2:
        if "2" in usages and "3" in usages:
            pkix, case = isPKIXCerts(data['time']+":01:00", data['starttls']['certs'])

            if not pkix:
                return dn + " " + time + " notPKIXchain23 " + case
            else:
                return dn + " " + time + " isPKIXchain23 " + case 
        return dn + " " + time + " NotTarget"
    else:
        return dn + " " + time + " NotTarget"

def getCerts(data):
    from OpenSSL import crypto

    def getCertRecord(certs):
        periodList = []
        for crt in certs:
            pem = base64.b64decode(crt)
            cert = crypto.load_certificate(crypto.FILETYPE_PEM, pem)
            notBefore = datetime.datetime.strptime(cert.get_notBefore().decode(), "%Y%m%d%H%M%SZ")
            notAfter = datetime.datetime.strptime(cert.get_notAfter().decode(), "%Y%m%d%H%M%SZ")
            
            periodList.append((notBefore, notAfter))

        return periodList

    if not 'certs' in data['starttls']:
        return {"name": "None"}

    certs = data['starttls']['certs']
    periodList = getCertRecord(certs)

    result = {"name":" ".join(certs), "certs":certs, "periods":periodList}

    return result


def initChainMap():
    global chainMap

    chainMap = {}
    '''
    keys = list(chainMap.keys())

    if not len(keys) == 0:
        for key in keys:
            del chainMap[key]
    '''

def getChains():
    global chainMap
    
    files = listdir(chain_path)
    if "_SUCCESS" in files:
        files.remove("_SUCCESS")

    initChainMap()

    for filename in files:
        f = open(os.path.join(chain_path, filename), "r")
        while True:
            line = f.readline()
            if not line: break
            line = line[:-1]
            
            if line == "None":
                continue
            line = line.split()
            
            data = line[:-2]
            if line[-2] == "True":
                usage0Result = True
            else:
                usage0Result = False
            if line[-1] == "True":
                usage2Result = True
            else:
                usage2Result = False
            
            certs = tuple(data[0::3])
            periods = list(zip(data[1::3], data[2::3]))
            if certs in chainMap:
                print("certExist!!!!")
                exit()
            else:
                chainMap[certs] = {"periods":periods, "usage0":bool(usage0Result), "usage2":bool(usage2Result)}
    
        f.close()

def getRootCerts():
    global root_certs

    files = listdir(cert_path)
    if "java" in files:
        files.remove("java")

    for filename in files:
        f = open(os.path.join(cert_path, filename), "r")
        cert = f.read()
        crt = crypto.load_certificate(crypto.FILETYPE_PEM, cert)
        issuer = crt.get_issuer().CN

        root_certs[issuer] = cert
        f.close()

def getStats(sc):

    def chainGroup(x):
        return x["name"]

    getRootCerts()

    # Load pre-validated chain results
    getChains()

    k = sc.textFile(input_path)\
            .map(tojson)\
            .map(daneValid)\
            .map(superfluousChain)        
    k.saveAsTextFile(output_path)


if __name__ == "__main__":
    sc = SparkContext(appName="DANE-RESEARCH-SUPERFLUOUS-CHAIN")
    sc.addPyFile(dependency_path)
    getStats(sc)
    sc.stop()

