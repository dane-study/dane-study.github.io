import os

input_path = "valid_dn_output_virginia/" # path to result of valid-dn.py, ex. /home/ubuntu/valid_dn_output_virginia/
output_path = "" # /home/ubuntu/valid-dn-stat-virginia.txt


def writeStat(dateMap):

    keys = list(dateMap.keys())
    keys = sorted(keys, key=lambda e: (e.split()[0], int(e.split()[1])))

    fOut = open(output_path, "w")
    fOut.write("time, total_com_dn, valid_com_dn, invalid_com_dn, total_org_dn, valid_org_dn, invalid_org_dn, total_net_dn, valid_net_dn, invalid_net_dn, total_nl_dn, valid_nl_dn, invalid_nl_dn, total_se_dn, valid_se_dn, invalid_se_dn\n")
    tlds = ["com", "org", "net", "nl", "se"]
    for key in keys:
        results = dateMap[key]
    
        output = key
        for tld in tlds:
            output = output + "," + str(results[tld][0]) + "," + str(results[tld][1]) + "," + str(results[tld][2])
        fOut.write(output + "\n")

    fOut.close()


def getStat():
    files = os.listdir(input_path)

    if "_SUCCESS" in files:
        files.remove("_SUCCESS")

    tlds = ["com", "org", "net", "nl", "se"]
    dateMap = {}
    valid = 0
    invalid = 0 
    for filename in files:
        f = open(os.path.join(input_path, filename), "r")
        while True:
            line = f.readline()
            if not line: break

            line = line[:-1]
            line = line.split()

            time = line[1] + " " + line[2]
            if not time in dateMap:
                dateMap[time] = {"com":[0, 0, 0], "org":[0, 0, 0], "net":[0, 0, 0], "nl":[0,0, 0], "se":[0,0, 0]}

            results = line[3:]
            if results == []:
                continue
            if line[3] == "NoData":
                continue
            it = iter(results)
            for x in it:
                tld = x
                isValid = next(it)
                num = int(next(it))

                dateMap[time][tld][0] += num
                if isValid == "1":
                    dateMap[time][tld][1] += num
                else:
                    dateMap[time][tld][2] += num
        f.close()
    writeStat(dateMap)

        
if __name__ == "__main__":

    getStat()
