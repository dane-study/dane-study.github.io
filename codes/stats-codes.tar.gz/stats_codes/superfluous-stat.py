import os
from os import listdir
import sys

input_path = "superfluous_output_virginia/" # path to results of superfluous.py, # ex. /home/ubuntu/superfluous_output_virginia/
output_path = "" # ex) /home/ubuntu/superfluous-stat-virginia.txt


def getStats():
    files = listdir(input_path)
    if "_SUCCESS" in files:
        files.remove("_SUCCESS")

    dateMap = {}

    for filename in files:
        f = open(os.path.join(input_path, filename), "r")
        while True:
            line = f.readline()
            if not line: break
            

            line = line[:-1]
            line = line.split()

            time = line[1] + " " + line[2]
            code = " ".join(line[3:])

            if "NoKey" in code:
                print(line)

            if code == 'isPKIXvalid 0':
                print(line)

            if "notPKIXchain2only" in code:
                code = "notPKIXchain2only"
            if "notPKIXchain23" in code:
                code = "notPKIXchain23"
            
            if "isPKIXvalid" in code:
                code = "isPKIXvalid N"

            if "NotTarget" in code or "NoTarget" in code:
                code = "NotTarget"
            
            if "isPKIXchain23":
                if "Expired" in code:
                    code = "isPKIXvalid23 1"

            if time in dateMap:
                dateMap[time]["total"] += 1
                dateMap[time][code] += 1
            else:
                dateMap[time] = {"total":1, "NotTarget":0, "isPKIXvalid N":0, "isPKIXvalid 0": 0, "notPKIXvalid":0, "isPKIXchain2only 0":0, "isPKIXchain2only 1":0, "notPKIXchain2only":0, "isPKIXchain23 0":0, "isPKIXchain23 1":0, "notPKIXchain23":0}
                dateMap[time][code] += 1

        f.close()
        
    keys = list(dateMap.keys())
    keys = sorted(keys, key=lambda e: (e.split()[0], int(e.split()[1])))

    fOut = open(output_path, "w")
    fOut.write("#time,notTarget,domainsUseOnlyUsage2,notPKIXValidChain,rootIsPKIXValid,interIsPKIXValid,domainsUseOnlyUsage3,notPKIXValid,PKIXvalid,domainsUseUsage2&3,notPKiXvalidChain,rootIsPKIXValid,interIsPKIXValid\n")
    for key in keys:
        data = dateMap[key]
        total3 = data['isPKIXvalid N'] + data["isPKIXvalid 0"] + data['notPKIXvalid']
        total2 = data['isPKIXchain2only 1'] + data['isPKIXchain2only 0'] + data['notPKIXchain2only']
        total23 = data['isPKIXchain23 1'] + data['isPKIXchain23 0'] + data['notPKIXchain23']

        fOut.write(key + "," + str(data['NotTarget']) + "," + str(total2) + "," + str(data['notPKIXchain2only']) + "," + str(data['isPKIXchain2only 0']) + "," + str(data['isPKIXchain2only 1']) + "," + str(total3) + "," + str(data['notPKIXvalid']) + "," + str(data['isPKIXvalid N']) + "," + str(total23) + "," + str(data['notPKIXchain23']) + "," + str(data['isPKIXchain23 0']) + "," + str(data['isPKIXchain23 1']) + "\n")
    fOut.close()


def getAverage():
    fIn = open(output_path, "r")

    ee_ratio = 0.0
    ta_ratio = 0.0
    count = 0
    fIn.readline()
    while True:
        line = fIn.readline()
        if not line: break
        line = line[:-1]
        line = line.split(",")
        count += 1
        ee_tmp = 100*int(line[8]) / int(line[6])
        ta_tmp = 100*(int(line[4]) + int(line[5])) / int(line[2])

        ee_ratio += ee_tmp
        ta_ratio += ta_tmp

    print("superfluous DANE-EE:", round(ee_ratio / count, 2), "%")
    print("superfluous DANE-TA:", round(ta_ratio / count, 2), "%")

    fIn.close()

if __name__ == "__main__":
    getStats()
    getAverage()

