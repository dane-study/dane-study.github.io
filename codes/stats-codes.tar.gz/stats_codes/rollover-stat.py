import os
import datetime

input_path = "" # path to result of rollover.py, ex. /home/ubuntu/rollover_output_virginia/


if __name__ == "__main__":
    files = os.listdir(input_path)

    usage0 = 0
    usage1 = 0

    total = 0
    notTarget = 0
    ShortTTL = 0
    CannotKnow = 0
    NotRollover = 0
    AllTimeGood = 0
    AllTimeGood_0 = 0
    AllTimeGood_1 = 0
    Bad = 0
    Bad_0 = 0
    Bad_1 = 0

    NewKeyInvalid = 0
    NewKeyInvalid_0 = 0
    NewKeyInvalid_1 = 0
    OldKeyInvalid = 0
    OldKeyInvalid_0 = 0
    OldKeyInvalid_1 = 0
    BothKeyInvalid = 0
    BothKeyInvalid_0 = 0
    BothKeyInvalid_1 = 0
    NewKeyInvalidOldKeyUnknown = 0
    NewKeyInvalidOldKeyUnknown_0 = 0
    NewKeyInvalidOldKeyUnknown_1 = 0
    NewKeyUnknownOldKeyInvalid = 0
    NewKeyUnknownOldKeyInvalid_0 = 0
    NewKeyUnknownOldKeyInvalid_1 = 0

    NewKeyInvalidOldKeyUnknown_validSame = 0
    NewKeyInvalidOldKeyUnknown_validBtw = 0
    NewKeyInvalidOldKeyUnknown_validAfter = 0
    NewKeyInvalidOldKeyUnknown_validNone = 0
    
    NewKeyInvalid_validSame = 0
    NewKeyInvalid_validBtw = 0
    NewKeyInvalid_validAfter = 0
    NewKeyInvalid_validNone = 0

    NewKeyInvalidOldKeyUnknown_validSame_0 = 0
    NewKeyInvalidOldKeyUnknown_validBtw_0 = 0
    NewKeyInvalidOldKeyUnknown_validAfter_0 = 0
    NewKeyInvalidOldKeyUnknown_validNone_0 = 0
    
    NewKeyInvalid_validSame_0 = 0
    NewKeyInvalid_validBtw_0 = 0
    NewKeyInvalid_validAfter_0 = 0
    NewKeyInvalid_validNone_0 = 0

    NewKeyInvalidOldKeyUnknown_validSame_1 =0
    NewKeyInvalidOldKeyUnknown_validBtw_1 = 0
    NewKeyInvalidOldKeyUnknown_validAfter_1 = 0
    NewKeyInvalidOldKeyUnknown_validNone_1 = 0
    
    NewKeyInvalid_validSame_1 = 0
    NewKeyInvalid_validBtw_1 = 0
    NewKeyInvalid_validAfter_1 = 0
    NewKeyInvalid_validNone_1 = 0

    invalid_domains = set([])
    mixed_usage = []

    for filename in files:
        f = open(input_path + filename, "r")
        while True:
            line = f.readline()
            if not line: break

            line = line.split()
            dn = line[0]
            results = line[1:]
            total += 1

            if results[0] == "NotTarget":
                notTarget += 1
                continue
           
            usage0_tmp = 0
            usage1_tmp = 0
            AllTimeNoTLSA_tmp = 0
            ShortTTL_tmp = 0
            CannotKnowPreviousTLSA_tmp = 0
            CannotKnowAfterTLSA_tmp = 0
            WellRolloverOrNotRollover_tmp = 0
            NotRollover_tmp = 0
            SomethingWrong = 0
            BothValid_tmp = 0
            BothInvalid_tmp = 0
            NewKeyValidOldKeyUnknown_tmp = 0
            OldKeyInvalid_tmp = 0
            CannotKnow_tmp = 0
            NewKeyInvalid_tmp = 0
            NewKeyInvalidOldKeyUnknown_tmp = 0
            NewKeyUnknownOldKeyInvalid_tmp = 0
            NewKeyInvalid_tmp = 0

            NewKeyInvalidOldKeyUnknown_validSame_tmp = 0
            NewKeyInvalidOldKeyUnknown_validBtw_tmp = 0
            NewKeyInvalidOldKeyUnknown_validAfter_tmp = 0
            NewKeyInvalidOldKeyUnknown_validNone_tmp = 0

            NewKeyInvalid_validSame_tmp = 0
            NewKeyInvalid_validBtw_tmp = 0
            NewKeyInvalid_validAfter_tmp = 0
            NewKeyInvalid_validNone_tmp = 0

            for result in results:
                if result == "AllTimeNoTLSA":
                    AllTimeNoTLSA_tmp += 1
                elif result == "CannotKnowPreviousTLSA":
                    CannotKnowPreviousTLSA_tmp += 1
                elif "ShortTTL" in result:
                    ShortTTL_tmp += 1

                elif result[:2] == "0-":
                    tmpResult = result[2:]
                    if tmpResult == "CannotKnowPreviousTLSA":
                        CannotKnowPreviousTLSA_tmp += 1
                        continue
                    if tmpResult == "NewKeyValid/OldKeyUnknown-A":
                        NewKeyValidOldKeyUnknown_tmp += 1
                        continue
                    if tmpResult == "NotRollover":
                        NotRollover_tmp += 1
                        continue
                    if tmpResult == "CannotKnow":
                        CannotKnow_tmp += 1
                        continue
                    if "BothInvalid" in tmpResult:
                        BothInvalid_tmp += 1
                        continue

                    usage0_tmp += 1
                    if "SomethingWrong" in tmpResult:
                        SomethingWrong += 1
                        print("SomethingWrong")
                        print(line)
                        input()
                    elif "BothValid" in tmpResult:
                        BothValid_tmp += 1
                    elif tmpResult == "OldKeyInvalid":
                        OldKeyInvalid_tmp += 1
                    elif "NewKeyInvalid/OldKeyUnknown" in tmpResult:
                        NewKeyInvalidOldKeyUnknown_tmp += 1
                        timeSplit = tmpResult.split("-")
                        keyChanged = timeSplit[1]
                        thres = timeSplit[3]
                        valid = timeSplit[5]

                        if valid == "None":
                            NewKeyInvalidOldKeyUnknown_validNone_tmp += 1
                        else:
                            keyChangedTime = datetime.datetime.strptime(keyChanged, "%Y%m%d:%H")
                            thresTime = datetime.datetime.strptime(thres, "%Y%m%d:%H")
                            validTime = datetime.datetime.strptime(valid, "%Y%m%d:%H")

                            if validTime < keyChangedTime:
                                NewKeyInvalidOldKeyUnknown_validBtw_tmp += 1
                            elif validTime == keyChangedTime:
                                NewKeyInvalidOldKeyUnknown_validSame_tmp += 1
                                #print(validTime, keyChangedTime)
                                #print(line)
                                #print(tmpResult)
                                #input()
                            else:
                                NewKeyInvalidOldKeyUnknown_validAfter_tmp+= 1
                    elif tmpResult == "NewKeyUnknown/OldKeyInvalid":
                        NewKeyUnknownOldKeyInvalid_tmp += 1
                    elif "NewKeyInvalid" in tmpResult:
                        NewKeyInvalid_tmp += 1
                        timeSplit = tmpResult.split("-")
                        keyChanged = timeSplit[1]
                        thres = timeSplit[3]
                        valid = timeSplit[5]

                        if valid == "None":
                            NewKeyInvalid_validNone_tmp += 1
                        else:
                            keyChangedTime = datetime.datetime.strptime(keyChanged, "%Y%m%d:%H")
                            thresTime = datetime.datetime.strptime(thres, "%Y%m%d:%H")
                            validTime = datetime.datetime.strptime(valid, "%Y%m%d:%H")

                            if validTime < keyChangedTime:
                                NewKeyInvalid_validBtw_tmp += 1
                            elif validTime == keyChangedTime:
                                NewKeyInvalid_validSame_tmp += 1
                                #print(validTime, keyChangedTime)
                                #print(line)
                                #print(tmpResult)
                                #input()
                            else:
                                NewKeyInvalid_validAfter_tmp+= 1
                    else:
                        print("Wrong0")
                        print(line)
                        print(result)
                        input()

                elif result[:4] == "1-0-":
                    tmpResult = result[4:]
                    if tmpResult == "CannotKnowPreviousTLSA":
                        CannotKnowPreviousTLSA_tmp += 1
                        continue
                    if tmpResult == "NewKeyValid/OldKeyUnknown":
                        NewKeyValidOldKeyUnknown_tmp += 1
                        continue
                    if tmpResult == "NotRollover":
                        NotRollover_tmp += 1
                        continue
                    if tmpResult == "CannotKnow":
                        CannotKnow_tmp += 1
                        continue
                    if "BothInvalid" in tmpResult:
                        BothInvalid_tmp += 1
                        continue

                    usage1_tmp += 1
                    if "SomethingWrong" in tmpResult:
                        SomethingWrong += 1
                    elif "BothValid" in tmpResult:
                        BothValid_tmp += 1
                    elif tmpResult == "OldKeyInvalid":
                        OldKeyInvalid_tmp += 1
                    elif "NewKeyInvalid/OldKeyUnknown" in tmpResult:
                        NewKeyInvalidOldKeyUnknown_tmp += 1
                        keyChanged = timeSplit[1]
                        thres = timeSplit[3]
                        valid = timeSplit[5]

                        if valid == "None":
                            NewKeyInvalidOldKeyUnknown_validNone_tmp += 1
                        else:
                            keyChangedTime = datetime.datetime.strptime(keyChanged, "%Y%m%d:%H")
                            thresTime = datetime.datetime.strptime(thres, "%Y%m%d:%H")
                            validTime = datetime.datetime.strptime(valid, "%Y%m%d:%H")

                            if validTime < keyChangedTime:
                                NewKeyInvalidOldKeyUnknown_validBtw_tmp += 1
                            elif validTime == keyChangedTime:
                                NewKeyInvalidOldKeyUnknown_validSame_tmp += 1
                                #print(validTime, keyChangedTime)
                                #print(line)
                                #print(tmpResult)
                                #input()
                            else:
                                NewKeyInvalidOldKeyUnknown_validAfter_tmp+= 1
 
                    elif tmpResult == "NewKeyUnknown/OldKeyInvalid":
                        NewKeyUnknownOldKeyInvalid_tmp += 1
                    elif "NewKeyInvalid" in tmpResult:
                        NewKeyInvalid_tmp += 1
                        keyChanged = timeSplit[1]
                        thres = timeSplit[3]
                        valid = timeSplit[5]

                        if valid == "None":
                            NewKeyInvalid_validNone_tmp += 1
                        else:
                            keyChangedTime = datetime.datetime.strptime(keyChanged, "%Y%m%d:%H")
                            thresTime = datetime.datetime.strptime(thres, "%Y%m%d:%H")
                            validTime = datetime.datetime.strptime(valid, "%Y%m%d:%H")

                            if validTime < keyChangedTime:
                                NewKeyInvalid_validBtw_tmp += 1
                            elif validTime == keyChangedTime:
                                NewKeyInvalid_validSame_tmp += 1
                                #print("validTime == keyChagnedTime")
                                #print(line)
                                #print(tmpResult)
                                #input()
                            else:
                                NewKeyInvalid_validAfter_tmp+= 1
 
                    else:
                        print("Wrong1")
                        print(line)
                        #print(result)
                        print(tmpResult)
                        input()

                elif result[:2] == "1-":
                    tmpResult = result[2:]
                    if tmpResult == "CannotKnowAfterTLSA":
                        CannotKnowAfterTLSA_tmp += 1
                        continue
                    usage1_tmp += 1
                    if tmpResult == "WellRolloverOrNotRollover":
                        WellRolloverOrNotRollover_tmp += 1
                    else:
                        print("Wrong2")
                        print(line)
                        print(result)
                        input()
            
            if usage0_tmp > 0 and usage1_tmp > 0:
                mixed_usage.append(line)
                continue

            if NewKeyInvalidOldKeyUnknown_validBtw_tmp > 0:
                NewKeyInvalidOlkKeyUnknown_validBtw += 1
                if usage0_tmp > 0:
                    NewKeyInvalidOldKeyUnknown_validBtw_0 += 1
                if usage1_tmp > 0:
                    NewKeyInvalidOldKeyUnknown_validBtw_1 += 1

            if NewKeyInvalidOldKeyUnknown_validSame_tmp > 0:
                NewKeyInvalidOlkKeyUnknown_validSame += 1
                if usage0_tmp > 0:
                    NewKeyInvalidOldKeyUnknown_validSame_0 += 1
                if usage1_tmp > 0:
                    NewKeyInvalidOldKeyUnknown_validSame_1 += 1

            if NewKeyInvalidOldKeyUnknown_validAfter_tmp > 0:
                NewKeyInvalidOlkKeyUnknown_validAfter += 1
                if usage0_tmp > 0:
                    NewKeyInvalidOldKeyUnknown_validAfter_0 += 1
                if usage1_tmp > 0:
                    NewKeyInvalidOldKeyUnknown_validAfter_1 += 1

            if NewKeyInvalidOldKeyUnknown_validNone_tmp > 0:
                NewKeyInvalidOldKeyUnknown_validNone += 1
                if usage0_tmp > 0:
                    NewKeyInvalidOldKeyUnknown_validNone_0 += 1
                if usage1_tmp > 0:
                    NewKeyInvalidOldKeyUnknown_validNone_1 += 1

            if NewKeyInvalid_validBtw_tmp > 0:
                NewKeyInvalid_validBtw += 1
                if usage0_tmp > 0:
                    NewKeyInvalid_validBtw_0 += 1
                if usage1_tmp > 0:
                    NewKeyInvalid_validBtw_1 += 1

            if NewKeyInvalid_validAfter_tmp > 0:
                NewKeyInvalid_validAfter+= 1
                if usage0_tmp > 0:
                    NewKeyInvalid_validAfter_0 += 1
                    invalid_domains.add(dn)
                if usage1_tmp > 0:
                    NewKeyInvalid_validAfter_1 += 1

            if NewKeyInvalid_validSame_tmp > 0:
                NewKeyInvalid_validSame += 1
                if usage0_tmp > 0:
                    NewKeyInvalid_validSame_0 += 1
                    invalid_domains.add(dn)
                if usage1_tmp > 0:
                    NewKeyInvalid_validSame_1 += 1

            if NewKeyInvalid_validNone_tmp > 0:
                NewKeyInvalid_validNone += 1
                if usage0_tmp > 0:
                    NewKeyInvalid_validNone_0 += 1
                if usage1_tmp > 0:
                    NewKeyInvalid_validNone_1 += 1


            if NewKeyInvalid_tmp > 0:
                NewKeyInvalid += 1
                if usage0_tmp > 0:
                    NewKeyInvalid_0 += 1
                if usage1_tmp > 0:
                    NewKeyInvalid_1 += 1
            if OldKeyInvalid_tmp > 0:
                OldKeyInvalid += 1
                if usage0_tmp > 0:
                    OldKeyInvalid_0 += 1
                if usage1_tmp > 0:
                    OldKeyInvalid_1 += 1
            '''
            if BothInvalid_tmp > 0:
                BothKeyInvalid += 1
                #if usage0_tmp > 0:
                #    BothKeyInvalid_0 += 1
                #if usage1_tmp > 0 :
                #    BothKeyInvalid_1 += 1
            '''
            if NewKeyInvalidOldKeyUnknown_tmp > 0:
                NewKeyInvalidOldKeyUnknown += 1
                if usage0_tmp > 0:
                    NewKeyInvalidOldKeyUnknown_0 += 1
                if usage1_tmp > 0:
                    NewKeyInvalidOldKeyUnknown_1 += 1
            if NewKeyUnknownOldKeyInvalid_tmp > 0:
                NewKeyUnknownOldKeyInvalid += 1
                if usage0_tmp > 0:
                    NewKeyUnknownOldKeyInvalid_0 += 1
                if usage1_tmp > 0:
                    NewKeyUnknownOldKeyInvalid_1 += 1
            #if BothInvalid_tmp > 0:
            #    print(line)
            #    input()

           
            tmpResult = []
            for result in results:
                if "BothInvalid" in result:
                    tmpResult.append(result[:13])
                elif "NewKeyInvalid" in result:
                    tmpResult.append(result[:15])
                else:
                    tmpResult.append(result)

            results = tmpResult

            if ShortTTL_tmp > 0:
                ShortTTL += 1
            elif OldKeyInvalid_tmp > 0 or NewKeyInvalid_tmp > 0 or NewKeyInvalidOldKeyUnknown_tmp > 0 or NewKeyUnknownOldKeyInvalid_tmp > 0 or NewKeyInvalid_tmp > 0:
                Bad += 1
                if usage0_tmp > 0:
                    Bad_0 += 1
                    usage0 += 1
                if usage1_tmp > 0:
                    Bad_1 += 1
                    usage1 += 1
            elif AllTimeNoTLSA_tmp > 0 or CannotKnowPreviousTLSA_tmp > 0 or CannotKnowAfterTLSA_tmp > 0 or NewKeyValidOldKeyUnknown_tmp > 0 or CannotKnow_tmp > 0:
                CannotKnow += 1
            else:
                if len(set(results)) == 1:
                    if BothValid_tmp > 0 or WellRolloverOrNotRollover_tmp > 0:
                        AllTimeGood += 1
                        if usage0_tmp > 0:
                            AllTimeGood_0 += 1
                            usage0 += 1
                        if usage1_tmp > 0:
                            AllTimeGood_1 += 1
                            usage1 += 1
                    elif NotRollover_tmp > 0:
                        NotRollover += 1
                    elif BothInvalid_tmp > 0:
                        BothKeyInvalid += 1
                    else:
                        continue
                        print("??")
                        print(line)
                        input()
                elif len(set(results)) == 2:
                    if BothValid_tmp > 0 and WellRolloverOrNotRollover_tmp > 0:
                        AllTimeGood += 1
                        if usage0_tmp > 0:
                            AllTimeGood_0 += 1
                            usage0 += 1
                        if usage1_tmp > 0:
                            AllTimeGood_1 += 1
                            usage1 += 1
                    elif BothValid_tmp > 0 and NotRollover_tmp > 0:
                        AllTimeGood += 1
                        if usage0_tmp > 0:
                            AllTimeGood_0 += 1
                            usage0 += 1
                        if usage1_tmp > 0:
                            usgae1 += 1
                            AllTimeGood_1 += 1
                    elif WellRolloverOrNotRollover_tmp > 0 and NotRollover_tmp > 0:
                        AllTimeGood += 1
                        if usage0_tmp > 0:
                            AllTimeGood_0 += 1
                            usage0 += 1
                        if usage1_tmp > 0:
                            AllTimeGood_1 += 1
                            usgae1 += 1
                    elif BothValid_tmp > 0 and BothInvalid_tmp > 0:
                        AllTimeGood += 1
                        if usage0_tmp > 0:
                            AllTimeGood_0 += 1
                            usage0 += 1
                        if usage1_tmp > 0:
                            AllTimeGood_1 += 1
                            usgae1 += 1 
                    elif WellRolloverOrNotRollover_tmp > 0 and BothInvalid_tmp > 0:
                        AllTimeGood += 1
                        if usage0_tmp > 0:
                            AllTimeGood_0 += 1
                            usage0 += 1
                        if usage1_tmp > 0:
                            AllTimeGood_1 += 1
                            usgae1 += 1
                    elif NotRollover_tmp > 0 and BothInvalid_tmp > 0:
                        NotRollover += 1
                    else:
                        #continue
                        print("??")
                        print(line)
                        input()
                elif len(set(results)) == 3:
                    if BothValid_tmp > 0 and WellRolloverOrNotRollover_tmp > 0 and NotRollover_tmp > 0:
                        AllTimeGood += 1
                        if usage0_tmp > 0:
                            AllTimeGood_0 += 1
                            usage0 += 1
                        if usage1_tmp > 0:
                            AllTimeGood_1 += 1
                            usgae1 += 1
                else:
                    #continue
                    print("??")
                    print(line)
                    input()
 

        f.close()


target = total - notTarget
print("Total:", total)
print("Taget:", target)

print("BothKeyInvalid:", BothKeyInvalid, round(100*BothKeyInvalid/target, 2))
print("NotRollover:", NotRollover, round(100*NotRollover/target, 2))
print("ShortTTL:", ShortTTL, round(100*ShortTTL/target, 2))
print("CannotKnow:", CannotKnow, round(100*CannotKnow/target, 2))
print()
print("AllTimeValid:", AllTimeGood, round(100*AllTimeGood/target, 2))
print("Invalid:", Bad, round(100*Bad/target, 2))
print()
print("OnlyUsage:", usage0)
print("AllTImeValid OnlyUsage:", AllTimeGood_0, round(100*AllTimeGood_0/usage0, 2))
print("Invalid OnlyUsage:", Bad_0, round(100*Bad_0/usage0, 2))
print("MixUsage:", usage1)
print("AllTimeValid MixUsage:", AllTimeGood_1, round(100*AllTimeGood_1/usage1, 2))
print("Invalid MixUsage:", Bad_1, round(100*Bad_1/usage1, 2))

print("-------------------------------------")
#print("NewKeyInvalid:", NewKeyInvalid)
#print("OldKeyInvalid:", OldKeyInvalid)
#print("NewKeyInvalidOldKeyUnknown:", NewKeyInvalidOldKeyUnknown)
#print("NewKeyUnknownOldKeyInvalid:", NewKeyUnknownOldKeyInvalid)

print("NewKeyInvalid OnlyUsage:", NewKeyInvalid_0, round(100*NewKeyInvalid_0/Bad_0, 2))
print("OldKeyInvalid OnlyUsage:", OldKeyInvalid_0, round(100*OldKeyInvalid_0/Bad_0, 2))
print("NewKeyInvalidOldKeyUnknown OnlyUsage:", NewKeyInvalidOldKeyUnknown_0, round(100*NewKeyInvalidOldKeyUnknown_0/Bad_0, 2))
print("NewKeyUnknownOldKeyInvalid OnlyUsage:", NewKeyUnknownOldKeyInvalid_0, round(100*NewKeyUnknownOldKeyInvalid_0/Bad_0, 2))

print("NewKeyInvalid MixUsage:", NewKeyInvalid_1, round(100*NewKeyInvalid_1/Bad_1, 2))
print("OldKeyInvalid MixUsage:", OldKeyInvalid_1, round(100*OldKeyInvalid_1/Bad_1, 2))
print("NewKeyInvalidOldKeyUnknown MixUsage:", NewKeyInvalidOldKeyUnknown_1, round(100*NewKeyInvalidOldKeyUnknown_1/Bad_1, 2))
print("NewKeyUnknownOldKeyInvalid MixUsage:", NewKeyUnknownOldKeyInvalid_1, round(100*NewKeyUnknownOldKeyInvalid_1/Bad_1, 2))

print("-------------------------------------")
'''
print("NewKeyInvalidOldKeyUnknown Same:", NewKeyInvalidOldKeyUnknown_validSame)
print("NewKeyInvalidOldKeyUnknown Btw:", NewKeyInvalidOldKeyUnknown_validBtw)
print("NewKeyInvalidOldKeyUnknown After:", NewKeyInvalidOldKeyUnknown_validAfter)
print("NewKeyInvalidOldKeyUnknown None:", NewKeyInvalidOldKeyUnknown_validNone)

print("NewKeyInvalid Same:", NewKeyInvalid_validSame)
print("NewKeyInvalid Btw:", NewKeyInvalid_validBtw)
print("NewKeyInvalid After:", NewKeyInvalid_validAfter)
print("NewKeyInvalid None:", NewKeyInvalid_validNone)
'''

print("NewKeyInvalid Btw OnlyUsage:", NewKeyInvalid_validBtw_0, round(100*NewKeyInvalid_validBtw_0/Bad_0, 2))
print("NewKeyInvalid Same OnlyUsage:", NewKeyInvalid_validSame_0, round(100*NewKeyInvalid_validSame_0/Bad_0, 2))
print("NewKeyInvalid After OnlyUsage:", NewKeyInvalid_validAfter_0, round(100*NewKeyInvalid_validAfter_0/Bad_0, 2))
print("NewKeyInvalid Not Chnged OnlyUsage:", NewKeyInvalid_validNone_0, round(100*NewKeyInvalid_validNone_0/Bad_0, 2))

print("NewKeyInvalid Same + After OnlyUsage Domains:", len(invalid_domains), round(100*len(invalid_domains)/Bad_0, 2))

print("NewKeyInvalid Btw MixUsage:", NewKeyInvalid_validBtw_1, round(100*NewKeyInvalid_validBtw_1/Bad_1, 2))
print("NewKeyInvalid Same MixUsage:", NewKeyInvalid_validSame_1, round(100*NewKeyInvalid_validSame_1/Bad_1, 2))
print("NewKeyInvalid After MixUsage:", NewKeyInvalid_validAfter_1, round(100*NewKeyInvalid_validAfter_1/Bad_1, 2))
print("NewKeyInvalid Not Changed MixUsage:", NewKeyInvalid_validNone_1, round(100*NewKeyInvalid_validNone_1/Bad_1, 2))



print()
print("Mixed_Usage(Need manual classification):", mixed_usage)
print()







