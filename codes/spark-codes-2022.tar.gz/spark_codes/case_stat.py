#!/usr/bin/python3
from pyspark import SparkContext, SparkConf

import datetime
import os
import json
import ast


case_hour_input_path = "/path/to/case_hour_output_[month]"
dependency_path = "/path/to/dependencies.zip"


def fromjson(d):
    return json.loads(d)

def todict(d):
    return ast.literal_eval(d)

def toCSV(d):
    return " ".join(str(x) for x in d)

def handleNoneHour(d):
    if d["hour"] == None:
        return False
    else:
        return True

def count(d):
    date = d[0][0]
    hour = d[0][1]

    dataList = d[1]
    totalDomainSet = set([])
    noData1 = set([])
    noData2 = set([])
    noCase = set([])
    results = {"MO":{"total_domain":set([]), "wrong_domain":set([]), "total_tlsa":set([]), "wrong_tlsa":set([])}, "MSDO": {"total_domain":set([]), "wrong_domain":set([]), "total_tlsa":set([]), "wrong_tlsa":set([])}, "MSDS": {"total_domain":set([]), "wrong_domain":set([]), "total_tlsa":set([]), "wrong_tlsa":set([])}}

    for data in dataList:
        domain = data['domain']
        totalDomainSet.add(domain)

        case = data['case']
        if case == "None":
            noCase.add(domain)
            continue

        validity = data['validity']
        
        if validity == -1:
            noData1.add(domain)
            continue
        if validity == -2 or validity == -3:
            noData2.add(domain)
            continue

    for data in dataList:
        domain = data['domain']

        if (domain in noCase) or (domain in noData1) or (domain in noData2):
            continue
        
        case = data['case']
        validity = data['validity']
       
        results[case]['total_domain'].add(domain)
        results[case]['total_tlsa'].update(data['valid_mx'])
        results[case]['total_tlsa'].update(data['invalid_mx'])

        if validity == 0:
            results[case]['wrong_domain'].add(domain)
            results[case]['wrong_tlsa'].update(data['invalid_mx'])

    total_crawled_domain = len(results['MO']['total_domain'] | results['MSDO']['total_domain'] | results['MSDS']['total_domain'])
    total_wrong_domain = len(results['MO']['wrong_domain'] | results['MSDO']['wrong_domain'] | results['MSDS']['wrong_domain'])
    total_tlsa = len(results['MO']['total_tlsa'] | results['MSDO']['total_tlsa'] | results['MSDS']['total_tlsa'])
    total_wrong_tlsa = len(results['MO']['wrong_tlsa'] | results['MSDO']['wrong_tlsa'] | results['MSDS']['wrong_tlsa'])
   
    return date+"-"+hour, len(totalDomainSet), len(noData1), len(noData2), len(noCase),\
            total_crawled_domain, total_wrong_domain, total_tlsa, total_wrong_tlsa,\
            len(results['MO']['total_domain']), len(results['MO']['wrong_domain']), len(results['MO']['total_tlsa']), len(results['MO']['wrong_tlsa']), \
            len(results['MSDO']['total_domain']), len(results['MSDO']['wrong_domain']), len(results['MSDO']['total_tlsa']), len(results['MSDO']['wrong_tlsa']), \
            len(results['MSDS']['total_domain']), len(results['MSDS']['wrong_domain']), len(results['MSDS']['total_tlsa']), len(results['MSDS']['wrong_tlsa'])



def run(sc):
    months = ["1907", "1908", "1909", "1910", "1911", "1912", "2001", "2002", "2003", "2004", "2005", "2006", "2007", "2008", "2009", "2010" ,"2011", "2012", "2101", "2102"]

    for month in months:
        k = sc.textFile(os.path.join(case_hour_input_path, "case_hour_output_" + month + "/*"))\
                .map(fromjson)\
                .filter(handleNoneHour)\
                .groupBy(lambda d: (d['date'], d['hour']))\
                .map(count)\
                .map(toCSV)
        
        k.saveAsTextFile("case_stat_" + month)

if __name__ == "__main__":
    sc = SparkContext(appName="DANE-Mgmt-Case-Stat")
    sc.addPyFile(os.path.join(dependency_path, "dependencies.zip"))
    run(sc)
    sc.stop()


