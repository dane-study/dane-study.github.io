#!/usr/bin/python3
from pyspark import SparkContext, SparkConf

import datetime
import os
import json


case_hour_input_path = "/path/to/case_hour_output_[month]"
rollover_target_input_path = "/path/to/rollover-actual-targets.txt"


def fromjson(d):
    return json.loads(d)

def tojson(d):
    return json.dumps(d)

def toCSV(d):
    return " ".join(str(x) for x in d)

def extractTLSA(d, targets):
    date = d[0][0]
    hour = d[0][1]

    dataList = d[1]
    passSet = set([])

    results = {"MO": set([]), "MSDO": set([]), "MSDS": set([])}
    mxMap = {}

    targets = set(targets.value)

    for data in dataList:
        domain = data['domain']
        case = data['case']
        if case == "None":
            passSet.add(domain)
            continue

        validity = data['validity']
        if validity == -1:
            passSet.add(domain)
            continue
        if validity == -2:
            passSet.add(domain)
            continue
        
        mxs = set(data['invalid_mx'] + data['valid_mx'])

        if len(mxs.intersection(targets)) == 0:
            passSet.add(domain)
            continue
        for mx in mxs:
            if not mx in mxMap:
                mxMap[mx] = {"MO":set([]), "MSDO":set([]), "MSDS":set([])}

    for data in dataList:
        domain = data['domain']
        if domain in passSet:
            continue

        case = data['case']
        validity = data['validity']
       
        results[case].update(data['invalid_mx'] + data['valid_mx'])

        mxs = set(data['invalid_mx'] + data['valid_mx'])
        for mx in mxs:
            mxMap[mx][case].add(domain)

    returns = []
    for case in results.keys():
        for mx in results[case]:
            if not mx in targets:
                continue
            returns.append({"time": date + "-" + hour, "case": case, "mx": mx, "domain": mxMap[mx][case]})

    return returns



def getTargets():
    targets = []
    f = open(path.join(rollover_target_input_path, "rollover-actual-targets.txt"), "r")
    while True:
        line = f.readline()
        if not line: break

        targets.append(line.strip())
    
    f.close()
    return targets


def getPerMXCase(d):

    mx = d[0]
    dataList = d[1]

    output = {"mx":mx}

    for data in dataList:

        case = data["case"]
        if not case in output:
            output[case] = {}

        output[case][data["time"]] = list(data["domain"])

    return output


def filterNoData(d):
    if d['hour'] == None:
        return False
    else:
        return True


def run(sc):
    
    targets = getTargets()

    months = ["1907", "1908", "1909", "1910", "1911", "1912", "2001", "2002", "2003", "2004", "2005", "2006", "2007", "2008", "2009", "2010" ,"2011", "2012", "2101", "2102"]

    targetsG = sc.broadcast(targets)

    for month in months:
        k = sc.textFile(os.path.join(case_hour_input_path, "case_hour_output_" + month + "/*"))\
                .map(fromjson)\
                .filter(filterNoData)\
                .groupBy(lambda d: (d['date'], d['hour']))\
                .map(lambda x: extractTLSA(x, targetsG))\
                .flatMap(lambda list: list)\
                .groupBy(lambda d: d['mx'])\
                .map(getPerMXCase)\
                .map(tojson)

        k.saveAsTextFile("rollover_target_case_" + month)
        

if __name__ == "__main__":
    sc = SparkContext(appName="DANE-Rollover-Case")
    run(sc)
    sc.stop()


