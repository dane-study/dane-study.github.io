#!/usr/bin/python3
from pyspark import SparkContext, SparkConf

import sys
import dns as mydns
import dns.message as mymessage
import base64
from OpenSSL import crypto
import json
import datetime
import os
import csv


rollover_groupby_input_path = "/path/to/rollover_groupby/"
antago_syix_mx_input_path = "/path/to/antago_syix_mx/"
mx_wo_nl_input_path = "/path/to/all-mx-exclude-nl.txt"
dependency_path = "/path/to/dependencies.zip"


def tojson(line):
    return json.loads(line)

def toCSV(line):
    return " ".join(str(d) for d in line)

def toTime(x):
    return datetime.datetime.strptime(x, '%Y%m%d %H')


def parseTLSA(encoded):
    msg = base64.b64decode(encoded)
    msg = mymessage.from_wire(msg)
    rrset = []

    for answer in msg.answer:
        if answer.rdtype == 52:
            rrset = rrset + [data.to_text() for data in answer]

    return set(rrset)

def getTLSA(d):
    if 'tlsa' in d:
        rrset = parseTLSA(d['tlsa']['record_raw'])
        return rrset
    return None
    

def getCert(d):
    if 'certs' in d['starttls']:
        certs = d['starttls']['certs']
    else:
        return None, None

    if len(certs) > 1:
        return certs[0], certs[1:]
    else:
        return certs[0], None


def getCN(cert):
    from OpenSSL import crypto

    crt = base64.b64decode(cert)
    crt = crypto.load_certificate(crypto.FILETYPE_PEM, crt)
    issuer = crt.get_issuer()

    if issuer == None or issuer.CN == None:
        return "None"

    cn = str(issuer.CN)

    return cn


def getKey(d):
    from OpenSSL import crypto
    
    if 'certs' in d['starttls']:
        certs = d['starttls']['certs']
    else:
        return None, None

    keys = []
    for cert in certs:
        crt = base64.b64decode(cert)
        crt = crypto.load_certificate(crypto.FILETYPE_PEM, crt)
        key = crt.get_pubkey()
        key = crypto.dump_publickey(crypto.FILETYPE_ASN1, key)
        key = base64.b64encode(key).decode()
        keys.append(key)

    if len(keys) > 1:
        return keys[0], keys[1:]
    else:
        return keys[0], None



def rolloverPrepare(d, pkiCA):
    dn = d['dn']
    dataList = d['list']

    tlsaChanged = 0
    leafCertChanged = 0
    otherCertChanged = 0
    leafKeyChanged = 0
    otherKeyChanged = 0

    prevTlsa = None
    prevLeafKey = None
    prevOtherKey = None
    prevLeafCert = None
    prevOtherCert = None
    otherKeyChangedTime = []
    timeList = []
    caSet = set([])

    for idx, data in enumerate(dataList):
        currTlsa = getTLSA(data)
        currLeafCert, currOtherCert = getCert(data)
        currLeafKey, currOtherKey = getKey(data)

        if not currLeafCert == None:
            currCN = getCN(currLeafCert)
            if currCN in pkiCA.value:
                currCN = currCN.replace(" ", "")
            else:
                currCN = "Self-signed"
            caSet.add(currCN)
          
        # initialize 
        if idx == 0:
            prevTlsa = currTlsa
            prevLeafCert = currLeafCert
            prevOtherCert = currOtherCert
            prevLeafKey = currLeafKey
            prevOtherKey = currOtherKey
            continue
        

        if prevTlsa == None:
            prevTlsa = currTlsa
        else:
            if not currTlsa == None:
                if not (prevTlsa == currTlsa):
                    tlsaChanged += 1
                    prevTlsa = currTlsa

        time = data['time'].replace(" ", "-")

        if currLeafCert == None:
            continue
        if prevLeafCert == None:
            prevLeafCert = currLeafCert
            prevOtherCert = currOtherCert
            prevLeafKey = currLeafKey
            prevOtherKey = currOtherKey
        else:
            if not prevLeafCert == None:
                cn = getCN(prevLeafCert)
                if cn in pkiCA.value:
                    cn = cn.replace(" ", "")
                else:
                    cn = "Self-signed"
 
            if not (prevLeafCert == currLeafCert):
                leafCertChanged += 1
                timeList.append(time + "/lc/" + cn)
                prevLeafCert = currLeafCert

            if not (prevLeafKey == currLeafKey):
                leafKeyChanged += 1
                timeList.append(time + "/lk/" + cn)
                prevLeafKey = currLeafKey 


            if currOtherCert == None:
                currOtherCertSet = set(["None"])
            else:
                currOtherCertSet = set(currOtherCert)
            if prevOtherCert == None:
                prevOtherCertSet = set(["None"])
            else:
                prevOtherCertSet = set(prevOtherCert)

            if not (prevOtherCertSet == currOtherCertSet):
                diff = currOtherCertSet - prevOtherCertSet
                diff2 = prevOtherCertSet - currOtherCertSet
                if not (len(diff) == 0 or len(diff2) == 0):
                    otherCertChanged += 1
                    timeList.append(time + "/oc/" + cn)
                prevOtherCert = currOtherCert

            if currOtherKey == None:
                currOtherKeySet = set(["None"])
            else:
                currOtherKeySet = set(currOtherKey)
            if prevOtherKey == None:
                prevOtherKeySet = set(["None"])
            else:
                prevOtherKeySet = set(prevOtherKey)

            if not (prevOtherKeySet == currOtherKeySet):
                diffKey = currOtherKeySet - prevOtherKeySet
                diffKey2 = prevOtherKeySet - currOtherKeySet
                if not (len(diffKey) == 0 or len(diffKey2) == 0):
                    timeList.append(time + "/ok/" + cn)
                    otherKeyChanged += 1
                prevOtherKey = currOtherKey

    start = datetime.datetime.strptime(dataList[0]['time'], "%Y%m%d %H")
    end = datetime.datetime.strptime(dataList[-1]['time'], "%Y%m%d %H")
    diff = int((end - start).total_seconds()//3600)
            
    if len(caSet) == 0:
        caSet.add("NoneNone")

    return (dn, diff, "/".join(caSet), tlsaChanged, leafCertChanged, otherCertChanged, leafKeyChanged, otherKeyChanged, " ".join(timeList))

def genList(data):
    dataList = [t for t in data[1]]
    dataList = sorted(dataList, key=lambda e: toTime(e['time']))

    return [data[0]] + dataList


def readPKICAs():
    cas = set([])
    with open("PublicAllIntermediateCertsReport.csv", "r") as csvFile:
        reader = csv.reader(csvFile)
        next(reader)
        for row in reader:
            cas.add(row[5])

    with open("PublicIntermediateCertsRevokedReport.csv", "r") as csvFile:
        reader = csv.reader(csvFile)
        next(reader)
        for row in reader:
            cas.add(row[9])
    return list(cas)


def getAntago():
    mxs = set([])
    path = os.path.join(antago_syix_mx_input_path, "antago_syix_mx/")
    files = os.listdir(path)
    for filename in files:
        f = open(path + filename, "r")
        while True:
            line = f.readline()
            if not line: break
            line = line.strip().split()
            
            if line[-1] == "Antagonist":
                mxs.add(line[0])
        f.close()

    return mxs

def filterNL(d, mxs):
    return (d['dn'] in mxs.value)


def filterAntago(d, mxs):
    return (not (d['dn'] in mxs.value))


def getNL():
    mxs = []
    f = open(os.path.join(mx_wo_nl_input_path, "all-mx-exclude-nl.txt"), "r")
    while True:
        line = f.readline()
        if not line: break
        mxs.append(line.strip())
    f.close()
    return mxs


def getStats(sc):

    pkiCA = readPKICAs()
    pkiCA_G = sc.broadcast(pkiCA)

    nlMX = getNL()
    antagoMX = getAntago()

    nlMX_G = sc.broadcast(nlMX)
    antagoMX_G = sc.broadcast(antagoMX)
    
    k = sc.textFile(os.path.join(rollover_groupby_input_path, "rollover_groupby/*"))\
            .map(tojson)\
            .filter(lambda x: filterNL(x, nlMX_G))\
            .filter(lambda x: filterAntago(x, antagoMX_G))\
            .map(lambda x: rolloverPrepare(x, pkiCA_G))\
            .map(toCSV)

    k.saveAsTextFile("rollover_cand_output")


if __name__ == "__main__":
    conf = SparkConf().setAppName("").set("spark.reducer.maxBlocksInFlightPerAddress", "1000")
    sc = SparkContext(appName="DANE-Rollover-Candidate", conf=conf)
    sc.addPyFile(os.path.join(dependency_path, "dependencies.zip"))
    getStats(sc)
    sc.stop()
