from pyspark import SparkContext, SparkConf

import sys, os
import base64
from OpenSSL import crypto
import json


input_path = "/path/to/input"
antago_syix_mx_input_path = "/path/to/antago_syix_mx/"
mx_wo_nl_input_path = "/path/to/all-mx-exclude-nl.txt"
dependency_path = "/path/to/dependencies.zip"


def tojson(line):
    return json.loads(line)


def isLEAux(item):
    from OpenSSL import crypto

    pem = base64.b64decode(item)
    cert = crypto.load_certificate(crypto.FILETYPE_PEM, pem)

    issuer = cert.get_issuer()

    if issuer == None:
        return 0, ""
    if issuer.O == None:
        return 0, ""

    if issuer.O == "Let's Encrypt":
        if "X3" in issuer.CN:
            return 1, "X3"
        elif "E1" in issuer.CN:
            return 1, "E1"
        elif "R3" in issuer.CN:
            return 1, "R3"
        elif "X1" in issuer.CN:
            return 1, "X1"
        else:
            return 1, "Error-" + str(issuer.CN)

    return 0, ""

def isLE(d):
    if not 'certs' in d['starttls']:
        return d['domain'] + ", " + d['time'] + ", " + "NotCrawled"

    certs = d['starttls']['certs']
    le, cn = isLEAux(certs[0])
    if le == 0:
        return d['domain'] + ", " + d['time'] + ", " + str(le)
    else:
        return d['domain'] + ", " + d['time'] + ", " + str(le) + ", " + cn


def filterAntagonist(d, antagonistMxG):
    mx = d['domain'] 
    return (not (mx in antagonistMxG.value))

def filterNL(d, mxs):
    return (d['domain'] in mxs.value)

def getTargetMX():
    mxs = []
    f = open(os.path.join(mx_wo_nl_input_path, "all-mx-exclude-nl.txt"), "r")
    while True:
        line = f.readline()
        if not line: break
        mxs.append(line.strip())
    f.close()
    return mxs
 

def getAntago():
    mxs = set([])
    path = os.path.join(antago_syix_mx_input_path, "antago_syix_mx/")
    files = os.listdir(path)
    for filename in files:
        f = open(path + filename, "r")
        while True:
            line = f.readline()
            if not line: break
            line = line.strip().split()

            if line[-1] == "Antagonist":
                mxs.add(line[0])
        f.close()

    return mxs

def getStats(sc):

    months = ["1907", "1908", "1909", "1910", "1911", "1912", "2001", "2002", "2003", "2004", "2005", "2006", "2007", "2008", "2009", "2010", "2011", "2012", "2101", "2102"]

    mxs = getTargetMX()
    mxsG = sc.broadcast(mxs)

    antagonistMx = getAntago()
    antagonistMxG = sc.broadcast(antagonistMx)

    for month in months:
        print(month)
        k = sc.textFile(os.path.join(input_path, month + "*"))\
                .map(tojson)\
                .filter(lambda x: filterNL(x, mxsG))\
                .filter(lambda x: filterAntagonist(x, antagonistMxG))\
                .map(isLE)\
                
        k.saveAsTextFile("le_output_" + month)
                


if __name__ == "__main__":
    sc = SparkContext(appName="DANE-LE")
    sc.addPyFile(os.path.join(dependency_path, "dependencies.zip"))
    getStats(sc)
    sc.stop()
