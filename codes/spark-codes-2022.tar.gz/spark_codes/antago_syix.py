#/usr/bin/python3
from pyspark import SparkContext, SparkConf

import datetime
import os
import json
import hashlib
import dns as mydns
import dns.message as mymessage
from OpenSSL import crypto
import base64

input_path = "/path/to/input"
ip_pp_input_path = "/path/to/ip_popularity/"
dependency_path = "/path/to/dependencies.zip"


def fromjson(d):
    return json.loads(d)

def tojson(d):
    return json.dumps(d)

def toCSV(d):
    return " ".join(str(x) for x in d)


def findTarget(d):
    from OpenSSL import crypto

    antago_keys = ["e415b82b2e85867110f488617b98c9492cadf727b405eabea7d96e97744dfafb"]
    syix_keys = ["750a3c28725db8a8f106f296a850ff717dc234427e9205bd2cd592394e6874c7",\
            "18c39af0928a3372344b5f0139e8a2f890674f701f3da0c54601c31198351ffe",\
            "a39a95a32ac01d8c9c3dcc9cb612153126f22d1c246a349bd1de5e0092cc0e12",\
            "1c669f909da9420c81026d5ec7553efff0173d4379d2bebbea5eef9fd23b9c01"]

    mx = d['domain']
    time = d['time']

    certs = d['starttls']['certs']
    leaf = certs[0]

    pem = base64.b64decode(leaf)
    crt = crypto.load_certificate(crypto.FILETYPE_PEM, pem)
    crt_asn = crypto.dump_certificate(crypto.FILETYPE_ASN1, crt)

    pubKey = crt.get_pubkey()
    pubKey = crypto.dump_publickey(crypto.FILETYPE_ASN1, pubKey)

    crt256 = hashlib.sha256(crt_asn).hexdigest()
    key256 = hashlib.sha256(pubKey).hexdigest()

    if key256 in antago_keys:
        return [[mx, time, "Antagonist"]]
    
    if crt256 in syix_keys:
        return [[mx, time, "Syix"]]
    
    return []


def uniqueMx(d, ipMap):
    mx = d[0][0]


    #dataList = d[1]
    #dataList = sorted(dataList, key = lambda x: datetime.datetime.strptime(x[1], "%Y%m%d %H"))

    return mx, dataList[0][1].replace(" ", "-")


def getIPMap(threshold, month, ipMap):
    path = os.path.join(ip_pp_input_path, "ip_pp_" + month)

    f = open(path, "r")
    while True:
        line = f.readline()
        if not line: break

        line = json.loads(line)
        date = "20"+line['date']

        ipSet = set([])
        mx_ips = line['mx_ip_len']
        for mx_ip in mx_ips:
            ip = mx_ip[0]
            mxs = mx_ip[1]

            if len(mxs) > threshold:
                ipSet.update(mxs)
        ipMap[date] = ipSet
    f.close()
    return ipMap


def run(sc):

    k = sc.textFile(input_path)\
            .map(fromjson)\
            .filter(lambda d: 'certs' in d['starttls'])\
            .map(findTarget)\
            .flatMap(lambda list: list)\
            .map(toCSV)

    k.saveAsTextFile("antago_syix_mx")


if __name__ == "__main__":
    conf = SparkConf()
    sc = SparkContext(appName="DANE-antagno-syix", conf=conf)
    sc.addPyFile(os.path.join(dependency_path, "dependencies.zip"))
    run(sc)
    sc.stop()

