#!/usr/bin/python3
from pyspark import SparkContext, SparkConf

import sys, os
import dns as mydns
import dns.message as mymessage
import base64
from OpenSSL import crypto
import json
import datetime
import hashlib
import csv
import binascii


root_cert_path = "/path/to/root_cert_store" # ex) /etc/ssl/certs/
rollover_groupby_input_path = "/path/to/rollover_groupby/"
antago_syix_mx_input_path = "/path/to/antago_syix_mx/"
mx_wo_nl_input_path = "/path/to/all-mx-exclude-nl.txt"
rollover_candidate_input_path = "/path/to/keyChangedDn.txt"
never_matched_input_path = "/path/to/never_matched.txt"
dependency_path = "/path/to/dependencies.zip"


def tojson(line):
    return json.loads(line)

def toCSV(line):
    return " ".join(str(d) for d in line)

def toTime(x):
    return datetime.datetime.strptime(x, '%Y%m%d %H')

def timeToStr(x):
    time = x.strftime("%Y%m%d-%H")
    time = time.split("-")
    if time[1][0] == "0":
        return time[0] + "-" + time[1][1]
    else:
        return time[0] + "-" + time[1]

def usageStr(usages):
    usages = sorted(usages, key=lambda x: int(x))
    return "_".join(usages)

def getTTL(encoded):
    msg = base64.b64decode(encoded)
    msg = mymessage.from_wire(msg)

    for answer in msg.answer:
        if answer.rdtype == 52:
            ttl = answer.to_rdataset().ttl
    return ttl


def getNearTLSA(dataList, time):

    prev = None
    for data in dataList:
        if 'tlsa' in data:
            prev = data['tlsa']['record_raw']
        if data['time'] == time:
            break

    return prev


def parseTLSA(encoded):
    msg = base64.b64decode(encoded)
    msg = mymessage.from_wire(msg)
    rrset = []

    usages = set([])
    for answer in msg.answer:
        if answer.rdtype == 52:
            rrset = rrset + [data.to_text() for data in answer]

    return set(rrset)

def getTLSA(d):
    if 'tlsa' in d:
        rrset = parseTLSA(d['tlsa']['record_raw'])
        return rrset
    return None
    

def getCert(d):
    if 'certs' in d['starttls']:
        certs = d['starttls']['certs']
    else:
        return None, None

    if len(certs) > 1:
        return certs[0], certs[1:]
    else:
        return certs[0], None


def getKey(d):
    from OpenSSL import crypto
    
    if 'certs' in d['starttls']:
        certs = d['starttls']['certs']
    else:
        return None, None

    keys = []
    for cert in certs:
        crt = base64.b64decode(cert)
        crt = crypto.load_certificate(crypto.FILETYPE_PEM, crt)
        key = crt.get_pubkey()
        key = crypto.dump_publickey(crypto.FILETYPE_ASN1, key)
        key = base64.b64encode(key).decode()
        keys.append(key)

    if len(keys) > 1:
        return keys[0], keys[1:]
    else:
        return keys[0], None


def getUsage(rrset):
    if rrset == None:
        return None
    usages = [x.split()[0] for x in rrset]
    return set(usages)


def getPreviousCert(time, d):
    prevCert = None
    afterCert = None

    passed = False
    for data in d:
        currTime = datetime.datetime.strptime(data['time'], "%Y%m%d %H")
        if currTime == time:
            return getCert(data)
        if currTime > time:
            break
    return None, None


def getPreviousTLSA(time, d):
    prevTLSA = None
    afterTLSA = None
    usage = None

    passed = False
    for data in d:
        currTime = datetime.datetime.strptime(data['time'], "%Y%m%d %H")
        if currTime == time:
            return getTLSA(data)
        if currTime > time:
            break
    return None


def getChangedTimes(dataList, keyChangedTime):

    prevLeafKey = None
    prevOtherKey = None

    timeline = []
   
    for idx, data in enumerate(dataList):
   
        currTlsa = getTLSA(data)
        currLeafKey, currOtherKey = getKey(data)

        # initialize 
        if idx == 0:
            prevLeafKey = currLeafKey
            prevOtherKey = currOtherKey
            continue
            
        if currLeafKey == None:
            continue
        if prevLeafKey == None:
            prevLeafKey = currLeafKey
            prevOtherKey = currOtherKey
            continue
 
        if not data['time'] in keyChangedTime:
            continue
      
        prevTime = datetime.datetime.strptime(data['time'], "%Y%m%d %H")
        prevTime = prevTime - datetime.timedelta(hours=1)
        oneHourBeforeTlsa = getPreviousTLSA(prevTime, dataList)
        if not oneHourBeforeTlsa == None:
            usage = getUsage(oneHourBeforeTlsa)
        oneHourBeforeLeaf, oneHourBeforeOther = getPreviousCert(prevTime, dataList)

        isChanged = False
        if not (prevLeafKey == currLeafKey):
            if not oneHourBeforeTlsa == None:
                isChanged = True
                timeline.append((data, oneHourBeforeTlsa, oneHourBeforeLeaf, oneHourBeforeOther, "0"))
            else:
                timeline.append((data, None, None, None, "-1"))
                isChanged = True
                            
            prevLeafKey = currLeafKey

        if currOtherKey == None:
            currOtherKeySet = set(["None"])
        else:
            currOtherKeySet = set(currOtherKey)
        if prevOtherKey == None:
            prevOtherKeySet = set(["None"])
        else:
            prevOtherKeySet = set(prevOtherKey)

        if not (prevOtherKeySet == currOtherKeySet):
            diff = currOtherKeySet - prevOtherKeySet
            diff2 = prevOtherKeySet - currOtherKeySet
            if not (len(diff) == 0 or len(diff2) == 0):
                if not oneHourBeforeTlsa == None:
                    if isChanged:
                        timeline = timeline[:-1]
                        timeline.append((data, oneHourBeforeTlsa, oneHourBeforeLeaf, oneHourBeforeOther, "2"))
                    else:
                        timeline.append((data, oneHourBeforeTlsa, oneHourBeforeLeaf, oneHourBeforeOther, "1"))
                else:
                    if not isChanged:
                        timeline.append((data, None, None, None, "-1"))

            prevOtherKey = currOtherKey

    return timeline
   

def getThresData(time, ttl, dataList):
    currTime = datetime.datetime.strptime(time, "%Y%m%d-%H")
    thresTime = currTime - datetime.timedelta(seconds=(2*ttl))

    thresData = None
    for data in dataList:
        curr = datetime.datetime.strptime(data['time'], "%Y%m%d %H")
        if curr == thresTime:
            thresData = data
        if curr > thresTime:
            break

    thresTime = timeToStr(thresTime)
    if thresData == None:
        return None, None, thresTime
    tlsa = getTLSA(thresData)
    leaf, other = getCert(thresData)

    if leaf == None:
        certs = None
    else:
        if not other == None:
            certs = [leaf] + other
        else:
            certs = [leaf]

    return tlsa, certs, thresTime


def getNearThresData(time, dataList):

    thresTime = datetime.datetime.strptime(time, "%Y%m%d-%H")
    prevTlsa = None
    prevLeaf = None
    prevOther = None
    for data in dataList:
        curr = datetime.datetime.strptime(data['time'], "%Y%m%d %H")
        if curr >= thresTime:
            break
        tlsa = getTLSA(data)
        if not tlsa == None:
            prevTlsa = tlsa
        leaf, other = getCert(data)
        if not leaf == None:
            prevLeaf = leaf
            prevOther = other

    if prevLeaf == None:
        certs = None
    else:
        if not prevOther == None:
            certs = [prevLeaf] + prevOther
        else:
            certs = [prevLeaf]
    return prevTlsa, certs



def matchCrt(matching, data, crt):
    from OpenSSL import crypto
    
    if matching == '0':
        data = data.lower()
        hashed = binascii.b2a_hex(crt).decode()
    elif matching == '1':
        data = data.lower()
        hashed = hashlib.sha256(crt).hexdigest()
    elif matching == '2':
        data = data.lower()
        hashed = hashlib.sha512(crt).hexdigest()
    else:
        return False, "Matching-"+matching

    if hashed == data:
        return True, None
    return False, "CrtNotMatch"

def matchKey(matching, data, key):
    from OpenSSL import crypto
    if matching == '0':
        hashed = binascii.b2a_hex(key).decode()
        data = data.lower()
    elif matching == '1':
        data = data.lower()
        hashed = hashlib.sha256(key).hexdigest()
    elif matching == '2':
        data = data.lower()
        hashed = hashlib.sha512(key).hexdigest()
    else:
        return False, "Matching-"+matching

    if hashed == data:
        return True, None
    return False, "KeyNotMatch"


def findRoot(cert, root_certs_map):
    from OpenSSL import crypto
    crt = base64.b64decode(cert)
    crt = crypto.load_certificate(crypto.FILETYPE_PEM, crt)
    issuer = crt.get_issuer()

    if issuer == None:
        return None

    roots = set(root_certs_map.value.keys())

    if issuer.CN in roots:
        root = base64.b64encode(root_certs_map.value[issuer.CN].encode())
        return root
    return None

def isRoot(cert):
    from OpenSSL import crypto
    crt = base64.b64decode(cert)
    crt = crypto.load_certificate(crypto.FILETYPE_PEM, crt)
    issuer = crt.get_issuer()
    subject = crt.get_subject()
    
    if issuer == None or subject == None:
        return False

    if issuer.CN == subject.CN:
        return True
    return False



def unitValidation(record, certs, root_certs_map):
    from OpenSSL import crypto

    record = record.split()
    if len(record) != 4:
        record = record[:3] + [''.join(record[3:])]
    usage = record[0]
    selector = record[1]
    matching = record[2]
    data = record[3]
  
    if usage == '1' or usage == '3':
        
        pem = base64.b64decode(certs[0])
        crt = crypto.load_certificate(crypto.FILETYPE_PEM, pem)
        # use entire certificate
        if selector == '0':
            crt = crypto.dump_certificate(crypto.FILETYPE_ASN1, crt)
            matched, error = matchCrt(matching, data, crt)
            return matched

        # use public key
        elif selector == '1':
            pubKey = crt.get_pubkey()
            pubKey = crypto.dump_publickey(crypto.FILETYPE_ASN1, pubKey)
            matched, error = matchKey(matching, data, pubKey)
            return matched
        else:
            return False
    elif usage == '0':
        if isRoot(certs[-1]):
            tmpCerts = certs
        else:
            root = findRoot(certs[-1], root_certs_map)
            if root == None:
                tmpCerts = certs
            else:
                tmpCerts = certs + [root]
        
        for cert in tmpCerts[1:]:
            pem = base64.b64decode(cert)
            crt = crypto.load_certificate(crypto.FILETYPE_PEM, pem)

            if selector == '0':
                crt = crypto.dump_certificate(crypto.FILETYPE_ASN1, crt)
                matched, error = matchCrt(matching, data, crt)
                if matched:
                    return matched
            elif selector == '1':
                pubKey = crt.get_pubkey()
                pubKey = crypto.dump_publickey(crypto.FILETYPE_ASN1, pubKey)
                matched, error = matchKey(matching, data, pubKey)
                if matched:
                    return matched
            else:
                return False
    
        return False
    elif usage == '2':

        for idx, cert in enumerate(certs[1:]):
            pem = base64.b64decode(cert)
            crt = crypto.load_certificate(crypto.FILETYPE_PEM, pem)

            # use entire certificate
            if selector == '0':
                crt = crypto.dump_certificate(crypto.FILETYPE_ASN1, crt)
                matched, error = matchCrt(matching, data, crt)
                if matched:
                    return matched
            elif selector == '1':
                pubKey = crt.get_pubkey()
                pubKey = crypto.dump_publickey(crypto.FILETYPE_ASN1, pubKey)
                matched, error = matchKey(matching, data, pubKey)
                if matched:
                    return matched
            else:
                return False
        return False
    else:
        return False


def validation(tlsaRecords, certs, root_certs_map):
   
    results = []
    for record in tlsaRecords:
        valid = unitValidation(record, certs, root_certs_map)
        if valid:
            return True
        else:
            results.append(valid)
    
    if results == [] or None in results:
        a = 0/0

    return False

def everMatchedBefore(time, certs, dataList, root_certs_map):
    targetTime = datetime.datetime.strptime(time, "%Y%m%d-%H")

    for data in dataList:
        curr = datetime.datetime.strptime(data['time'], "%Y%m%d %H")

        if targetTime <= curr:
            break

        tlsa = getTLSA(data)
        if tlsa == None:
            continue

        leaf, other = getCert(data)
        if not leaf == None:
            currCerts = set([leaf])
            if not other == None:
                currCerts.update(other)

            if currCerts == set(certs):
                valid = validation(tlsa, certs, root_certs_map)
                if valid:
                    return True

    return False


def isOtherValid(tlsaRecords, certs, root_certs_map):
    targetRecords = []
    for record in tlsaRecords:
        if record[0] == "0" or record[0] == "2":
            targetRecords.append(record)

    for record in targetRecords:
        valid = unitValidation(record, certs, root_certs_map)
        if valid:
            return True
    
    return False

def isLeafValid(tlsaRecords, certs, root_certs_map):
    targetRecords = []
    for record in tlsaRecords:
        if record[0] == "1" or record[0] == "3":
            targetRecords.append(record)

    for record in targetRecords:
        valid = unitValidation(record, certs, root_certs_map)
        if valid:
            return True
    
    return False

def isThresValid(time, ttl, where, dataList, currTlsa, currCerts, root_certs_map, prefix):
    thresTlsa, thresCerts, thresTime = getThresData(time, ttl, dataList)
    if not thresTlsa == None:
        thresBeforeMatched_newKey = validation(thresTlsa, currCerts, root_certs_map)
        if not thresBeforeMatched_newKey:
            everMatched = afterValid(thresTime, currCerts, dataList, root_certs_map)
            if everMatched == None:
                whenMatched = "NotMatched"
            else:
                currTime = datetime.datetime.strptime(time, "%Y%m%d-%H")
                
                if everMatched < currTime:
                    whenMatched = "Between/" + timeToStr(everMatched)
                elif everMatched == currTime:
                    whenMatched = "SameTime/" + timeToStr(everMatched)
                else:
                    whenMatched = "After/" + timeToStr(everMatched)

                return prefix + where + "/Wrong/thres/" + time + "/" + whenMatched
        else:
            return prefix + where + "/Correct/" + time
            # get previous TLSA records
    else:
        nearThresTlsa, nearThresCerts = getNearThresData(thresTime, dataList)
        if nearThresTlsa == None:
            return "NoData/" + time
                            
        thresBeforeMatched_newKey = validation(nearThresTlsa, currCerts, root_certs_map)
        if not thresBeforeMatched_newKey:
            return "NoData/" + time
        else:
            return prefix + where + "/Correct/" + time
 

def afterValid(time, currCerts, dataList, root_certs_map):
    targetTime = datetime.datetime.strptime(time, "%Y%m%d-%H")

    for data in dataList:
        curr = datetime.datetime.strptime(data['time'], "%Y%m%d %H")
        if curr <= targetTime:
            continue
        tlsa = getTLSA(data)
        if not tlsa == None:
            valid = validation(tlsa, currCerts, root_certs_map)
            if valid:
                return curr

    return None



def rolloverCheck(x, keyChangedMap, root_certs_map):
    if x[1] == "NotTarget":
        return [x[0], x[1]]

    if x[1] == "NeverMatched":
        return [x[0], x[1]]
    
    if not x == None and not x[1] == None:
        dn = x[0]
        dataList = x[1]

        keyChangedTimes = keyChangedMap.value
        changedTimes = getChangedTimes(dataList, keyChangedTimes[dn])
    
        results = []
        for timeData in changedTimes:
            data = timeData[0]
            oneHourBeforeTlsa = timeData[1]
            oneHourBeforeLeaf = timeData[2]
            oneHourBeforeOther = timeData[3]
            where = timeData[4]


            time = data['time'].replace(" ", "-")

            if where == "-1":
                results.append("NoData/" + time)
                continue
   
            currTlsa = getTLSA(data)
            if currTlsa == None:
                results.append("NoData/" + time)
                continue
                       
            currLeafCert, currOtherCert = getCert(data)
            if currLeafCert == None:
                results.append("ERROR/" + str(data) + "/" + str(changedTimes))
                continue
            
            ttl = getTTL(data['tlsa']['record_raw'])
            # check short TTL
            if 2*ttl < 3600:
                if len(results) > 0 and results[-1] == "ShortTTL":
                    continue
                results.append("ShortTTL/" + time)
                continue

            if oneHourBeforeLeaf == None and oneHourBeforeOther == None:
                oneHourBeforeCerts = None
            else:
                if not oneHourBeforeOther == None:
                    oneHourBeforeCerts = [oneHourBeforeLeaf] + oneHourBeforeOther
                else:
                    oneHourBeforeCerts = [oneHourBeforeLeaf]
            
            if not currOtherCert == None:
                currCerts = [currLeafCert] + currOtherCert
            else:
                currCerts = [currLeafCert]

            if oneHourBeforeTlsa == None:
                results.append("ERROR/" + str(data) + "/" + str(changedTimes))
                continue

            if oneHourBeforeCerts == None:
                results.append("NoData/" + time)
                continue

            usage = getUsage(oneHourBeforeTlsa)

            if where == "0":
                if not ('1' in usage or '3' in usage):
                    results.append(usageStr(usage) + "/" + where + "/NotRollover/" + time)
                    continue
            if where == "1":
                if not ('0' in usage or '2' in usage):
                    results.append(usageStr(usage) + "/" + where + "/NotRollover/" + time)
                    continue
            
            # Usage 0 or 2 is included
            if "0" in usage or "2" in usage:
                oneHourBeforeMatched_oldKey = validation(oneHourBeforeTlsa, oneHourBeforeCerts, root_certs_map)
               
                if not oneHourBeforeMatched_oldKey:
                    oneHourBeforeMatched_newKey = validation(oneHourBeforeTlsa, currCerts, root_certs_map)
                    if not oneHourBeforeMatched_newKey:
                        results.append(usageStr(usage) + "/" + where + "/UnmatchBefore/" + time)
                    else:
                        if everMatchedBefore(time, oneHourBeforeCerts, dataList, root_certs_map):
                            results.append(usageStr(usage) + "/" + where + "/Wrong/a/" + time)
                        else:
                            results.append(usageStr(usage) + "/" + where + "/UnmatchBefore/" + time)
                else:
                    currMatched_newKey = validation(currTlsa, currCerts, root_certs_map)
                    if not currMatched_newKey:
                        everMatched = afterValid(time, currCerts, dataList, root_certs_map)
                        if everMatched == None:
                            whenMatched = "NotMatched"
                        else:
                            whenMatched = "After/" + timeToStr(everMatched)

                        # Do not update TLSA record before key changing
                        results.append(usageStr(usage) + "/" + where + "/Wrong/b/" + time + "/" + whenMatched)
                    else:
                        oneHourBeforeMatched_newKey = validation(oneHourBeforeTlsa, currCerts, root_certs_map)
                        if not oneHourBeforeMatched_newKey:
                            # Update TLSA record and certificates at the same time
                            results.append(usageStr(usage) + "/" + where + "/Wrong/c/" + time)
                        else:
                            if where == "0":
                                if isOtherValid(oneHourBeforeTlsa, oneHourBeforeCerts, root_certs_map):
                                    results.append(usageStr(usage) + "/" + where + "/Correct/" + time)
                                else:
                                    thresValid = isThresValid(time, ttl, where, dataList, currTlsa, currCerts, root_certs_map, usageStr(usage) + "/")
                                    results.append(thresValid)

                            elif where == "1":
                                if isLeafValid(oneHourBeforeTlsa, oneHourBeforeCerts, root_certs_map):
                                    results.append(usageStr(usage) + "/" + where + "/Correct/" + time)
                                else:
                                    thresValid = isThresValid(time, ttl, where, dataList, currTlsa, currCerts, root_certs_map, usageStr(usage) + "/")
                                    results.append(thresValid)

                            else:
                                thresValid = isThresValid(time, ttl, where, dataList, currTlsa, currCerts, root_certs_map, usageStr(usage) + "/")
                                results.append(thresValid)



            # Only Usage 1 or 3 is used
            else:
                oneHourBeforeMatched_oldKey = validation(oneHourBeforeTlsa, oneHourBeforeCerts, root_certs_map)

                if not oneHourBeforeMatched_oldKey:
                    oneHourBeforeMatched_newKey = validation(oneHourBeforeTlsa, currCerts, root_certs_map)
                    if not oneHourBeforeMatched_newKey:
                        results.append(usageStr(usage) + "/" + where + "/UnmatchBefore/" + time)
                    else:
                        if everMatchedBefore(time, oneHourBeforeCerts, dataList, root_certs_map):
                            results.append(usageStr(usage) + "/" + where + "/Wrong/d/" + time)
                        else:
                            results.append(usageStr(usage) + "/" + where + "/UnmatchBefore/" + time)
                else:
                    currMatched_newKey = validation(currTlsa, currCerts, root_certs_map)
                    if not currMatched_newKey:
                        everMatched = afterValid(time, currCerts, dataList, root_certs_map)
                        if everMatched == None:
                            whenMatched = "NotMatched"
                        else:
                            whenMatched = "After/" + timeToStr(everMatched)
                        # Do not update TLSA record before key changing
                        results.append(usageStr(usage) + "/" + where + "/Wrong/e/" + time + "/" + whenMatched)
                    else:
                        thresValid = isThresValid(time, ttl, where, dataList, currTlsa, currCerts, root_certs_map, usageStr(usage) + "/")
                        results.append(thresValid)

        if results == []:
            a = 100/0

        return [dn] + results


def genList(d, keyChangedMap, neverMatchedSet):
    
    dn = d['dn']
    dataList = d['list']

    keyChangedSet = (keyChangedMap.value).keys()
 
    if not dn in keyChangedSet:
        return (dn, "NotTarget")
    if dn in neverMatchedSet.value:
        return (dn, "NeverMatched")

    return (dn, dataList)


def readKeyChangedSet(path):
    keyChangedSet = {}

    f = open(path, "r")
    while True:
        line = f.readline()
        if not line: break
        line = line.strip().split()

        dn = line[0]
        changedTimes = [x.split("/")[0].replace("-", " ") for x in line[1:]]
        keyChangedSet[dn] = changedTimes

    f.close()

    return keyChangedSet


def getNeverMatchedSet():
    path = os.path.join(never_matched_input_path, "never_matched.txt")
    if os.path.isfile(path):
        f = open(path, "r")
        l = f.read().strip()
        l = l.split("\n")
        f.close()
        return l
    else:
        print("Need Never Matched Set")
        exit()


def getRootCertsMap():
    root_certs_map = {}

    files = os.listdir(root_cert_path)
    files.remove("java")

    for filename in files:
        f = open(root_cert_path + filename, "r")
        cert = f.read()
        crt = crypto.load_certificate(crypto.FILETYPE_PEM, cert)
        issuer = crt.get_issuer().CN

        root_certs_map[issuer] = cert
        f.close()

    return root_certs_map

def dnGroup(x):
    return x['domain']

def filterNL(d, mxs):
    return (d['dn'] in mxs.value)


def filterAntago(d, mxs):
    return (not (d['dn'] in mxs.value))


def getNL():
    mxs = []
    f = open(os.path.join(mx_wo_nl_input_path, "all-mx-exclude-nl.txt"), "r")
    while True:
        line = f.readline()
        if not line: break
        mxs.append(line.strip())
    f.close()
    return mxs


def getAntago():
    mxs = set([])
    path = os.path.join(antago_syix_mx_input_path, "antago_syix_mx/")
    files = os.listdir(path)
    for filename in files:
        f = open(path + filename, "r")
        while True:
            line = f.readline()
            if not line: break
            line = line.strip().split()

            if line[-1] == "Antagonist":
                mxs.add(line[0])
        f.close()

    return mxs


def getStats(sc):
    path = os.path.join(rollover_candidate_input_path, "keyChangedDn.txt")
    neverMatchedSet = getNeverMatchedSet()
    keyChangedMap = readKeyChangedSet(path) 
    root_certs_map = getRootCertsMap()

    neverMatchedSetG = sc.broadcast(neverMatchedSet)
    root_certs_mapG = sc.broadcast(root_certs_map)
    keyChangedMapG = sc.broadcast(keyChangedMap)

    
    nlMX = getNL()
    antagoMX = getAntago()
    nlMXG = sc.broadcast(nlMX)
    antagoMXG = sc.broadcast(antagoMX)

    k = sc.textFile(os.path.join(rollover_groupby_input_path, "rollover_groupby/*"))\
            .map(tojson)\
            .filter(lambda x: filterNL(x, nlMXG))\
            .filter(lambda x: filterAntago(x, antagoMXG))\
            .map(lambda x: genList(x, keyChangedMapG, neverMatchedSetG))\
            .map(lambda x: rolloverCheck(x, keyChangedMapG, root_certs_mapG))\
            .map(toCSV)

    k.saveAsTextFile("rollover_output")


if __name__ == "__main__":
    conf = SparkConf().setAppName("").set("spark.reducer.maxBlocksInFlightPerAddress", "1000")
    sc = SparkContext(appName="DANE-ROLLOVER", conf=conf)
    sc.addPyFile(os.path.join(dependency_path, "dependencies.zip"))
    getStats(sc)
    sc.stop()
