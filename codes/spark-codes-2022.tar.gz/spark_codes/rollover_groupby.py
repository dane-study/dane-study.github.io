#!/usr/bin/python3
from pyspark import SparkContext, SparkConf
import json
import datetime


input_path = "/path/to/input"


def fromjson(line):
    return json.loads(line)

def tojson(line):
    return json.dumps(line)

def toTime(x):
    return datetime.datetime.strptime(x, '%Y%m%d %H')

def genList(data):
    dataList = [t for t in data[1]]
    dataList = sorted(dataList, key=lambda e: toTime(e['time']))

    output = {}
    output["dn"] = data[0]
    output["list"] = dataList
    return output

def dnGroup(x):
    return x['domain']


def run(sc):
    
    k = sc.textFile(input_path)\
            .map(fromjson)\
            .groupBy(dnGroup)\
            .map(genList)\
            .map(tojson)
    k.saveAsTextFile("rollover_groupby")

if __name__ == "__main__":
    conf = SparkConf().setAppName("").set("spark.reducer.maxBlocksInFlightPerAddress", "1000")
    sc = SparkContext(appName="DANE-Rollover-GroupBy", conf=conf)
    run(sc)
    sc.stop()


