#!/usr/bin/python3
from pyspark import SparkContext, SparkConf

import sys, os
import dns as mydns
import dns.message as mymessage
import base64
from OpenSSL import crypto
import json
import datetime
import csv 


input_path = "/path/to/input"
init_seed_input_path = "/path/to/init-seed.txt"
antago_syix_mx_input_path = "/path/to/antago_syix_mx/"
mx_wo_nl_input_path = "/path/to/all-mx-exclude-nl.txt"
dependency_path = "/path/to/dependencies.zip"


def fromjson(line):
    return json.loads(line)

def tojson(line):
    return json.dumps(line)

def toCSV(line):
    return " ".join(str(l) for l in line)


def filterNL(d, mxs):
    return (d['domain'] in mxs.value)

def filterAntagonist(d, antagonistMxG):
    mx = d['domain']
    return (not (mx in antagonistMxG.value))


def checkInitial(d, initSet):

    mx = d['domain']
    time = d['time']
    if mx in initSet.value:
        return []
    else:
        if (not 'tlsa' in d) or ('why_fail' in d['starttls']):
            return [{"mx": mx, "time": time, "tlsa": "NoData", "certs": "NoData"}]
        return [{"mx": mx, "time": time, "tlsa": d['tlsa']['record_raw'], "certs": d['starttls']['certs']}]

def returnFirst(d):
    mx = d[0]
    dataList = d[1]
    dataList = sorted(dataList, key=lambda x: datetime.datetime.strptime(x["time"], '%Y%m%d %H'))

    return dataList[0]


def getTargetMX():

    mxs = []
    f = open(os.path.join(mx_wo_nl_input_path, "all-mx-exclude-nl.txt"), "r")
    while True:
        line = f.readline()
        if not line: break
        mxs.append(line.strip())

    f.close()

    return mxs

def getAntagonist():
    mxs = set([])
    path = os.path.join(antago_syix_mx_input_path, "antago_syix_mx/")
    files = os.listdir(path)
    for filename in files:
        f = open(path + filename, "r")
        while True:
            line = f.readline()
            if not line: break
            line = line.strip().split()

            if line[-1] == "Antagonist":
                mxs.add(line[0])
        f.close()

    return mxs


def getInitSet():
    initSet = []
    f = open(os.path.join(init_seed_input_path, "init-seed.txt"), "r")
    while True:
        line = f.readline()
        if not line: break
        mx = line.strip()
        initSet.append(mx)
    f.close()
    return initSet

def run(sc):
    
    mxs = getTargetMX()
    mxsG = sc.broadcast(mxs)

    antagonistMx = getAntagonist()
    antagonistMxG = sc.broadcast(antagonistMx)

    initSet = getInitSet()
    initSetG = sc.broadcast(initSet)

    k = sc.textFile(input_path)\
            .map(fromjson)\
            .filter(lambda x: filterNL(x, mxsG))\
            .filter(lambda x: filterAntagonist(x, antagonistMxG))\
            .map(lambda d: checkInitial(d, initSetG))\
            .flatMap(lambda list: list)\
            .groupBy(lambda d: d['mx'])\
            .map(returnFirst)\
            .map(tojson)
   
    k.saveAsTextFile("init_deploy")

if __name__ == "__main__":
    sc = SparkContext(appName="TLSA-Usage-Stat")
    sc.addPyFile(os.path.join(dependency_path, "dependencies.zip"))
    run(sc)
    sc.stop()


