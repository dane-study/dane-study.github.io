#!/usr/bin/python3
from pyspark import SparkContext, StorageLevel
from pyspark import SparkConf

import datetime
import os
import json


input_path = "/path/to/tlsa_mx_ns_aggregated/"
ns_popularity_input_path = "/path/to/ns_cluster_popularity/"
mx_popularity_input_path = "/path/to/mx_cluster_popularity/"
ip_popularity_input_path = "/path/to/ip_popularity/"
mx_cluster_input_path = "/path/to/mx_cluster.txt"
ns_cluster_input_path = "/path/to/ns_cluser.txt"


def tojson(d):

    output = {"domain":d[0], "date":d[1], "mx_case":d[2], "mx_first_party":d[3], "mx_outsourcing":d[4], "mx_cannotknow":d[5], "ns_case":d[6], "ns_first_party":d[7], "ns_outsourcing":d[8], "ns_cannotknow":d[9]}
    return json.dumps(output)


def fromjson(d):
    return json.loads(d)


def getSLD(domain, sldMap):
    if domain in sldMap.value.keys():
        return sldMap.value[domain]
    else:
        dn = domain.split(".")[:-1]
        sld = dn[-2]
        return sld

def filterFamousIP(candList, famousSet):
    firstPartyCand = []
    outsourcing = []
    for cand in candList:
        if cand in famousSet:
            outsourcing.append(cand)
        else:
            firstPartyCand.append(cand)

    return firstPartyCand, outsourcing

def filterSameSLD(domain, subdomainList, sldMap):
    firstParty = []
    outsourcingCand = []
    domainSLD = getSLD(domain, sldMap)
    for subdomain in subdomainList:
        if domainSLD == getSLD(subdomain, sldMap):
            firstParty.append(subdomain)
        else:
            outsourcingCand.append(subdomain)

    return firstParty, outsourcingCand


def filterFamousSLD(candList, famousSLDSet, sldMap):

    firstPartyCand = []
    outsourcing = []
    for cand in candList:
        sld = sldMap.value[cand]
        if sld in famousSLDSet:
            outsourcing.append(cand)
        else:
            if ".awsdns-" in cand or ".cloudflare." in cand:
                outsourcing.append(cand)
            else:
                firstPartyCand.append(cand)

    return firstPartyCand, outsourcing



def getMXCase(domain, mxList, famousMXSLDSet, mxSLDMap, famousIPSet):
    mxFirstPartyCand1, mxOutsourcing1 = filterFamousIP(mxList, famousIPSet)

    if len(mxFirstPartyCand1) == 0:
        mxFirstParty = []
        mxOutsourcing = mxOutsourcing1
        cannotKnow = []
    else:
        mxFirstParty2, mxOutsourcingCand2 = filterSameSLD(domain, mxFirstPartyCand1, mxSLDMap)
   
        if len(mxOutsourcingCand2) == 0:
            mxOutsourcing = mxOutsourcing1
            mxFirstParty = mxFirstParty2
            cannotKnow = []
        else:
            mxFirstPartyCand3, mxOutsourcing3 = filterFamousSLD(mxOutsourcingCand2, famousMXSLDSet, mxSLDMap)
    
            mxFirstParty = mxFirstParty2
            mxOutsourcing = mxOutsourcing1 + mxOutsourcing3
            cannotKnow = mxFirstPartyCand3

    if len(cannotKnow) > 0:
        mxCase = -1
    else:
        if len(mxOutsourcing) > 0 and len(mxFirstParty) == 0:
            mxCase = 1
        elif len(mxOutsourcing) == 0 and len(mxFirstParty) > 0:
            mxCase = 2
        else:
            mxCase = 3

    return mxCase, mxFirstParty, mxOutsourcing, cannotKnow


def getNSCase(domain, nsList, famousNSSLDSet, nsSLDMap):
    nsFirstParty1, nsOutsourcingCand1 = filterSameSLD(domain, nsList, nsSLDMap)
   
    if len(nsOutsourcingCand1) == 0:
        nsFirstParty = nsFirstParty1
        nsOutsourcing = []
        cannotKnow = []
    else:
        nsFirstPartyCand2, nsOutsourcing2 = filterFamousSLD(nsOutsourcingCand1, famousNSSLDSet, nsSLDMap)
    
        nsFirstParty = nsFirstParty1
        nsOutsourcing = nsOutsourcing2
        cannotKnow = nsFirstPartyCand2
    
    if len(cannotKnow) > 0:
        nsCase = -1
    else:
        if len(nsOutsourcing) > 0 and len(nsFirstParty) == 0:
            nsCase = 1
        elif len(nsOutsourcing) == 0 and len(nsFirstParty) > 0:
            nsCase = 2
        else:
            nsCase = 3

    return nsCase, nsFirstParty, nsOutsourcing, cannotKnow


def getCase(d, famousMap, mxSLDMap, nsSLDMap):

    domain = d["domain"]
    nsList = d["ns_list"]
    mxList = d["tlsa_mx_list"]
    date = d['year'] + d['month'] + d['day']

    famousMXSLDSet = famousMap.value[date][0]
    famousNSSLDSet = famousMap.value[date][1]
    famousIPSet = famousMap.value[date][2]

    mxCase, mxFirstParty, mxOutsourcing, mxCannotKnow = getMXCase(domain, mxList, famousMXSLDSet, mxSLDMap, famousIPSet)
    nsCase, nsFirstParty, nsOutsourcing, nsCannotKnow = getNSCase(domain, nsList, famousNSSLDSet, nsSLDMap)

        
    return domain, date, mxCase, mxFirstParty, mxOutsourcing, mxCannotKnow, nsCase, nsFirstParty, nsOutsourcing, nsCannotKnow


def getFamousMXSLD(threshold, month, mxSLDMap, famousSLDMap):
    
    path = os.path.join(mx_popularity_input_path, "mx_pp_" + month)

    f = open(path, "r")
    while True:
        line = f.readline()
        if not line: break

        line = json.loads(line)

        date = "20"+line['date']

        popularity = line['popularity']
        
        famousSet = []

        for d in popularity:
            sld = d[0]
            rank = int(d[1])

            if rank > threshold:
                famousSet.append(sld)

        famousSLDMap[date] = [famousSet]
    f.close()

    return famousSLDMap


def getFamousNSSLD(threshold, month, nsSLDMap, famousSLDMap):
    
    path = os.path.join(ns_popularity_input_path, "ns_pp_" + month)

    f = open(path, "r")
    while True:
        line = f.readline()
        if not line: break

        line = json.loads(line)

        date = "20"+line['date']
        popularity = line['popularity']
        
        famousSet = []

        for d in popularity:
            sld = d[0]
            rank = int(d[1])

            if rank > threshold:
                famousSet.append(sld)

        famousSLDMap[date].append(famousSet)
    f.close()


    return famousSLDMap


def getSLDCluster():

    mx_path = os.path.join(mx_cluster_input_path, "mx_cluster.txt")
    ns_path = os.path.join(ns_cluster_input_path, "ns_cluster.txt")
    
    mxSLDMap = {}
    f = open(mx_path, "r")
    while True:
        line = f.readline()
        if not line: break

        line = line.strip().split(", ")

        sld = line[0]
        mxs = line[2:]

        for mx in mxs:
            mxSLDMap[mx] = sld
    f.close()

    nsSLDMap = {}
    f = open(ns_path, "r")
    while True:
        line = f.readline()
        if not line: break

        line = line.strip().split(", ")

        sld = line[0]
        nss = line[2:]
        
        for ns in nss:
            nsSLDMap[ns] = sld
    f.close()

    return mxSLDMap, nsSLDMap


def getIPMap(threshold, month, famousMap):
    path = os.path.join(ip_popularity_input_path, "ip_pp_" + month)
    
    f = open(path, "r")
    while True:
        line = f.readline()
        if not line: break

        line = json.loads(line)
        date = "20"+line['date']

        famousSet = set([])
        mx_ips = line['mx_ip_len']
        for mx_ip in mx_ips:
            ip = mx_ip[0]
            mxs = mx_ip[1]

            if len(mxs) > threshold:
                famousSet.update(mxs)
        famousMap[date].append(list(famousSet))
    f.close()

    return famousMap


def filterDate(d):
    date = d['year'] + d['month'] + d['day']
    if datetime.datetime.strptime(date, "%Y%m%d") < datetime.datetime.strptime("20190712", "%Y%m%d"):
        return False
    if datetime.datetime.strptime(date, "%Y%m%d") > datetime.datetime.strptime("20210211", "%Y%m%d"):
        return False
    return True


def run(sc):
    months =["1907", "1908", "1909", "1910", "1911", "1912", "2001", "2002", "2003", "2004", "2005", "2006", "2007", "2008", "2009", "2010", "2011", "2012", "2101", "2102"]
  
    mxSLDMap, nsSLDMap = getSLDCluster()
    for month in months:
        famousMap = {}
        famousMap = getFamousMXSLD(50, month, mxSLDMap, famousMap)
        famousMap = getFamousNSSLD(50, month, nsSLDMap, famousMap)
        famousMap = getIPMap(50, month, famousMap)
   
        dates = famousMap.keys()

        for date in dates:
            if len(famousMap[date]) < 3:
                print(famousMap[date])
                print(date, len(famousMap[date]))
                exit()

        famousMapG = sc.broadcast(famousMap)
        mxSLDMapG = sc.broadcast(mxSLDMap)
        nsSLDMapG = sc.broadcast(nsSLDMap)

        k = sc.textFile(os.path.join(input_path, "20" + month[:2] + "_" + month[2:] + ".txt"))\
                .map(fromjson)\
                .filter(filterDate)\
                .map(lambda x: getCase(x, famousMapG, mxSLDMapG, nsSLDMapG))\
                .map(tojson)

        k.saveAsTextFile("case_output_" + month)


if __name__ == "__main__":
    sc = SparkContext(appName="DANE-Mgmt-Case-Classification")
    run(sc)
    sc.stop()
