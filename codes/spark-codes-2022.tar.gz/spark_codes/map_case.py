#!/usr/bin/python3
from pyspark import SparkContext, SparkConf
from pyspark.sql import SparkSession
from pyspark.sql.types import StructType, StructField, StringType, ArrayType
import pyspark.sql.functions as F

import datetime
import os
import json


dane_validation_input_path = "/path/to/dane_output_[date] (ex. 1907)/"
case_input_path = "/path/to/case_output_[date (ex. 1907)]"


def fromjson(d):
   return json.loads(d)

def tojson(d):
    return json.dumps(d)


def nextDate(date):
    convertedDate = datetime.datetime.strptime(date, "%Y%m%d")
    convertedDate = convertedDate + datetime.timedelta(days=1)
    convertedDate = convertedDate.strftime("%Y%m%d")
    return convertedDate   


def split_third_case(d):

    date = nextDate(d['date'])
    
    domain = d['domain']
    mxCase = int(d['mx_case'])
    nsCase = int(d['ns_case'])
    mxFirstParties = d['mx_first_party']
    mxOutsourcings = d['mx_outsourcing']
    nsFirstParties = d['ns_first_party']
    nsOutsourcings = d['ns_outsourcing']

    results = []

    if mxCase == -1:
        case = "None"
        mx_list = mxFirstParties + mxOutsourcings
        ns_list = []
        results.append((case, mx_list, ns_list))
    else:
        if mxCase == 1:
            case = "MO"
            mx_list = mxOutsourcings
            ns_list = []
            results.append((case, mx_list, ns_list))
        elif mxCase == 2:
            if nsCase == -1:
                case = "None"
                mx_list = mxFirstParties + mxOutsourcings
                ns_list = []
                results.append((case, mx_list, ns_list))
            elif nsCase == 1:
                case = "MSDO"
                mx_list = mxFirstParties
                ns_list = nsOutsourcings
                results.append((case, mx_list, ns_list))
            elif nsCase == 2:
                case = "MSDS"
                mx_list = mxFirstParties
                ns_list = nsFirstParties
                results.append((case, mx_list, ns_list))
            else: # nsCase == 3
                # DNS outsourcing
                case = "MSDO"
                mx_list = mxFirstParties
                ns_list = nsOutsourcings
                results.append((case, mx_list, ns_list))
                
                # DNS self-hosting
                case = "MSDS"
                ns_list = nsFirstParties
                results.append((case, mx_list, ns_list))
        else: # mxCase == 3
            if nsCase == -1:
                case = "None"
                mx_list = mxFirstParties + mxOutsourcings
                ns_list = []
                results.append((case, mx_list, ns_list))
            elif nsCase == 1:
                # Mail outsourcing
                case = "MO"
                mx_list = mxOutsourcings
                ns_list = []
                results.append((case, mx_list, ns_list))

                # Mail self-hosting
                case = "MSDO"
                mx_list = mxFirstParties
                ns_list = nsOutsourcings
                results.append((case, mx_list, ns_list))
            elif nsCase == 2:
                # Mail outsourcing
                case = "MO"
                mx_list = mxOutsourcings
                ns_list = []
                results.append((case, mx_list, ns_list))

                # Mail self-hosting
                case = "MSDS"
                mx_list = mxFirstParties
                ns_list = mxFirstParties
                results.append((case, mx_list, ns_list))
            else: # nsCase == 3
                # Mail outsourcing
                case = "MO"
                mx_list = mxOutsourcings
                ns_list = []
                results.append((case, mx_list, ns_list))

                # Mail self-hosting, DNS outsourcing
                case = "MSDO"
                mx_list = mxFirstParties
                ns_list = nsOutsourcings
                results.append((case, mx_list, ns_list))

                # Mail self-hosting, DNS self-hosting
                case = "MSDS"
                mx_list = mxFirstParties
                ns_list = nsFirstParties
                results.append((case, mx_list, ns_list))

    returns = []
    for val in results:
        mx_list = val[1]
        for mx in mx_list:
            returns.append([mx, date, domain, val[0], val[2]])

    return returns


def merge_data(d):
    domain = d[0][0]
    case = d[0][1]
    date = d[0][2]
    dataList = [t for t in d[1]]
    
    mergedMap = {}
    for data in dataList:
        mx = data[0]
        ns = data[4]
        hour = data[5]

        if not hour in mergedMap:
            mergedMap[hour] = {"date": date, "hour": hour, "domain": domain, "case": case, "validity": -3, "valid_mx": [], "invalid_mx": [], "not_crawled_mx": [], "not_used_mx": [], "ns": ns}
        
        validations = data[7]
        if validations == None:
            mergedMap[hour]["not_used_mx"].append(mx)
            continue

        if "-1" in validations or "-2" in validations:
            mergedMap[hour]["not_crawled_mx"].append(mx)
        elif "0" in validations:
            mergedMap[hour]["valid_mx"].append(mx)
        else:
            mergedMap[hour]["invalid_mx"].append(mx)

    if (None in mergedMap) and (not len(mergedMap.keys()) == 1):
        tmp = mergedMap[None]
        del mergedMap[None]
        hours = mergedMap.keys()
        for hour in mergedMap:
            mergedMap[hour]["not_used_mx"] += tmp["not_used_mx"]

    hours = mergedMap.keys()
    returns = []
    for hour in hours:
        merged = mergedMap[hour]
        if (len(merged["not_crawled_mx"]) + len(merged["valid_mx"]) + len(merged["invalid_mx"])) == 0:
            merged["validity"] = -2
        else:
            if len(merged["invalid_mx"]) > 0:
                merged["validity"] = 0
            else:
                if len(merged["not_crawled_mx"]) > 0:
                    merged["validity"] = -1
                else:
                    merged["validity"] = 1
        returns.append(merged)

    return returns


def split_validation_result(d):
    data = d.split(" ")

    results = [data[0], data[2], data[3], data[8], data[10:]]

    return results

def filter_no_date(d):
    if (d["date"] == None) or (d["hour"] == None):
        return False
    return True


def run(sc):
    months = ["1907", "1908", "1909", "1910", "1911", "1912", "2001", "2002", "2003", "2004", "2005", "2006", "2007", "2008", "2009", "2010" ,"2011", "2012", "2101", "2102"]

    validation_data_header = ["mx", "date", "hour", "dnssec", "validations"]
    domain_data_schema = StructType([StructField("mx", StringType(), True), StructField("date", StringType(), True), StructField("domain", StringType(), True), StructField("case", StringType(), True), StructField("ns_list", ArrayType(StringType(), True), True)])

    validation_data = sc.sparkContext.textFile(os.path.join(dane_validation_input_path, "dane_output_*"))\
            .map(split_validation_result)
    validation_df = validation_data.toDF(validation_data_header)
  
    for month in months:
        domain_data = sc.sparkContext.textFile(os.path.join(case_input_path, "case_output_" + month))\
                .map(fromjson)\
                .map(split_third_case)\
                .flatMap(lambda list: list)
        domain_df = sc.createDataFrame(domain_data, schema=domain_data_schema)
  
        # mx, date, domain, case, ns_list, hour, dnssec, validations
        joined_df = domain_df.join(validation_df, ["mx", "date"], "left")\
                .rdd\
                .map(list)
        
        # domain, case, date
        k = joined_df.groupBy(lambda x: (x[2], x[3], x[1]))\
                .map(merge_data)\
                .flatMap(lambda list: list)\
                .map(tojson)\

        k.saveAsTextFile("case_hour_output_" + month)


if __name__ == "__main__":
    conf = SparkConf().setAppName("")
    sc = SparkContext(appName="DANE-Mgmt-Case-Validity-Merge", conf=conf)
    spark = SparkSession(sc)
    run(spark)
    sc.stop()
