#!/usr/bin/python3
from pyspark import SparkContext, SparkConf

import csv
import datetime
import os
import base64
import json


input_path = "/path/to/input"
public_intermediate_cert_input = "/path/to/PublicAllIntermediateCertsReport.csv"
public_intermediate_revoked_cert_input = "/path/to/PublicIntermediateCertsRevokedReport.csv"
antago_syix_mx_input_path = "/path/to/antago_syix_mx/"
mx_wo_nl_input_path = "/path/to/all-mx-exclude-nl.txt"


def tojson(d):
    return json.loads(d)

def toCSV(d):
    return " ".join(str(x) for x in d)


def getCN(d, antagonistMx):
    from OpenSSL import crypto

    antagoFlag = False
    if d['domain'] in antagonistMx.value:
        antagoFlag = True

    if not 'certs' in d['starttls']:
        return (d['time'], "NoData", -1, antagoFlag)

    crt = base64.b64decode(d['starttls']['certs'][0])
    crt = crypto.load_certificate(crypto.FILETYPE_PEM, crt)
    issuer = crt.get_issuer()
    
    if issuer == None or issuer.O == None:
        return (d['time'], "None", -1, antagoFlag)

    if issuer.O == "Let's Encrypt":
        if "X3" in issuer.CN:
            tag = "X3"
        elif "E1" in issuer.CN:
            tag = "E1"
        elif "R3" in issuer.CN:
            tag = "R3"
        elif "X1" in issuer.CN:
            tag = "X1"
        return (d['time'], issuer.CN, tag, antagoFlag)
    
    return (d['time'], issuer.CN, -1, antagoFlag)


def getDateStat(d, pkiCA):
    time = d[0]

    dataList = d[1]
    
    total = 0
    noData = 0
    pki = 0
    le = 0
    x3 = 0
    e1 = 0
    r3 = 0
    x1 = 0

    total_wo_at = 0
    noData_wo_at = 0
    pki_wo_at = 0
    le_wo_at = 0
    x3_wo_at = 0
    e1_wo_at = 0
    r3_wo_at = 0
    x1_wo_at = 0

    for data in dataList:
        antagoFlag = data[3]
        total += 1
        if data[1] == "NoData":
            noData += 1
        else:
            if data[1] in pkiCA.value:
                pki += 1

                if data[2] == "X3":
                    le += 1
                    x3 += 1
                elif data[2] == "E1":
                    le += 1
                    e1 += 1
                elif data[2] == "R3":
                    le += 1
                    r3 += 1
                elif data[2] == "X1":
                    le += 1
                    x1 += 1

        if not antagoFlag:
            total_wo_at += 1
            if data[1] == "NoData":
                noData_wo_at += 1
                continue

            if data[1] in pkiCA.value:
                pki_wo_at += 1

                if data[2] == "X3":
                    le_wo_at += 1
                    x3_wo_at += 1
                elif data[2] == "E1":
                    le_wo_at += 1
                    e1_wo_at += 1
                elif data[2] == "R3":
                    le_wo_at += 1
                    r3_wo_at += 1
                elif data[2] == "X1":
                    le_wo_at += 1
                    x1_wo_at += 1
            


    return (time.replace(" ", "-"), total, noData, pki, le, x1, x3, e1, r3, total_wo_at, noData_wo_at, pki_wo_at, le_wo_at, x1_wo_at, x3_wo_at, e1_wo_at, r3_wo_at)



def readPKICAs():

    cas = set([])
    with open(public_intermediate_cert_input, ,"r") as csvFile:
        reader = csv.reader(csvFile)
        next(reader)
        for row in reader:
            cas.add(row[5])
    
    with open(public_intermediate_revoked_cert_input, "r") as csvFile:
        reader = csv.reader(csvFile)
        next(reader)
        for row in reader:
            cas.add(row[9])

    return cas
    

def filterAntagonist(d, antagonistMx):
    mx = d['domain']
    return (not (mx in antagonistMx.value))


def getAntago():
    mxs = set([])
    path = os.path.join(antago_syix_mx_input_path, "antago_syix_mx/")
    files = os.listdir(path)
    for filename in files:
        f = open(path + filename, "r")
        while True:
            line = f.readline()
            if not line: break
            line = line.strip().split()

            if line[-1] == "Antagonist":
                mxs.add(line[0])
        f.close()

    return mxs



def filterNL(d, mxs):
    return (d['domain'] in mxs.value)


def getTargetMX():
    mxs = []
    f = open(os.path.join(mx_wo_nl_input_path, "all-mx-exclude-nl.txt"), "r")
    while True:
        line = f.readline()
        if not line: break

        mxs.append(line.strip())
    f.close()
    return mxs


def run(sc):

    pkiCA = readPKICAs()
    pkiCA_G = sc.broadcast(pkiCA)

    antagonistMx = getAntago()
    antagonistMxG = sc.broadcast(antagonistMx)

    mxs = getTargetMX()
    mxsG = sc.broadcast(mxs)

    k = sc.textFile(input_path)\
            .map(tojson)\
            .filter(lambda d: filterNL(d, mxsG))\
            .map(lambda x: getCN(x, antagonistMxG))\
            .groupBy(lambda x: x[0])\
            .map(lambda x: getDateStat(x, pkiCA_G))\
            .map(toCSV)

    k.saveAsTextFile("cert_pki_cn_stat")


if __name__ == "__main__":
    sc = SparkContext(appName="DANE-Cert-PKI-CN")
    run(sc)


