#!/usr/bin/python3
from pyspark import SparkContext, SparkConf

import sys, os
import dns as mydns
import dns.message as mymessage
import base64
from OpenSSL import crypto
import json
import datetime
import hashlib
import csv
import binascii

root_cert_path = "/path/to/root_cert_store" # ex) /etc/ssl/certs/
rollover_groupby_input_path = "/path/to/rollover_groupby/"
dependency_path = "/path/to/dependencies.zip"


def fromjson(line):
    return json.loads(line)

def tojson(line):
    return json.dumps(line)

def toCSV(line):
    return " ".join(str(d) for d in line)


def parseTLSA(encoded):
    msg = base64.b64decode(encoded)
    msg = mymessage.from_wire(msg)
    rrset = []

    usages = set([])
    for answer in msg.answer:
        if answer.rdtype == 52:
            rrset = rrset + [data.to_text() for data in answer]

    return rrset


def getTLSA(d):
    if 'tlsa' in d:
        rrset = parseTLSA(d['tlsa']['record_raw'])
        return rrset
    return None
    

def getCert(d):
    if 'certs' in d['starttls']:
        certs = d['starttls']['certs']
    else:
        return None, None

    if len(certs) > 1:
        return certs[0], certs[1:]
    else:
        return certs[0], None


def getKey(d):
    from OpenSSL import crypto
    
    if 'certs' in d['starttls']:
        certs = d['starttls']['certs']
    else:
        return None, None

    keys = []
    for cert in certs:
        crt = base64.b64decode(cert)
        crt = crypto.load_certificate(crypto.FILETYPE_PEM, crt)
        key = crt.get_pubkey()
        key = crypto.dump_publickey(crypto.FILETYPE_ASN1, key)
        key = base64.b64encode(key).decode()
        keys.append(key)

    if len(keys) > 1:
        return keys[0], keys[1:]
    else:
        return keys[0], None


def matchCrt(matching, data, crt):
    from OpenSSL import crypto
    
    if matching == '0':
        data = data.lower()
        hashed = binascii.b2a_hex(crt).decode()
    elif matching == '1':
        data = data.lower()
        hashed = hashlib.sha256(crt).hexdigest()
    elif matching == '2':
        data = data.lower()
        hashed = hashlib.sha512(crt).hexdigest()
    else:
        return False, "Matching-"+matching

    if hashed == data:
        return True, None
    return False, "CrtNotMatch"

def matchKey(matching, data, key):
    from OpenSSL import crypto
    if matching == '0':
        data = data.lower()
        hashed = binascii.b2a_hex(key).decode()
    elif matching == '1':
        data = data.lower()
        hashed = hashlib.sha256(key).hexdigest()
    elif matching == '2':
        data = data.lower()
        hashed = hashlib.sha512(key).hexdigest()
    else:
        return False, "Matching-"+matching

    if hashed == data:
        return True, None
    return False, "KeyNotMatch"


def findRoot(cert, root_certs_map):
    from OpenSSL import crypto
    crt = base64.b64decode(cert)
    crt = crypto.load_certificate(crypto.FILETYPE_PEM, crt)
    issuer = crt.get_issuer()

    if issuer == None:
        return None

    roots = set(root_certs_map.value.keys())

    if issuer.CN in roots:
        root = base64.b64encode(root_certs_map.value[issuer.CN].encode())
        return root
    return None

def isRoot(cert):
    from OpenSSL import crypto
    crt = base64.b64decode(cert)
    crt = crypto.load_certificate(crypto.FILETYPE_PEM, crt)
    issuer = crt.get_issuer()
    subject = crt.get_subject()
    
    if issuer == None or subject == None:
        return False

    if issuer.CN == subject.CN:
        return True
    return False



def unitValidation(record, certs, root_certs_map):
    from OpenSSL import crypto

    record = record.split()
    if len(record) != 4:
        record = record[:3] + [''.join(record[3:])]
    usage = record[0]
    selector = record[1]
    matching = record[2]
    data = record[3]
  
    if usage == '1' or usage == '3':
        
        pem = base64.b64decode(certs[0])
        crt = crypto.load_certificate(crypto.FILETYPE_PEM, pem)
        # use entire certificate
        if selector == '0':
            crt = crypto.dump_certificate(crypto.FILETYPE_ASN1, crt)
            matched, error = matchCrt(matching, data, crt)
            return matched

        # use public key
        elif selector == '1':
            pubKey = crt.get_pubkey()
            pubKey = crypto.dump_publickey(crypto.FILETYPE_ASN1, pubKey)
            matched, error = matchKey(matching, data, pubKey)
            return matched
        else:
            return False
    elif usage == '0':
        if isRoot(certs[-1]):
            tmpCerts = certs
        else:
            root = findRoot(certs[-1], root_certs_map)
            if root == None:
                tmpCerts = certs
            else:
                tmpCerts = certs + [root]
        
        for cert in tmpCerts[1:]:
            pem = base64.b64decode(cert)
            crt = crypto.load_certificate(crypto.FILETYPE_PEM, pem)

            if selector == '0':
                crt = crypto.dump_certificate(crypto.FILETYPE_ASN1, crt)
                matched, error = matchCrt(matching, data, crt)
                if matched:
                    return matched
            elif selector == '1':
                pubKey = crt.get_pubkey()
                pubKey = crypto.dump_publickey(crypto.FILETYPE_ASN1, pubKey)
                matched, error = matchKey(matching, data, pubKey)
                if matched:
                    return matched
            else:
                return False
    
        return False
    elif usage == '2':

        for idx, cert in enumerate(certs[1:]):
            pem = base64.b64decode(cert)
            crt = crypto.load_certificate(crypto.FILETYPE_PEM, pem)

            # use entire certificate
            if selector == '0':
                crt = crypto.dump_certificate(crypto.FILETYPE_ASN1, crt)
                matched, error = matchCrt(matching, data, crt)
                if matched:
                    return matched
            elif selector == '1':
                pubKey = crt.get_pubkey()
                pubKey = crypto.dump_publickey(crypto.FILETYPE_ASN1, pubKey)
                matched, error = matchKey(matching, data, pubKey)
                if matched:
                    return matched
            else:
                return False
        return False
    else:
        return False



def validation(tlsaRecords, certs, root_certs_map):
   
    results = []
    for record in tlsaRecords:
        valid = unitValidation(record, certs, root_certs_map)
        if valid:
            return True
        else:
            results.append(valid)
    
    if results == [] or None in results:
        a = 0/0

    return False


def check_matched_before(tlsa, data_list, root_certs_map):
    for data in data_list:
        leaf_cert, other_certs = getCert(data)
        if leaf_cert == None:
            continue

        certs = [leaf_cert]
        if not other_certs == None:
            certs = certs + other_certs

        is_matched = validation(tlsa, certs, root_certs_map)
        if is_matched:
            return True
    
    return False


def check_ever_matched(d, root_certs_map):
    mx = d['dn']
    data_list = d['list']
    
    ever_matched = False
    tlsa_matched_map = {}

    '''
    result code
    -1: No TLSA
    -2: No Certs
    0: current tlsa and certs are matched
    1: current tlsa is not matched ever
    2: current tlsa is not matched now but matched before
    '''
    results = []
    for idx, data in enumerate(data_list):
        date = data['time'].split()[0]
        hour = data['time'].split()[1]
        tlsa = getTLSA(data)
        if tlsa == None:
            results.append([mx, date, hour, -1])
            continue
        tlsa.sort()

        leaf_cert, other_certs = getCert(data)
        if leaf_cert == None:
            results.append([mx, date, hour, -2])
            continue

        certs = [leaf_cert]
        if not other_certs == None:
            certs = certs + other_certs

        is_matched = validation(tlsa, certs, root_certs_map)
        if is_matched:
            results.append([mx, date, hour, 0])
            tlsa_matched_map[" ".join(tlsa)] = True
        else:

            if " ".join(tlsa) in tlsa_matched_map:
                results.append([mx, date, hour, 2])
            else:
                matched_before = check_matched_before(tlsa, data_list[:idx], root_certs_map)
                if matched_before:
                    results.append([mx, date, hour, 2])
                    tlsa_matched_map[" ".join(tlsa)] = True
                else:
                    results.append([mx, date, hour, 1])

    return results

        
def getRootCertsMap():
    root_certs_map = {}

    files = os.listdir(root_cert_path)
    files.remove("java")

    for filename in files:
        f = open(root_cert_path + filename, "r")
        cert = f.read()
        crt = crypto.load_certificate(crypto.FILETYPE_PEM, cert)
        issuer = crt.get_issuer().CN

        root_certs_map[issuer] = cert
        f.close()

    return root_certs_map


def getStats(sc):
    root_certs_map = getRootCertsMap()
    root_certs_mapG = sc.broadcast(root_certs_map)

    k = sc.textFile(os.path.join(rollover_groupby_input_path, "rollover_groupby/*"))\
            .map(fromjson)\
            .map(lambda x: check_ever_matched(x, root_certs_mapG))\
            .flatMap(lambda list: list)\
            .map(toCSV)
    
    k.saveAsTextFile("ever_matched")

if __name__ == "__main__":
    conf = SparkConf().setAppName("").set("spark.reducer.maxBlocksInFlightPerAddress", "1000")
    sc = SparkContext(appName="DANE-Ever-Matched", conf=conf)
    sc.addPyFile(os.path.join(dependency_path, "dependencies.zip")) 
    getStats(sc)
    sc.stop()
