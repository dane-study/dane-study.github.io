#!/usr/bin/python3
from pyspark import SparkContext, SparkConf
from pyspark.sql import SparkSession
from pyspark.sql.types import StructType, StructField, StringType, IntegerType, ArrayType

import datetime
import os
import json


ever_matched_input_path = "/path/to/ever_matched/"
dane_incorrect_input_path = "/path/to/dane_incorrect_output/incorrect_output_[month]"
case_hour_input_path = "/path/to/case_hour_output/case_hour_output_[month]"
dependency_path = "/path/to/dependencies.zip"


def fromjson(d):
    return json.loads(d)

def toCSV(d):
    return " ".join(str(x) for x in d)


def extractMX(d):
    date = d[0][0]
    hour = d[0][1]
    dataList = d[1]

    results = {"MO": {"valid_mx":set([]), "invalid_mx":set([])}, "MSDO": {"valid_mx":set([]), "invalid_mx":set([])}, "MSDS": {"valid_mx":set([]), "invalid_mx":set([])}}

    for data in dataList:
        domain = data['domain']
        case = data['case']
        validity = data['validity']
      
        if case == "None":
            continue
        if validity < 0:
            continue

        if validity == 0:
            results[case]['invalid_mx'].update(data['invalid_mx'])
            results[case]['valid_mx'].update(data['valid_mx'])
        else:
            results[case]['valid_mx'].update(data['valid_mx'])

    returns = []
    time = date + "-" + hour
    for case in results.keys():
        for mx in results[case]['valid_mx']:
            returns.append([mx, date, hour, case, 1])
        for mx in results[case]['invalid_mx']:
            returns.append([mx, date, hour, case, 0])
    return returns


def getOtherReason(details):
   
    for idx in range(int(len(details)/7)):
        detail = details[idx*7:(idx+1)*7+1]

        if detail[0] == "0":
            index = detail[5].split("/")[0]
            if index == "1":
                return "usage"
        elif detail[0] == "1":
            index = detail[5].split("/")[0]
            if not index == "1":
                return "usage"
        elif detail[0] == "2":
            index = detail[5].split("/")[0]
            if index == "1":
                return "usage"
        elif detail[0] == "3":
            index = detail[5].split("/")[0]
            if not index == "1":
                return "usage"
        else:
            x = 1/0


        if detail[1] == "0":
            selector = "crt"
        else:
            selector = "key"
        if detail[2] == "0":
            matching = "Raw"
        elif detail[2] == "1":
            matching = "256"
        else:
            matching = "512"

        realSelector = detail[4][:3]
        realMatching = detail[4][3:]

        if not selector == realSelector:
            return "selector"
        if not matching == realMatching:
            return "matching_type"

    x = 1/0


def getFailDetails(stats, outlier_stats, everValid, results):

    unknown = False
    matching = False
    dnssec = results[0]
    chain = results[1]

    if dnssec == "Insecure":
        stats["dnssec"] += 1
        stats["insecure"] += 1
        outlier_stats["dnssec"] += 1

    if dnssec == "Bogus":
        stats["dnssec"] += 1
        stats["bogus"] += 1
        outlier_stats["dnssec"] += 1

    if chain == "WrongChain":
        stats["chain"] += 1
        outlier_stats["chain"] += 1
   
    if not results[2] == "Matched":
        matching = True
        stats["unmatch"] += 1
        outlier_stats["unmatch"] += 1
        if results[2] == "NoCase":
            stats["unknown"] += 1
            unknown = True
        elif results[2] == "WeirdField":
            stats["undefined"] += 1
        elif results[2] == "OtherReason":
            reason = getOtherReason(results[3:])
            stats[reason] += 1
        else:
            exit()

    if (not matching) and (chain == "CorrectChain") and (dnssec == "Insecure"):
        stats['ds_only'] += 1

    if unknown and (everValid == "2"):
        stats["ever_matched"] += 1

    return stats, outlier_stats


def getPerCaseStat(d):
    
    date = d[0][0]
    hour = d[0][1]
    case = d[0][2]
    
    dataList = d[1]
    
    stats = {"total":0, "NoCerts":0, "NoTLSA":0, "invalid":0,"dnssec":0, "insecure":0, "bogus":0, "ds_only":0, "unmatch":0, "usage":0, "selector":0, "matching_type":0, "undefined":0, "unknown":0, "chain":0, "ever_matched":0}
    antago_stats = {"invalid":0, "dnssec":0, "unmatch":0, "chain":0}
    syix_stats = {"invalid":0, "dnssec":0, "unmatch":0, "chain":0}
    dummy = {"invalid":0, "dnssec":0, "unmatch":0, "chain":0}
    for data in dataList:
        everValid = data[6]
        if everValid == None:
            xx = 100/0
    
        outlier_check = data[7]
        if case == "MO":
            if outlier_check == None:
                is_outlier = 0
            elif outlier_check == "Antagonist":
                is_outlier = 1
            elif outlier_check == "Syix":
                is_outlier = 2
            else :
                yy = 300/0
        else:
            is_outlier = 0

        validity = data[4] 
        results = data[5]

        stats["total"] += 1
        
        if "Correct" in results:
            continue

        if "NoCerts" in results:
            stats["NoCerts"] += 1
            continue
        if "NoTLSA" in results:
            stats["NoTLSA"] += 1
            continue
        
        if not validity == 0:
            x = 2/0

        stats["invalid"] += 1
        if is_outlier == 0:
            stats, dummy = getFailDetails(stats, dummy, everValid, results)
        elif is_outlier == 1:
            antago_stats["invalid"] += 1
            stats, antago_stats = getFailDetails(stats, antago_stats, everValid, results)
        elif is_outlier == 2:
            syix_stats["invalid"] += 1
            stats, syix_stats = getFailDetails(stats, syix_stats, everValid, results)
        else:
            x = 3/0

    return (date, hour, case,\
            stats["total"], stats["NoCerts"], stats["NoTLSA"], stats["invalid"],\
            stats["dnssec"], stats["insecure"], stats["bogus"], stats["ds_only"],\
            stats["unmatch"], stats["usage"], stats["selector"], stats["matching_type"], stats["undefined"],\
            stats["unknown"], stats["chain"], stats["ever_matched"],\
            antago_stats["invalid"], antago_stats["dnssec"], antago_stats["unmatch"], antago_stats["chain"],\
            syix_stats["invalid"], syix_stats["dnssec"], syix_stats["unmatch"], syix_stats["chain"])
    

def split_validation_result(d):
    data = d.split(" ")

    mx = data[0]
    date = data[2]
    hour = data[3]
    results = data[4:]

    return [mx, date, hour, results]


def filterNoData(d):
    if d["hour"] == None:
        return False
    return True


def run(sc):
    
    ever_matched_df_header = ["mx", "date", "hour", "ever_matched"]
    ever_matched_df = sc.sparkContext.textFile(os.path.join(ever_matched_input_path, "ever_matched"))\
            .map(lambda x: x.split(" "))\
            .toDF(ever_matched_df_header)
    
    validation_df_header = ["mx", "date", "hour", "validations"]
    validation_data = sc.sparkContext.textFile(os.path.join(dane_incorrect_input_path, "incorrect_output_*"))\
            .map(split_validation_result)\
            .toDF(validation_df_header)
 
    # mx, date, hour, validations, ever_matched
    validation_data_tmp = validation_data.join(ever_matched_df, ["mx", "date", "hour"], "left")

    outlier_df_header = ["mx", "date", "hour", "outlier_check"]
    outlier_df = sc.sparkContext.textFile("antago_syix_mx")\
            .map(lambda x: x.split(" "))\
            .toDF(outlier_df_header)

    # mx, date, hour, validations, ever_matched, outlier_check
    validation_df = validation_data_tmp.join(outlier_df, ["mx", "date", "hour"], "left")

    months = ["1907", "1908", "1909", "1910", "1911", "1912", "2001", "2002", "2003", "2004", "2005", "2006", "2007", "2008", "2009", "2010" ,"2011", "2012", "2101", "2102"]

    for month in months:
        mx_df_header = ["mx", "date", "hour", "case", "validity"]
        mx_df = sc.sparkContext.textFile(os.path.join(case_hour_input_path, "case_hour_output_" + month))\
                .map(fromjson)\
                .filter(filterNoData)\
                .groupBy(lambda d: (d['date'], d['hour']))\
                .map(extractMX)\
                .flatMap(lambda list: list)\
                .toDF(mx_df_header)\

        # mx, date, hour, case, validity, validations, ever_matched, outlier_check
        joined_df = mx_df.join(validation_df, ["mx", "date", "hour"], "left")\
                .rdd\
                .map(list)
        
        k = joined_df.groupBy(lambda d: (d[1], d[2], d[3]))\
                .map(getPerCaseStat)\
                .map(toCSV)
        
        k.saveAsTextFile("case_tlsa_stat_" + month)


if __name__ == "__main__":

    conf = SparkConf().setAppName("")
    sc = SparkContext(appName="DANE-Mgmt-Case-MX-Stat", conf=conf)
    sc.addPyFile(os.path.join(dependency_path, "dependencies.zip"))
    spark = SparkSession(sc)
    run(spark)
    sc.stop()


