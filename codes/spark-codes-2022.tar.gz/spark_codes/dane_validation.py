#!/usr/bin/python3
from pyspark import SparkContext, StorageLevel, SparkConf

import sys, os
import dns as mydns
import dns.message as mymessage
import base64
from OpenSSL import crypto
import hashlib
import json
import re
import subprocess
import struct
import time
import random
import shutil
import datetime
import binascii


input_path = "/path/to/input"
dependency_path = "/path/to/dependencies.zip"
temp_cert_path = "/path/to/spark_temporary_path_for_cert_validation"
ca_bundle_path = "/path/to/root-ca-list"
root_cert_path = "/path/to/root_cert_store" # ex) /etc/ssl/certs/
faketime_path = "/path/to/libfaketime.so" # ex) /usr/lib/x86_64-linux-gnu/faketime/libfaketime.so.1


def make_name():
    make_name_size = 2**16-1
    return struct.pack(">dHL", time.time(), random.randint(0, make_name_size), os.getpid()).hex()

def fromjson(line):
    return json.loads(line)

def toCSV(data):
    return " ".join(str(d) for d in data)

def tlsaCrawled(d):
    return int ('tlsa' in d)

def dnssec(d):
    '''    
    #Return
    -1: TLSA is not crawled
    0: Secure
    1: Insecure
    2~: Bogus classification
    -1000: Wrong value
    '''

    if not 'tlsa' in d:
        return -1

    if 'tlsa' in d:
        dnssec = d['tlsa']['dnssec']
        if dnssec == "Secure":
            return 0
        elif dnssec == "Insecure":
            return 1
        elif dnssec == "Bogus":
            why_bogus = d['tlsa']['why_bogus']
            if "signature expired" in why_bogus:
                return 2
            elif "no keys have a DS" in why_bogus:
                return 3
            elif "DS hash mismatches" in why_bogus:
                return 4
            elif "wildcard proof failed" in why_bogus:
                return 5
            elif "No DNSKEY record" in why_bogus:
                return 6
            elif "signature crypto failed" in why_bogus:
                return 7
            elif "signature missing from" in why_bogus:
                return 8
            elif "cname proof failed" in why_bogus:
                return 9
            elif "no DS" in why_bogus:
                return 10
            elif "signature before inception date" in why_bogus:
                return 11
            elif "no signatures" in why_bogus:
                return 12
            elif "signatures from unknown keys" in why_bogus:
                return 13
            elif "no DNSSEC records" in why_bogus:
                return 14
            elif "signature inception after expiration" in why_bogus:
                return 15
            elif "no NSEC3 records from" in why_bogus:
                return 16
            else:
                return 17, why_bogus
        else:
            return -1000


def starttlsCrawled(d):
    return int ('certs' in d['starttls'])

def getStarttlsErr(d):
    '''
    #Return
    -2: NoData
    -1: None (STARTTLS certificate is crawled)
    
    case0: 4* 
    case1: 50*
    case2: 55*
    case3: tcp
    case4: tls
    case5: 1*
    case6: 2*
    csee7: 3*
    case8: etc
    '''

    case0 = ["4"]
    case1 = ["500", "502", "503", "504"]
    case2 = ["551", "550", "554"]
    case3 = ["dial tcp", "write tcp", "read tcp"]
    case4 = ["remote error", "tls"]
    case5 = ["1"]
    case6 = ["2"]
    case7 = ["3"]

    if 'why_fail' in d['starttls']:
        why_fail = d['starttls']['why_fail']
        domain = d['domain']
        for code in case0:
            codeLen = len(code)
            if why_fail[:codeLen] == code:
               return "0"

        for code in case1:
            codeLen = len(code)
            if why_fail[:codeLen] == code:
                return "1"
        for code in case2:
            codeLen = len(code)
            if why_fail[:codeLen] == code:
                return "2" 
        for code in case3:
            codeLen = len(code)
            if why_fail[:codeLen] == code:
                return "3" 
        for code in case4:
            codeLen = len(code)
            if why_fail[:codeLen] == code:
                return "4"
        for code in case5:
            codeLen = len(code)
            if why_fail[:codeLen] == code:
                return "5"
        for code in case6:
            codeLen = len(code)
            if why_fail[:codeLen] == code:
                return "6"
        for code in case7:
            codeLen = len(code)
            if why_fail[:codeLen] == code:
                return "7"

        if why_fail == "NoData":
            return -2
        return "8"
    return -1


def parseTLSA(raw):
    msg = base64.b64decode(raw)
    msg = mymessage.from_wire(msg)
    rrsetList = []

    for answer in msg.answer:
        if answer.rdtype == 52:
            rrsetList = rrsetList + [data.to_text() for data in answer]
    return rrsetList

def matchCrt(matching, data, crt):
    from OpenSSL import crypto
    
    if matching == '0':
        data = data.lower()
        hashed = binascii.b2a_hex(crt).decode()
    elif matching == '1':
        data = data.lower()
        hashed = hashlib.sha256(crt).hexdigest()
    elif matching == '2':
        data = data.lower()
        hashed = hashlib.sha512(crt).hexdigest()
    else:
        return False, "Matching-"+matching

    if hashed == data:
        return True, None
    return False, "CrtNotMatch"

def matchKey(matching, data, key):
    from OpenSSL import crypto
    if matching == '0':
        data = data.lower()
        hashed = binascii.b2a_hex(key).decode()
    elif matching == '1':
        data = data.lower()
        hashed = hashlib.sha256(key).hexdigest()
    elif matching == '2':
        data = data.lower()
        hashed = hashlib.sha512(key).hexdigest()
    else:
        return False, "Matching-"+matching

    if hashed == data:
        return True, None
    return False, "KeyNotMatch"


def chainValid(usage, time, certs, idx, cert_path, root_certs):
    from OpenSSL import crypto
    
    '''
    #Return
    False (Chain is valid)
    True (Chain is not valid)
    '''

    if usage == "3":
        return "Empty", ""

    certNum = len(certs)
    leaf = base64.b64decode(certs[0]).decode()

    while True:
        tmp_folder = "ssl_verify_" + make_name()
        base_path = os.path.join(cert_path.value, tmp_folder)
        if not os.path.isdir(base_path):
            os.makedirs(base_path)
            break

    leaf_filename = os.path.join(base_path, "leaf.pem")
    f_leaf = open(leaf_filename, "w")
    f_leaf.write(leaf)
    f_leaf.close()

    root_filename = os.path.join(base_path, "root.pem")
    f_root = open(root_filename, "w")
    f_root.write(root_certs.value)
    f_root.close()

    eTime = datetime.datetime.strptime(time, "%Y%m%d %H:%M:%S")
    eTime = str(int(eTime.timestamp()))

    if certNum == 1:
        if usage == "0" or usage == "1":
            query = ['openssl', 'verify', '-attime', eTime, '-CAfile', root_filename, leaf_filename]
        else:
            shutil.rmtree(base_path)
            return False, ""
    else:
        inter = ""
        if usage == "0" or usage == "1":
            for cert in certs[1:]:
                inter = inter + base64.b64decode(cert).decode() + "\n"
 
            inter_filename = os.path.join(base_path, "inter.pem")
            f_inter = open(inter_filename, "w")
            f_inter.write(inter)
            f_inter.close()

            query = ['openssl', 'verify', '-attime', eTime, '-CAfile', root_filename, '-untrusted', inter_filename, leaf_filename]
        
        else:
            
            if idx == -1:
                for cert in certs[1:]:
                    inter = inter + base64.b64decode(cert).decode() + "\n"
            else:
                for cert in certs[1:idx]:
                    inter = inter + base64.b64decode(cert).decode() + "\n"
 
            inter_filename = os.path.join(base_path, "inter.pem")
            f_inter = open(inter_filename, "w")
            f_inter.write(inter)
            f_inter.close()

            query = ['openssl', 'verify', '-attime', eTime, '-no-CApath', '-no-CAfile', '-partial_chain', '-trusted', inter_filename, leaf_filename]

 
    process = subprocess.Popen(query, stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=dict(os.environ, LD_PRELOAD=faketime_path))
    stdoutdata, stderrdata = process.communicate()
    result = stdoutdata.decode()

    shutil.rmtree(base_path)
    fails = ["error", "fail", "Error", "Expire"]
    for fail in fails:
        if fail in result:
            return False, result
    
    return True, stderrdata.decode()


def findRoot(cert, root_certs_map):
    from OpenSSL import crypto
    crt = base64.b64decode(cert)
    crt = crypto.load_certificate(crypto.FILETYPE_PEM, crt)
    issuer = crt.get_issuer()

    if issuer == None:
        return None

    roots = set(root_certs_map.value.keys())

    if issuer.CN in roots:
        root = base64.b64encode(root_certs_map.value[issuer.CN].encode())
        return root
    return None

def isRoot(cert):
    from OpenSSL import crypto
    crt = base64.b64decode(cert)
    crt = crypto.load_certificate(crypto.FILETYPE_PEM, crt)
    issuer = crt.get_issuer()
    subject = crt.get_subject()
    
    if issuer == None or subject == None:
        return False

    if issuer.CN == subject.CN:
        return True
    return False



def unitValidate(record, time, certs, cert_path, root_certs, root_certs_map):
    from OpenSSL import crypto

    record = record.split()
    if len(record) != 4:
        record = record[:3] + [''.join(record[3:])]
    usage = record[0]
    selector = record[1]
    matching = record[2]
    data = record[3]
  
    error = None
    chain = "Empty"
    if usage == '1' or usage == '3':
        
        pem = base64.b64decode(certs[0])
        crt = crypto.load_certificate(crypto.FILETYPE_PEM, pem)
        # use entire certificate
        if selector == '0':
            crt = crypto.dump_certificate(crypto.FILETYPE_ASN1, crt)
            matched, error = matchCrt(matching, data, crt)
            if usage == '1':
                chain, error = chainValid(usage, time, certs, -1, cert_path, root_certs)
                if error == "NoKey":
                    chain = "NoKey"
            if usage == '3':
                chain = "Empty"
            return matched, chain, error

        # use public key
        elif selector == '1':
            pubKey = crt.get_pubkey()
            pubKey = crypto.dump_publickey(crypto.FILETYPE_ASN1, pubKey)
            matched, error = matchKey(matching, data, pubKey)
            if usage == '1':
                chain, error = chainValid(usage, time, certs, -1, cert_path, root_certs)
                if error == "NoKey":
                    chain = "NoKey"
            if usage == '3':
                chain = "Empty"
            return matched, chain, error
        else:
            return False, chain, "Selector-"+selector
    elif usage == '0':
        if isRoot(certs[-1]):
            tmpCerts = certs
        else:
            root = findRoot(certs[-1], root_certs_map)
            if root == None:
                tmpCerts = certs
            else:
                tmpCerts = certs + [root]
        
        chain, error = chainValid(usage, time, tmpCerts, -1, cert_path, root_certs)
        
        for cert in tmpCerts[1:]:
            pem = base64.b64decode(cert)
            crt = crypto.load_certificate(crypto.FILETYPE_PEM, pem)

            if selector == '0':
                crt = crypto.dump_certificate(crypto.FILETYPE_ASN1, crt)
                matched, error = matchCrt(matching, data, crt)
                if matched:
                    return matched, chain, error
            elif selector == '1':
                pubKey = crt.get_pubkey()
                pubKey = crypto.dump_publickey(crypto.FILETYPE_ASN1, pubKey)
                matched, error = matchKey(matching, data, pubKey)
                if matched:
                    return matched, chain, error
            else:
                return False, chain, "Selector-"+selctor
    
        return False, chain, error
    elif usage == '2':

        chain, error = chainValid(usage, time, certs, -1, cert_path, root_certs)
        for idx, cert in enumerate(certs[1:]):
            pem = base64.b64decode(cert)
            crt = crypto.load_certificate(crypto.FILETYPE_PEM, pem)

            # use entire certificate
            if selector == '0':
                crt = crypto.dump_certificate(crypto.FILETYPE_ASN1, crt)
                matched, error = matchCrt(matching, data, crt)
                if matched:
                    chain, error2 = chainValid(usage, time, certs, idx+2, cert_path, root_certs)
                    return matched, chain, error
            elif selector == '1':
                pubKey = crt.get_pubkey()
                pubKey = crypto.dump_publickey(crypto.FILETYPE_ASN1, pubKey)
                matched, error = matchKey(matching, data, pubKey)
                if matched:
                    chain, error2 = chainValid(usage, time, certs, idx+2, cert_path, root_certs)
                    return matched, chain, error
            else:
                return False, chain, "Selector-"+selector
        return False, chain, error
    else:
        return False, False, "Usage-"+usage

def resultCase(dnssecRaw, matched, chain):
    if dnssecRaw == "Secure":
        dnssec = True
    else:
        dnssec = False

    if dnssec:
        if matched:
            if chain == True: return 0
            elif chain == "Empty": return 0
            else: return 1
        else:
            if chain == True: return 2
            elif chain == "Empty": return 3
            else: return 4
    else:
        if matched:
            if chain == True: return 5
            elif chain == "Empty": return 6
            else: return 7
        else:
            if chain == True: return 8
            elif chain == "Empty": return 9
            else: return 10


def daneValid(d, cert_path, root_certs, root_certs_map):
    from OpenSSL import crypto
    '''
    #Return
    -1: TLSA record does not exist
    -2: STARTTLS cert does not exist
    '''

    if not ('tlsa' in d):
        return -1
    if not ('certs' in d['starttls']):
        return -2

    dnssec = d['tlsa']['dnssec']
    records = parseTLSA(d['tlsa']['record_raw'])
    time = d['time']+":01:00"
    
    resultList = []
    for record in records:
        matched, chain, error = unitValidate(record, time, d['starttls']['certs'], cert_path, root_certs, root_certs_map)
        result = resultCase(dnssec, matched, chain)
        resultList.append(str(result))
    return ' '.join(resultList)

def dnskeyExist(d):
    '''
    #Return
    -1: None (DNSSEC is not Insecure)
    0: DNSKEY does not exist
    1: DNSKEY exist
    '''
    
    if not ('tlsa' in d):
        return -1
    if not (d['tlsa']['dnssec'] == "Insecure"):
        return -1

    msg = base64.b64decode(d['tlsa']['record_raw'])
    msg = mymessage.from_wire(msg)
    raw = msg.to_text()

    dn = d['domain']
    query = dn + " .* RRSIG TLSA .*"
    exist = re.search(query, raw)
    if exist:
        return 1

    query = dn + " .* CNAME .*"
    exist = re.search(query, raw)
    if exit:
        query2 = dn + " .* RRSIG CNAME .*"
        exist2 = re.search(query2, raw)
        if exist2:
            return 1
    
    return 0


def getRootCertsMap():
    root_certs_map = {}

    files = os.listdir(root_cert_path)
    files.remove("java")

    for filename in files:
        f = open(root_cert_path + filename, "r")
        cert = f.read()
        crt = crypto.load_certificate(crypto.FILETYPE_PEM, cert)
        issuer = crt.get_issuer().CN

        root_certs_map[issuer] = cert
        f.close()

    return root_certs_map


def getStats(sc):
    root_certs_map = getRootCertsMap()
    cert_path = temp_cert_path
    f = open(os.path.join(ca_bundle_path, "root-ca-list"), "r")
    root_certs = f.read()
    f.close()

    root_certs_mapG = sc.broadcast(root_certs_map)
    root_certsG = sc.broadcast(root_certs)
    cert_pathG = sc.broadcast(cert_path)

    months = ["1907", "1908", "1909", "1910", "1911", "1912", "2001", "2002", "2003", "2004", "2005", "2006", "2007", "2008", "2009", "2010", "2011", "2012", "2101", "2102"]

    for month in months:
        k = sc.textFile(os.path.join(input_path, month + "*"))\
                .map(fromjson)\
                .map(lambda x: (x['domain'], x['port'], x['time'], x['city'],\
                tlsaCrawled(x), starttlsCrawled(x), getStarttlsErr(x),\
                dnssec(x), dnskeyExist(x), daneValid(x, cert_pathG, root_certsG, root_certs_mapG)))\
                .map(toCSV)
   
        k.saveAsTextFile("dane_output_" + month)


if __name__ == "__main__":
    sc = SparkContext(appName="DANE-Validation")
    sc.addPyFile(os.path.join(dependency_path, "dependencies.zip"))
    getStats(sc)
    sc.stop()

