#!/usr/bin/python3
from pyspark import SparkContext
from pyspark import SparkConf

import sys, os
import dns as mydns
import dns.message as mymessage
import base64
from OpenSSL import crypto
import json
import hashlib
import distance
import binascii


input_path = "/path/to/input"
dane_validation_input_path = "/path/to/dane_validation_output/"
root_cert_path = "/path/to/root_cert_store" # ex) /etc/ssl/certs/
dependency_path = "/path/to/dependencies.zip"


def tojson(line):
    return json.loads(line)

def toCSV(line):
    return " ".join(str(d) for d in line)


def parseTLSA(encoded):
    msg = base64.b64decode(encoded)
    msg = mymessage.from_wire(msg)
    rrset = []

    for answer in msg.answer:
        if answer.rdtype == 52:
            rrset = rrset + [data.to_text() for data in answer]
    return rrset

def checkWeirdField(records):
    def checkUsage(x):
        if x == '0' or x =='1' or x == '2' or x =='3':
            return True, None
        else:
            return False, x
    def checkSelector(x):
        if x == '0' or x == '1':
            return True, None
        else:
            return False, x
    def checkMatchingType(x):
        if x == '0' or x == '1' or x == '2':
            return True, None
        else:
            return False, x
    
    # Check Incorrect Field Values
    results = [None, None, None]
    for record in records:
        record = record.split()
        if len(record) != 4:
            record = record[:4] + [''.join(record[3:])]
        usage = record[0]
        selector = record[1]
        matching = record[2]

        usageValid, wrongUsage = checkUsage(usage)
        selectorValid, wrongSelector = checkSelector(selector)
        matchingValid, wrongMatching = checkMatchingType(matching)

        if not usageValid:
            results[0] = wrongUsage
        if not selectorValid:
            results[1] = wrongSelector
        if not matchingValid:
            results[2] = wrongMatching

    if not len(set(results)) == 1:
        return results
    else:
        if not (None in results):
            return results
    
    return None

def matchCrt(matching, data, crt):
    from OpenSSL import crypto
    
    if matching == '0':
        data = data.lower()
        hashed = binascii.b2a_hex(crt).decode()
    elif matching == '1':
        data = data.lower()
        hashed = hashlib.sha256(crt).hexdigest()
    elif matching == '2':
        data = data.lower()
        hashed = hashlib.sha512(crt).hexdigest()
    else:
        # Must not enter her
        return None, "Matching-"+matching

    if hashed == data:
        return True, None
    return False, "CrtNotMatch"

def matchKey(matching, data, key):
    from OpenSSL import crypto
    if matching == '0':
        data = data.lower()
        hashed = binascii.b2a_hex(key).decode()
    elif matching == '1':
        data = data.lower()
        hashed = hashlib.sha256(key).hexdigest()
    elif matching == '2':
        data = data.lower()
        hashed = hashlib.sha512(key).hexdigest()
    else:
        # Must not enter here
        return None, "Matching-"+matching

    if hashed == data:
        return True, None
    return False, "KeyNotMatch"


def findRoot(cert, root_certs):
    from OpenSSL import crypto
    crt = base64.b64decode(cert)
    crt = crypto.load_certificate(crypto.FILETYPE_PEM, crt)
    issuer = crt.get_issuer()
    if issuer == None:
        return None
    roots = set(root_certs.value.keys())

    if issuer.CN in roots:
        root = base64.b64encode(root_certs.value[issuer.CN].encode())
        return root
    return None

def isRoot(cert):
    from OpenSSL import crypto
    crt = base64.b64decode(cert)
    crt = crypto.load_certificate(crypto.FILETYPE_PEM, crt)
    issuer = crt.get_issuer()
    subject = crt.get_subject()

    if issuer == None or subject == None:
        return False

    if issuer.CN == subject.CN:
        return True
    return False


def unitValidate(record, certs):
    from OpenSSL import crypto
    record = record.split()
    if len(record) != 4:
        record = record[:4] + [''.join(record[3:])]
    usage = record[0]
    selector = record[1]
    matching = record[2]
    data = record[3]

    error = None
    matched = False
    if usage == '0':
        if isRoot(certs[-1]):
            tmpCerts = certs
        else:
            root = findRoot(certs[-1], root_certs)
            if root == None:
                tmpCerts = certs
            else:
                tmpCerts = certs + [root]
        for cert in tmpCerts[1:]:
            pem = base64.b64decode(cert)
            crt = crypto.load_certificate(crypto.FILETYPE_PEM, pem)

            if selector == '0':
                crt = crypto.dump_certificate(crypto.FILETYPE_ASN1, crt)
                matched, error = matchCrt(matching, data, crt)
                if matched:
                    return matched, error
            elif selector == '1':
                pubKey = crt.get_pubkey()
                pubKey = crypto.dump_publickey(crypto.FILETYPE_ASN1, pubKey)
                matched, error = matchKey(matching, data, pubKey)
                if matched:
                    return matched, error
            else:
                # Must not enter here
                return None, None
        return False, error
    elif usage == '2':
        pem = base64.b64decode(certs[-1])
        crt = crypto.load_certificate(crypto.FILETYPE_PEM, pem)

        if selector == '0':
            crt = crypto.dump_certificate(crypto.FILETYPE_ASN1, crt)
            matched, error = matchCrt(matching, data, crt)
        elif selector == '1':
            pubKey = crt.get_pubkey()
            pubKey = crypto.dump_publickey(crypto.FILETYPE_ASN1, pubKey)
            matched, error = matchKey(matching, data, pubKey)
        else:
            # Must not enter here
            return None, None
        return matched, error
    elif usage == '1' or usage == '3':
        pem = base64.b64decode(certs[0])
        crt = crypto.load_certificate(crypto.FILETYPE_PEM, pem)

        if selector == '0':
            crt = crypto.dump_certificate(crypto.FILETYPE_ASN1, crt)
            matched, error = matchCrt(matching, data, crt)
        elif selector == '1':
            pubKey = crt.get_pubkey()
            pubKey = crypto.dump_publickey(crypto.FILETYPE_ASN1, pubKey)
            matched, error = matchKey(matching, data, pubKey)
        else:
            # Must not enter here
            return None, None
        return matched, error
    else:
        #Must not enter here
        return None, None

def findMatch(record, certs, root_certs):
    from OpenSSL import crypto

    record = record.split()
    if len(record) != 4:
        record = record[:3] + [''.join(record[3:])]
    usage = record[0]
    selector = record[1]
    matching = record[2]
    data = record[3]

    if usage == '2' and len(certs) == 1:
        return None

    tmpCerts = certs
    if usage == '0':
        if isRoot(certs[-1]):
            tmpCerts = certs
        else:
            root = findRoot(certs[-1], root_certs)
            if root == None:
                tmpCerts = certs
            else:
                tmpCerts = certs + [root]
 

    for index, cert in enumerate(tmpCerts):
        idx = str(index+1) + "/" + str(len(tmpCerts))
        pem = base64.b64decode(cert)
        crt = crypto.load_certificate(crypto.FILETYPE_PEM, pem)

        key = crt.get_pubkey()
        key = crypto.dump_publickey(crypto.FILETYPE_ASN1, key)
        crt = crypto.dump_certificate(crypto.FILETYPE_ASN1, crt)

        key256 = hashlib.sha256(key).hexdigest()
        if data.lower() == key256:
            return "key256 " + idx + " " + key256
        key512 = hashlib.sha512(key).hexdigest()
        if data.lower() == key512:
            return "key512 " + idx + " " + key512
        crt256 = hashlib.sha256(crt).hexdigest()
        if data.lower() == crt256:
            return "crt256 " + idx + " " + crt256
        crt512 = hashlib.sha512(crt).hexdigest()
        if data.lower() == crt512:
            return "crt512 " + idx + " " + crt512

        crt_raw = crypto.load_certificate(crypto.FILETYPE_ASN1, crt)
        crt_raw = crypto.dump_certificate(crypto.FILETYPE_PEM, crt_raw).lower().decode()
        crt_raw = crt_raw.replace('-----begin certificate-----', '').replace('-----end certificate-----', '').replace('\n', '').lower()
        
        key_raw = crypto.load_publickey(crypto.FILETYPE_ASN1, key)
        key_raw = crypto.dump_publickey(crypto.FILETYPE_PEM, key_raw).lower().decode()
        key_raw = key_raw.replace('-----begin public key-----', '').replace('-----end public key-----', '').replace('\n', '').lower()
        
        data = data.replace('-----begin certificate-----', '').replace('-----end certificate-----' ,'').replace('-----begin public key-----', '').replace('-----end public key-----', '').replace('\n', '').lower()

        if crt_raw == data:
            return "crtRaw " + idx + " " + crt_raw
        if key_raw == data:
            return "keyRaw " + idx + " " + key_raw
    return None


def checkHashDistance(record, certs, root_certs):
    from OpenSSL import crypto
    
    record = record.split()
    if len(record) != 4:
        record = record[:3] + [''.join(record[3:])]
    usage = record[0]
    selector = record[1]
    matching = record[2]
    data = record[3]

    tmpCerts = certs
    if usage == '0':
        if isRoot(certs[-1]):
            tmpCerts = certs
        else:
            root = findRoot(certs[-1], root_certs)
            if root == None:
                tmpCerts = certs
            else:
                tmpCerts = certs + [root]

    if usage == '1' or usage == '3':
        cert = tmpCerts[0]
        pem = base64.b64decode(cert)
        crt = crypto.load_certificate(crypto.FILETYPE_PEM, pem)
        key = crt.get_pubkey()
        key = crypto.dump_publickey(crypto.FILETYPE_ASN1, key)
        crt = crypto.dump_certificate(crypto.FILETYPE_ASN1, crt)
        if selector == "0":
            if matching == "0":
                crt_raw = crypto.load_certificate(crypto.FILETYPE_ASN1, crt)
                crt_raw = crypto.dump_certificate(crypto.FILETYPE_PEM, crt_raw).lower().decode()
                crt = crt_raw.replace('-----begin certificate-----', '').replace('-----end certificate-----', '').replace('\n', '').lower()
                data = data.replace('-----begin certificate-----', '').replace('-----end certificate-----' ,'').replace('-----begin public key-----', '').replace('-----end public key-----', '').replace('\n', '').lower()
            
            elif matching == "1":
                crt = hashlib.sha256(crt).hexdigest()
            else:
                crt = hashlib.sha512(crt).hexdigest()
            return distance.levenshtein(crt, data)

        else:
            if matching == "0":
                key_raw = crypto.load_publickey(crypto.FILETYPE_ASN1, key)
                key_raw = crypto.dump_publickey(crypto.FILETYPE_PEM, key_raw).lower().decode()
                key = key_raw.replace('-----begin public key-----', '').replace('-----end public key-----', '').replace('\n', '').lower()
                data = data.replace('-----begin certificate-----', '').replace('-----end certificate-----' ,'').replace('-----begin public key-----', '').replace('-----end public key-----', '').replace('\n', '').lower()
 
            elif matching == "1":
                key = hashlib.sha256(key).hexdigest()
            else:
                key = hashlib.sha512(key).hexdigest()
            return distance.levenshtein(key, data)

    elif usage == '0' or usage == '2':
        maxDistance = -10000
        for cert in tmpCerts[1:]:
            cert = tmpCerts[0]
            pem = base64.b64decode(cert)
            crt = crypto.load_certificate(crypto.FILETYPE_PEM, pem)
            key = crt.get_pubkey()
            key = crypto.dump_publickey(crypto.FILETYPE_ASN1, key)
            crt = crypto.dump_certificate(crypto.FILETYPE_ASN1, crt)
            if selector == "0":
                if matching == "0":
                    crt_raw = crypto.load_certificate(crypto.FILETYPE_ASN1, crt)
                    crt_raw = crypto.dump_certificate(crypto.FILETYPE_PEM, crt_raw).lower().decode()
                    crt = crt_raw.replace('-----begin certificate-----', '').replace('-----end certificate-----', '').replace('\n', '').lower()
                    data = data.replace('-----begin certificate-----', '').replace('-----end certificate-----' ,'').replace('-----begin public key-----', '').replace('-----end public key-----', '').replace('\n', '').lower()
            
                elif matching == "1":
                    crt = hashlib.sha256(crt).hexdigest()
                else:
                    crt = hashlib.sha512(crt).hexdigest()
                dist = distance.levenshtein(crt, data)
                if dist > maxDistance:
                    maxDistance = dist
            else:
                if matching == "0":
                    key_raw = crypto.load_publickey(crypto.FILETYPE_ASN1, key)
                    key_raw = crypto.dump_publickey(crypto.FILETYPE_PEM, key_raw).lower().decode()
                    key = key_raw.replace('-----begin public key-----', '').replace('-----end public key-----', '').replace('\n', '').lower()
                    data = data.replace('-----begin certificate-----', '').replace('-----end certificate-----' ,'').replace('-----begin public key-----', '').replace('-----end public key-----', '').replace('\n', '').lower()
 
                elif matching == "1":
                    key = hashlib.sha256(key).hexdigest()
                else:
                    key = hashlib.sha512(key).hexdigest()
                dist = distance.levenshtein(key, data)
                if dist > maxDistance:
                    maxDistance = dist
        return maxDistance
    else:
        return -1


def checkEmptyStr(record):
    empty256 = "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    empty512 = "cf83e1357eefb8bdf1542850d66d8007d620e4050b5715dc83f4a921d36ce9ce47d0d13c5d85f2b0ff8318d2877eec2f63b931bd47417a81a538327af927da3e"

    record = record.split()
    if len(record) != 4:
        record = record[:3] + [''.join(record[3:])]
    data = record[3]

    if data == empty256:
        return "Empty256"
    if data == empty512:
        return "Empty512"
    return "NotEmptyFile"


def checkIncorrectField(records, certs, root_certs):
    caseList = []
    for record in records:
        case = findMatch(record, certs, root_certs)
        if case == None:
            continue
        caseList.append(record + " " + case)

    if caseList == []:
        distances = []
        for record in records:
            distance = checkHashDistance(record, certs, root_certs)
            distances.append(distance)
            isEmpty = checkEmptyStr(record)
        return ["NoCase", isEmpty] + distances

    return caseList
    

# incorrect?
# 1. Exclude domains if their TLSA records were not crawled (NoTLSA)
# 2. Exclude domains if they are DANE valid (Correct)
# For remainsers, classify incorrect reasons
# DNSSEC Result (Secure, Insecure, Bogus)
# Chain validation Result 
# Undefined Fields (WeirdField, description)
# Other reasons (Incorrect, description)

def Incorrectness(data, root_certs, validMap):
    
    if not 'tlsa' in data:
        return (data['domain'], data['port'], data['time'], "NoTLSA")

    if not 'certs' in data['starttls']:
        return (data['domain'], data['port'], data['time'], "NoCerts")

    if data['domain'] in validMap.value[data['time']][0]:
        return(data['domain'], data['port'], data['time'], "Correct")

    dnssecFail = data['tlsa']['dnssec']

    isInvalidChain = "CorrectChain"
    if data['domain'] in validMap.value[data['time']][1]:
        isInvalidChain = "WrongChain"

    # if TLSA-Cert matched, just return
    if data['domain'] in validMap.value[data['time']][2]:
        return (data['domain'], data['port'], data['time'], dnssecFail, isInvalidChain, "Matched")
 
    # if TLSA-Cert unmatched, investigate reasons
    records = parseTLSA(data['tlsa']['record_raw'])
    
    weird = checkWeirdField(records)
    if not weird == None:
        return [data['domain'], data['port'], data['time'], dnssecFail, isInvalidChain, "WeirdField"] + weird
    
    incorrect = checkIncorrectField(records, data['starttls']['certs'], root_certs)
   
    if incorrect[0] == "NoCase":
        return [data['domain'], data['port'], data['time'], dnssecFail, isInvalidChain, incorrect[0]] + incorrect[1:]

    return [data['domain'], data['port'], data['time'], dnssecFail, isInvalidChain, "OtherReason"] + incorrect


def getRootCerts():
    root_certs = {}

    files = os.listdir(root_cert_path)
    files.remove("java")

    for filename in files:
        f = open(root_cert_path + filename, "r")
        cert = f.read()
        crt = crypto.load_certificate(crypto.FILETYPE_PEM, cert)
        issuer = crt.get_issuer().CN

        root_certs[issuer] = cert
        f.close()

    return root_certs

def getValidMap(path):
    validMap = {}

    files_ = os.listdir(path)
    files = []
    for f in files_:
        if f.startswith(".") or f.startswith("_"):
            continue
        files.append(f)

    for filename in files:
        f = open(os.path.join(path, filename) ,"r")
        while True:
            line = f.readline()
            if not line: break

            line = line.strip().split()

            key = line[2] + " " + line[3]
            results = line[10:]
            if '0' in results:
                dn = line[0]
                if key in validMap:
                    validMap[key][0].append(dn)
                else:
                    validMap[key] = [[dn], [], []]
                continue
            
            if '1' in results or '4' in results or '7' in results or '10' in results:
                dn = line[0]
                if key in validMap:
                    validMap[key][1].append(dn)
                else:
                    validMap[key] = [[], [dn], []]

            if '1' in results or '5' in results or '6' in results or '7' in results:
                dn = line[0]
                if key in validMap:
                    validMap[key][2].append(dn)
                else:
                    validMap[key] = [[], [], [dn]]
        f.close()

    return validMap


def getStats(sc):
    root_certs = getRootCerts()
    root_certsG = sc.broadcast(root_certs)

    months = ["1907", "1908", "1909", "1910", "1911", "1912", "2001", "2002", "2003", "2004", "2005", "2006", "2007", "2008", "2009", "2010", "2011", "2012", "2101", "2102"]
   
    for month in months:
        validMap = getValidMap(os.path.join(dane_validation_input_path, "dane_output_" + month))
        validMapG = sc.broadcast(validMap)
        k = sc.textFile(os.path.join(input_path, month + "*"))\
                .map(tojson)\
                .map(lambda x: Incorrectness(x, root_certsG, validMapG))\
                .map(toCSV)

        k.saveAsTextFile("incorrect_output_" + month)

if __name__ == "__main__":
    sc = SparkContext(appName="DANE-INCORRECT-CHECK")
    sc.addPyFile(os.path.join(dependency_path, "dependencies.zip"))

    getStats(sc)
    sc.stop()
