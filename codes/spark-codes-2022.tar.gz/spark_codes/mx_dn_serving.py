#/usr/bin/python3
from pyspark import SparkContext, SparkConf

import datetime
import os
import json


input_path = "/path/to/case_hour_output_2102/"
output_path = "/path/to/mx_dn_serving_210212_14"


def fromjson(d):
    return json.loads(d)

def tojson(d):
    return json.dumps(d)

def toCSV(d):
    return " ".join(str(x) for x in d)


def getTLSA(d):
    valids = d['valid_mx']
    invalids = d['invalid_mx']
    notCrawled = d['not_crawled_mx']

    domain = d['domain']

    if len(valids) == 0 and len(invalids) == 0:
        returns = [(x, "NoData", domain) for x in notCrawled]
        return returns

    returns = [(x, "Valid", domain) for x in valids]
    returns += [(x, "Invalid", domain) for x in invalids]
    return returns


def getStats(d):
    mx = d[0]
    dataList = d[1]

    validSet = set([x[1] for x in dataList])
    if not len(validSet) == 1:
        return mx, "-".join(validSet)

    return mx, validSet.pop(), len(dataList), " ".join([d[2] for d in dataList])

def filterDate(d):
    if d['date'] == "20210212":
        if d['hour'] == "14" or d['hour'] == None:
            return True
    return False

def run(sc):
    k = sc.textFile(input_path)\
            .map(fromjson)\
            .filter(filterDate)\
            .map(getTLSA)\
            .flatMap(lambda list: list)\
            .groupBy(lambda x: x[0])\
            .map(getStats)\
            .map(toCSV)
    
    k.saveAsTextFile(os.path.join(output_path, "mx_dn_serving_210212_14"))
    

if __name__ == "__main__":
    sc = SparkContext(appName="DANE-MX-Domain-Serving")
    run(sc)
    sc.stop()
